import test from "node:test";
import assert from "node:assert/strict";
import { REVIEW_SYSTEM_PROMPT, buildReviewUserPrompt } from "../src/lib/prompts/review.prompt.ts";
import { VISUALIZER_SYSTEM_PROMPT, buildVisualizerUserPrompt } from "../src/lib/prompts/visualizer.prompt.ts";
import { validateAndNormalizeVizPayload } from "../src/lib/ai-contracts.ts";
import { getCanonicalMultiDatasets, type VizBundle } from "../src/lib/problems.ts";

test("Prompt Engineering - Review prompt enforces dynamic 3-dataset generation", () => {
  assert.match(REVIEW_SYSTEM_PROMPT, /DYNAMIC 3-DATASET GENERATION/i);
  assert.match(REVIEW_SYSTEM_PROMPT, /Normal Dataset/i);
  assert.match(REVIEW_SYSTEM_PROMPT, /Longer Dataset/i);
  assert.match(REVIEW_SYSTEM_PROMPT, /Edge Case/i);
  assert.match(REVIEW_SYSTEM_PROMPT, /DATA STRUCTURE FIELD MAPPING/i);

  const userPrompt = buildReviewUserPrompt({
    title: "Two Sum",
    difficulty: "Easy",
    topics: ["Array", "Hash Table"],
    statement: "Given an array of integers nums and an integer target...",
    pseudocode: "for i in range(len(nums)): ...",
  });

  assert.match(userPrompt, /DYNAMICALLY GENERATE 3 DISTINCT DATASETS/i);
  assert.match(userPrompt, /Normal Dataset/i);
  assert.match(userPrompt, /Longer Dataset/i);
  assert.match(userPrompt, /Edge Case/i);
});

test("Prompt Engineering - Visualizer prompt mandates step density and deep descriptions", () => {
  assert.match(VISUALIZER_SYSTEM_PROMPT, /PEDAGOGICAL, IN-DEPTH STEP DESCRIPTIONS/i);
  assert.match(VISUALIZER_SYSTEM_PROMPT, /STEP DEPTH & DENSITY REQUIREMENTS/i);
  assert.match(VISUALIZER_SYSTEM_PROMPT, /DO NOT compress loops into 3 or 4 macro steps or skip iterations/i);
  assert.match(VISUALIZER_SYSTEM_PROMPT, /30 to 60\+ comprehensive execution steps/i);

  const userPrompt = buildVisualizerUserPrompt({
    title: "Longest Substring Without Repeating Characters",
    statement: "Find length of longest substring...",
    pseudocode: "left = 0\nfor right in range(len(s)): ...",
    datasetLabel: "Dataset 2: Longer Dataset (Extended Traversal ⚡)",
    datasetDescription: "Extended string sequence",
  });

  assert.match(userPrompt, /PEDAGOGICAL & IN-DEPTH STEP EXPLANATIONS/i);
  assert.match(userPrompt, /STEP DENSITY & COMPREHENSIVE TRAVERSAL/i);
});

test("Contract Normalization - Allows large step traces up to 500 without 100-step truncation", () => {
  // Generate 180 synthetic steps
  const mockRawSteps = Array.from({ length: 180 }, (_, i) => ({
    line: i % 10,
    desc: `Step ${i}: Processing element with value ${i * 2}`,
    array: [1, 2, 3, 4, 5],
    current: i % 5,
    type: "array",
  }));

  const fallback: VizBundle = {
    code: ["line 0", "line 1"],
    array: [1, 2, 3, 4, 5],
    steps: [],
  };

  const normalized = validateAndNormalizeVizPayload(
    {
      code_lines: ["line 0", "line 1"],
      test_array: [1, 2, 3, 4, 5],
      viz_steps: mockRawSteps,
    },
    fallback
  );

  assert.equal(normalized.viz_steps.length, 180, "Expected all 180 steps to be preserved without 100-step capping");
});

test("Canonical Dataset Generation - Generates 3 foundational datasets for all problems", () => {
  const ds = getCanonicalMultiDatasets("two-sum", "Two Sum", ["Array", "Hash Table"]);
  assert.equal(ds.length, 3);
  assert.equal(ds[0].category, "standard");
  assert.equal(ds[1].category, "longer");
  assert.equal(ds[2].category, "edge");
});

test("Matrix & Island - Longer Dataset has expansive 8x10 archipelago with 20+ land cells", () => {
  const islandDatasets = getCanonicalMultiDatasets("max-area-of-island", "Max Area of Island", ["Array", "Matrix", "Depth-First Search"]);
  assert.equal(islandDatasets.length, 3);
  const d2 = islandDatasets[1];
  assert.equal(d2.category, "longer");
  assert.ok(d2.matrix, "Longer dataset must have a matrix defined");
  assert.ok(d2.matrix!.length >= 8, `Expected at least 8 rows, got ${d2.matrix!.length}`);
  assert.ok(d2.matrix![0].length >= 10, `Expected at least 10 columns, got ${d2.matrix![0].length}`);

  const landCells = d2.matrix!.flat().filter((x) => Number(x) === 1).length;
  assert.ok(landCells >= 20, `Expected at least 20 land cells, got ${landCells}`);
});

test("VisualizerTypes - parse2DCoord and coordKey seamlessly match varied coordinate formats", async () => {
  const { parse2DCoord, coordKey, extractScalarValue } = await import("../src/components/visualizer/VisualizerTypes.ts");

  // Tuple format
  assert.deepEqual(parse2DCoord([3, 4]), [3, 4]);
  assert.equal(coordKey([3, 4]), "3,4");

  // String formats
  assert.deepEqual(parse2DCoord("(3, 4)"), [3, 4]);
  assert.deepEqual(parse2DCoord("[3, 4]"), [3, 4]);
  assert.deepEqual(parse2DCoord("3, 4"), [3, 4]);
  assert.deepEqual(parse2DCoord("3,4"), [3, 4]);
  assert.deepEqual(parse2DCoord("r=3, c=4"), [3, 4]);
  assert.deepEqual(parse2DCoord("row=3, col=4"), [3, 4]);
  assert.deepEqual(parse2DCoord("grid[3][4]"), [3, 4]);
  assert.deepEqual(parse2DCoord("cell (3, 4)"), [3, 4]);

  // All resolve to identical coordinate keys
  assert.equal(coordKey("(3, 4)"), "3,4");
  assert.equal(coordKey("r=3, c=4"), "3,4");
  assert.equal(coordKey("grid[3][4]"), "3,4");

  // extractScalarValue preserves 2D coordinates instead of taking only index 1
  assert.equal(extractScalarValue([3, 4]), "3,4");
  assert.equal(extractScalarValue({ r: 3, c: 4 }), "3,4");
});

