export { statementForSlug } from "./statements";
