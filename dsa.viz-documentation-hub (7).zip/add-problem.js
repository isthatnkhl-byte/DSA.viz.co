const fs = require('fs');

const problem = {
  "slug": "chocolate-distribution-problem",
  "title": "Chocolate Distribution Problem",
  "difficulty": "Easy",
  "topics": [
    "Array",
    "Sorting"
  ],
  "companies": [
    "flipkart",
    "amazon"
  ],
  "freq": 70
};

const problemsFile = 'src/data/problems.json';
const problems = JSON.parse(fs.readFileSync(problemsFile, 'utf8'));
problems.unshift(problem); // Add to beginning
fs.writeFileSync(problemsFile, JSON.stringify(problems, null, 2));

const statementsFile = 'src/data/statements.json';
const statements = JSON.parse(fs.readFileSync(statementsFile, 'utf8'));
statements["chocolate-distribution-problem"] = "Given an array of n integers where each value represents the number of chocolates in a packet. Each packet can have a variable number of chocolates. There are m students, the task is to distribute chocolate packets such that: 1. Each student gets exactly one packet. 2. The difference between maximum number of chocolates given to a student and minimum number of chocolates given to a student is minimum.\n\nReturn the minimum difference.\n\nExample 1:\nInput: nums = [7, 3, 2, 4, 9, 12, 56], m = 3\nOutput: 2\nExplanation: The minimum difference between maximum chocolates and minimum chocolates is 9 - 7 = 2 by choosing following m packets: [7, 9, 12].\n\nExample 2:\nInput: nums = [3, 4, 1, 9, 56, 7, 9, 12], m = 5\nOutput: 6\nExplanation: The minimum difference between maximum chocolates and minimum chocolates is 9 - 3 = 6 by choosing following m packets: [3, 4, 7, 9, 9].\n\nConstraints:\n1 <= m <= n <= 10^5\n1 <= nums[i] <= 10^9";
fs.writeFileSync(statementsFile, JSON.stringify(statements, null, 2));

console.log("Added problem successfully!");
