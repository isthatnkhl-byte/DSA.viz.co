const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// Remove helpers
const helperStart = code.indexOf('// Helper for safe path resolution');
const helperEnd = code.indexOf('app.post("/api/sync-leetcode"');
if (helperStart !== -1 && helperEnd !== -1) {
    // leave the sync-leetcode endpoint intact, but we want to trim just the helpers. 
    // Wait, let's find the exact end of buildFileTree
    const buildTreeEnd = code.indexOf('    return [];\n  }\n}\n');
    if (buildTreeEnd !== -1) {
       code = code.substring(0, helperStart) + code.substring(buildTreeEnd + '    return [];\n  }\n}\n'.length);
    }
}

// Remove File & Compiler APIs
const fileStart = code.indexOf('// ---------------------\napp.get("/api/files/tree"');
const chatStart = code.indexOf('// API: Multi-turn Chatbot endpoint\napp.post("/api/chat"');
if (fileStart !== -1 && chatStart !== -1) {
    code = code.substring(0, fileStart) + code.substring(chatStart);
}

fs.writeFileSync('server.ts', code);
console.log("Cleanup complete");
