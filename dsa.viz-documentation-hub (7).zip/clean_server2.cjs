const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const fileStart = code.indexOf('app.get("/api/files/tree"');
const chatStart = code.indexOf('// API: Multi-turn Chatbot endpoint\napp.post("/api/chat"');
if (fileStart !== -1 && chatStart !== -1) {
    // Find the previous newline or comment if possible
    code = code.substring(0, fileStart) + code.substring(chatStart);
    fs.writeFileSync('server.ts', code);
    console.log("Successfully removed APIs");
} else {
    console.log("Could not find start/end bounds for APIs", fileStart, chatStart);
}
