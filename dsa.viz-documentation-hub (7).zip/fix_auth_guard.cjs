const fs = require('fs');
let code = fs.readFileSync('src/components/AuthGuard.tsx', 'utf8');

code = code.replace(
  'import { useRouter } from "@tanstack/react-router";',
  'import { useRouter, useLocation } from "@tanstack/react-router";'
);

code = code.replace(
  'const isLandingPage = window.location.pathname === "/";',
  'const location = useLocation();\n  const isLandingPage = location.pathname === "/";'
);

fs.writeFileSync('src/components/AuthGuard.tsx', code);
console.log("Patched AuthGuard");
