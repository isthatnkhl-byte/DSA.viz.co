const fs = require('fs');
let code = fs.readFileSync('src/components/AuthGuard.tsx', 'utf8');

code = code.replace(
  'const isLandingPage = location.pathname === "/";',
  'const isLandingPage = location.pathname === "/" || location.pathname === "/auth";'
);

fs.writeFileSync('src/components/AuthGuard.tsx', code);
console.log("Patched AuthGuard for /auth");
