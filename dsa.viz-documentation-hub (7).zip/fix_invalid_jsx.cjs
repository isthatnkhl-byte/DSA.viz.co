const fs = require('fs');
let code = fs.readFileSync('src/routes/index.tsx', 'utf8');

code = code.replace(/<\/Link>\n              <\/Link>/g, '</Link>');

fs.writeFileSync('src/routes/index.tsx', code);
console.log("Fixed extra </Link>");
