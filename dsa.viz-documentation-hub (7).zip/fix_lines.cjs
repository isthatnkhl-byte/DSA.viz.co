const fs = require('fs');
let code = fs.readFileSync('src/routes/index.tsx', 'utf8');

const target1 = `              </Link>
          
              </Link>`;
code = code.replace(target1, '              </Link>');

const target2 = `              </Link>
            ) : (`;
// wait, line 230 is empty or has spaces. Let's just use regex with `\s+`
code = code.replace(/<\/Link>\s+<\/Link>/g, '</Link>');

fs.writeFileSync('src/routes/index.tsx', code);
console.log("Fixed extra </Link>");
