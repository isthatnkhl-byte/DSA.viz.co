const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

if (!code.includes("import crypto from 'crypto';")) {
  code = "import crypto from 'crypto';\n" + code;
}

const signStatePattern = "const state = Buffer.from(JSON.stringify({ uid, redirectUri })).toString('base64');";
const signStateReplacement = `const payload = JSON.stringify({ uid, redirectUri });
  const hmac = crypto.createHmac('sha256', process.env.GITHUB_CLIENT_SECRET || 'fallback-secret');
  hmac.update(payload);
  const signature = hmac.digest('hex');
  const state = Buffer.from(JSON.stringify({ payload, signature })).toString('base64');`;
  
const verifyStatePattern = `  let uid, redirectUri;
  try {
    const decoded = JSON.parse(Buffer.from(state, 'base64').toString('utf8'));
    uid = decoded.uid;
    redirectUri = decoded.redirectUri;
  } catch (e) {
    return res.status(400).send("Invalid state");
  }`;
  
const verifyStateReplacement = `  let uid, redirectUri;
  try {
    const decodedWrapper = JSON.parse(Buffer.from(state, 'base64').toString('utf8'));
    const { payload, signature } = decodedWrapper;
    
    // Verify signature
    const hmac = crypto.createHmac('sha256', process.env.GITHUB_CLIENT_SECRET || 'fallback-secret');
    hmac.update(payload);
    const expectedSignature = hmac.digest('hex');
    
    if (signature !== expectedSignature) {
      return res.status(403).send("State signature mismatch - possible CSRF attack");
    }
    
    const decoded = JSON.parse(payload);
    uid = decoded.uid;
    redirectUri = decoded.redirectUri;
  } catch (e) {
    return res.status(400).send("Invalid state");
  }`;

code = code.replace(signStatePattern, signStateReplacement);
code = code.replace(verifyStatePattern, verifyStateReplacement);

fs.writeFileSync('server.ts', code);
console.log("OAuth state signature logic added.");
