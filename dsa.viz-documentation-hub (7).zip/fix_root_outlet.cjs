const fs = require('fs');
let code = fs.readFileSync('src/routes/__root.tsx', 'utf8');

// The first one was the comment, so let's fix the comment back.
code = code.replace('<AuthGuard><Outlet /></AuthGuard>', '<Outlet />');

// Now explicitly replace the real one.
const oldJSX = `        {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
        <Outlet />`;
const newJSX = `        {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
        <AuthGuard>
          <Outlet />
        </AuthGuard>`;

if (code.includes(oldJSX)) {
  code = code.replace(oldJSX, newJSX);
}

fs.writeFileSync('src/routes/__root.tsx', code);
console.log("Properly wrapped Outlet in AuthGuard");
