const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// 1. Add imports
const imports = `
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import crypto from 'crypto';
`;

code = code.replace('import dotenv from "dotenv";', imports + '\nimport dotenv from "dotenv";');

// 2. Add Encryption helpers
const encryptionHelpers = `
const getEncryptionKey = () => {
  if (process.env.ENCRYPTION_KEY) return Buffer.from(process.env.ENCRYPTION_KEY.padEnd(32, '0').slice(0, 32));
  return crypto.scryptSync(process.env.GITHUB_CLIENT_SECRET || 'default_secret', 'salt', 32);
};

function encryptToken(text) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-gcm', getEncryptionKey(), iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag();
  return \`\${iv.toString('hex')}:\${encrypted}:\${authTag.toString('hex')}\`;
}

function decryptToken(text) {
  try {
    const parts = text.split(':');
    if (parts.length !== 3) return text; // Fallback for old unencrypted tokens
    const iv = Buffer.from(parts[0], 'hex');
    const encryptedText = Buffer.from(parts[1], 'hex');
    const authTag = Buffer.from(parts[2], 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', getEncryptionKey(), iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch(e) {
    return text;
  }
}
`;

code = code.replace('const app = express();', encryptionHelpers + '\nconst app = express();');

// 3. Add Rate limiters
const limiters = `
const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 100,
  message: { error: "Too many requests, please try again later." }
});

const aiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 5,
  message: { error: "AI rate limit exceeded. Max 5 requests per minute." }
});

app.use("/api/", apiLimiter);
`;

code = code.replace('app.use(express.urlencoded({ extended: true, limit: "50mb" }));', 'app.use(express.urlencoded({ extended: true, limit: "50mb" }));\n' + limiters);

// 4. Rate limit AI chat & generate image
code = code.replace('app.post("/api/chat", async (req: Request, res: Response) => {', 'app.post("/api/chat", aiLimiter, async (req: Request, res: Response) => {');
code = code.replace('app.post("/api/generate-image", async (req: Request, res: Response) => {', 'app.post("/api/generate-image", aiLimiter, async (req: Request, res: Response) => {');

// 5. Encrypt token on callback
code = code.replace('await updateProfile(uid, { githubToken: accessToken });', 'await updateProfile(uid, { githubToken: encryptToken(accessToken) });');

// 6. Decrypt token on push
code = code.replace('const githubToken = profile?.githubToken;', 'const githubToken = profile?.githubToken ? decryptToken(profile.githubToken) : null;');

// 7. Zod validation for push
const pushValidation = `
    const pushSchema = z.object({
      code: z.string().max(50000, "Code is too large"),
      titleSlug: z.string().max(255),
      lang: z.string().max(50)
    });
    
    const parsed = pushSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid payload", details: parsed.error.format() });
    }
    const { code, titleSlug, lang } = parsed.data;
`;

code = code.replace('const { code, titleSlug, lang } = req.body;', pushValidation);

fs.writeFileSync('server.ts', code);
console.log("Security enhancements applied.");
