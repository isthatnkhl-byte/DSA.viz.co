const fs = require('fs');
let code = fs.readFileSync('src/components/SiteHeader.tsx', 'utf8');

// Fix Desktop Nav
const navStart = '<nav className="hidden md:flex items-center gap-1 rounded-full border border-border/70 bg-card/70 px-2 py-1 shadow-xs backdrop-blur-md">';
const navEnd = '</nav>';
if (code.includes(navStart)) {
  const startIndex = code.indexOf(navStart);
  const endIndex = code.indexOf(navEnd, startIndex) + navEnd.length;
  
  const originalNav = code.substring(startIndex, endIndex);
  
  const newNav = `<nav className="hidden md:flex items-center gap-1 rounded-full border border-border/70 bg-card/70 px-2 py-1 shadow-xs backdrop-blur-md">
          {user && (
            <>
              <Link
                to="/problems"
                activeProps={{
                  className: "bg-primary/20 text-primary font-bold border-primary/30",
                }}
                className="flex items-center gap-1.5 rounded-full px-3.5 py-1.5 font-mono text-xs font-semibold text-muted-foreground transition-all hover:bg-secondary hover:text-foreground active:scale-95"
              >
                <Layers className="size-3.5 text-primary" />
                <span>Problems</span>
                <span className="rounded-full bg-primary/15 px-1.5 py-0.2 text-[9px] font-bold text-primary">
                  800+
                </span>
              </Link>
              <Link
                to={"/sheets" as any}
                activeProps={{
                  className: "bg-primary/20 text-primary font-bold border-primary/30",
                }}
                className="flex items-center gap-1.5 rounded-full px-3.5 py-1.5 font-mono text-xs font-semibold text-muted-foreground transition-all hover:bg-secondary hover:text-foreground active:scale-95"
              >
                <BookOpen className="size-3.5 text-primary" />
                <span>DSA Sheets</span>
              </Link>
              <Link
                to="/playground"
                activeProps={{
                  className: "bg-primary/20 text-primary font-bold border-primary/30",
                }}
                className="flex items-center gap-1.5 rounded-full px-3.5 py-1.5 font-mono text-xs font-semibold text-muted-foreground transition-all hover:bg-secondary hover:text-foreground active:scale-95"
              >
                <Sparkles className="size-3.5 text-primary" />
                <span>Playground</span>
              </Link>
              <Link
                to="/compiler"
                activeProps={{
                  className: "bg-emerald-500/15 text-emerald-400 font-bold border-emerald-500/30",
                }}
                className="flex items-center gap-1.5 rounded-full px-3.5 py-1.5 font-mono text-xs font-semibold text-muted-foreground transition-all hover:bg-secondary hover:text-foreground active:scale-95"
              >
                <Code2 className="size-3.5 text-emerald-400" />
                <span>C++ Compiler</span>
                <span className="rounded-full bg-emerald-500/20 px-1.5 py-0.2 text-[9px] font-bold text-emerald-400">
                  C++
                </span>
              </Link>
            </>
          )}
        </nav>`;

  code = code.replace(originalNav, newNav);
}

// Fix Mobile Menu Nav
const mobileMenuStart = `{mobileMenuOpen && (
        <div className="mt-3 flex flex-col gap-2 rounded-2xl border border-border/80 bg-card/95 p-4 shadow-2xl backdrop-blur-xl md:hidden animate-fade">`;
const mobileMenuEnd = `        </div>
      )}
    </header>`;

if (code.includes(mobileMenuStart)) {
  const startIndex = code.indexOf(mobileMenuStart);
  const endIndex = code.indexOf(mobileMenuEnd, startIndex) + mobileMenuEnd.length;
  
  const newMobileMenu = `{mobileMenuOpen && (
        <div className="mt-3 flex flex-col gap-2 rounded-2xl border border-border/80 bg-card/95 p-4 shadow-2xl backdrop-blur-xl md:hidden animate-fade">
          {user && (
            <>
              <Link
                to="/problems"
                onClick={() => setMobileMenuOpen(false)}
                activeProps={{
                  className: "bg-primary/20 text-primary font-bold border-primary/30",
                }}
                className="flex items-center justify-between rounded-xl border border-transparent px-3.5 py-2.5 font-mono text-xs font-semibold text-foreground hover:bg-secondary transition-all"
              >
                <span className="flex items-center gap-2">
                  <Layers className="size-4 text-primary" />
                  <span>Problems</span>
                </span>
                <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] text-primary font-bold">
                  800+
                </span>
              </Link>
              <Link
                to={"/sheets" as any}
                onClick={() => setMobileMenuOpen(false)}
                activeProps={{
                  className: "bg-primary/20 text-primary font-bold border-primary/30",
                }}
                className="flex items-center gap-2 rounded-xl border border-transparent px-3.5 py-2.5 font-mono text-xs font-semibold text-foreground hover:bg-secondary transition-all"
              >
                <BookOpen className="size-4 text-primary" />
                <span>DSA Sheets</span>
              </Link>
              <Link
                to="/playground"
                onClick={() => setMobileMenuOpen(false)}
                activeProps={{
                  className: "bg-primary/20 text-primary font-bold border-primary/30",
                }}
                className="flex items-center gap-2 rounded-xl border border-transparent px-3.5 py-2.5 font-mono text-xs font-semibold text-foreground hover:bg-secondary transition-all"
              >
                <Sparkles className="size-4 text-primary" />
                <span>Playground</span>
              </Link>
              <Link
                to="/compiler"
                onClick={() => setMobileMenuOpen(false)}
                activeProps={{
                  className: "bg-emerald-500/15 text-emerald-400 font-bold border-emerald-500/30",
                }}
                className="flex items-center justify-between rounded-xl border border-transparent px-3.5 py-2.5 font-mono text-xs font-semibold text-foreground hover:bg-secondary transition-all"
              >
                <span className="flex items-center gap-2">
                  <Code2 className="size-4 text-emerald-400" />
                  <span>Online C++ Compiler</span>
                </span>
                <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] text-emerald-400 font-bold">
                  C++20
                </span>
              </Link>
            </>
          )}

          <div className="my-1 border-t border-border/60" />

          {/* Auth in Mobile Menu */}
          {user ? (
            <div className="flex flex-col gap-1.5 pt-1">
              <Link
                to="/dashboard"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-2 rounded-xl px-3.5 py-2 font-mono text-xs text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
              >
                <LayoutDashboard className="size-4" />
                <span>Dashboard</span>
              </Link>
              <Link
                to="/profile"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-2 rounded-xl px-3.5 py-2 font-mono text-xs text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
              >
                <UserIcon className="size-4" />
                <span>Profile</span>
              </Link>
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  signOut();
                }}
                className="flex items-center gap-2 rounded-xl px-3.5 py-2 font-mono text-xs text-destructive hover:bg-destructive/10 transition-all text-left"
              >
                <LogOut className="size-4" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <div
              onClick={() => setMobileMenuOpen(false)}
              className="mt-1 cursor-pointer"
            >
              <Link to="/auth">
                <Button className="w-full rounded-xl py-2.5 font-mono text-xs font-bold shadow-md bg-primary text-primary-foreground">
                  Sign In
                </Button>
              </Link>
            </div>
          )}
        </div>
      )}
    </header>`;
    
  code = code.substring(0, startIndex) + newMobileMenu + code.substring(endIndex);
}

fs.writeFileSync('src/components/SiteHeader.tsx', code);
console.log("Reconstructed SiteHeader.tsx nav logic");
