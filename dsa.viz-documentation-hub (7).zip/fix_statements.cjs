const fs = require('fs');

let pfCode = `import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import statementsData from "../data/statements.json";

const statementsMap = (statementsData?.default || statementsData || {});

export const getStatement = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (
      typeof input === "object" &&
      input !== null &&
      "slug" in input &&
      typeof (input as { slug?: unknown }).slug === "string"
    ) {
      return { slug: (input as { slug: string }).slug };
    }
    return z.object({ slug: z.string() }).parse(input);
  })
  .handler(async ({ data }) => {
    try {
      let slug = data?.slug ?? "";
      let statement = "";
      
      let s = "";
      try {
        s = decodeURIComponent(slug).toLowerCase().trim().replace(/\\/+$/, "");
      } catch {
        s = slug.toLowerCase().trim().replace(/\\/+$/, "");
      }
      
      statement = statementsMap[s] || statementsMap[s.replace(/_/g, "-").replace(/\\s+/g, "-")] || "";
      
      if (!statement && slug) {
        const res = await fetch("https://leetcode.com/graphql", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                query: \`query questionData($titleSlug: String!) {
                    question(titleSlug: $titleSlug) {
                        content
                    }
                }\`,
                variables: { titleSlug: slug }
            })
        });
        const json = await res.json();
        if (json?.data?.question?.content) {
            statement = json.data.question.content;
        }
      }

      return { statement };
    } catch (e) {
      console.error(e);
      return { statement: "" };
    }
  });`;

fs.writeFileSync('src/lib/problem.functions.ts', pfCode);

let slugCode = fs.readFileSync('src/routes/problem.$slug.tsx', 'utf8');

slugCode = slugCode.replace(/import \{ statementForSlug \} from "@\/lib\/statements";\n?/g, "");

slugCode = slugCode.replace(
`  loader: ({ params }) => {
    const slug = params?.slug ? String(params.slug) : "";
    const problem = problemBySlug(slug);
    if (!problem) throw notFound();
    const statement = statementForSlug(slug);
    return { problem, statement };
  },`,
`  loader: ({ params }) => {
    const slug = params?.slug ? String(params.slug) : "";
    const problem = problemBySlug(slug);
    if (!problem) throw notFound();
    return { problem };
  },`
);

slugCode = slugCode.replace(
`  const initialStatement = loaderData?.statement || (problem?.slug ? statementForSlug(problem.slug) : "");
  const fetchStatement = useServerFn(getStatement);
  
  const { data: remoteStatement, isLoading: isStatementLoading } = useQuery({
    queryKey: ['problem-statement', problem?.slug],
    queryFn: () => fetchStatement({ data: { slug: problem?.slug || "" } }),
    enabled: !!problem?.slug && !initialStatement, // Only fetch if not already in JSON
    staleTime: Infinity,
  });

  const statement = initialStatement || (remoteStatement?.statement ?? "");`,
`  const fetchStatement = useServerFn(getStatement);
  
  const { data: remoteStatement, isLoading: isStatementLoading } = useQuery({
    queryKey: ['problem-statement', problem?.slug],
    queryFn: () => fetchStatement({ data: { slug: problem?.slug || "" } }),
    enabled: !!problem?.slug,
    staleTime: Infinity,
  });

  const statement = remoteStatement?.statement ?? "";`
);

fs.writeFileSync('src/routes/problem.$slug.tsx', slugCode);
