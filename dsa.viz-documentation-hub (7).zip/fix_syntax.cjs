const fs = require('fs');
let code = fs.readFileSync('src/components/landing/DsaSheetSection.tsx', 'utf8');

code = code.replace(/\\\`/g, '\`');
code = code.replace(/\\\$/g, '$');

fs.writeFileSync('src/components/landing/DsaSheetSection.tsx', code);
