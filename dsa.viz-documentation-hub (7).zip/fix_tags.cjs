const fs = require('fs');

async function main() {
    console.log("Loading problems.json...");
    const problemsFile = 'src/data/problems.json';
    const problems = JSON.parse(fs.readFileSync(problemsFile, 'utf8'));
    
    console.log(`Loaded ${problems.length} problems. Fetching tags from LeetCode...`);
    
    const allLeetCodeTags = new Map();
    let skip = 0;
    const limit = 100;
    let total = 1; // dummy initial value
    
    while (skip < total) {
        console.log(`Fetching from LeetCode, skip: ${skip}...`);
        try {
            const res = await fetch("https://leetcode.com/graphql", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    query: `query problemsetQuestionList($categorySlug: String, $limit: Int, $skip: Int, $filters: QuestionListFilterInput) {
                        problemsetQuestionList: questionList(
                            categorySlug: $categorySlug
                            limit: $limit
                            skip: $skip
                            filters: $filters
                        ) {
                            total: totalNum
                            questions: data {
                                titleSlug
                                topicTags {
                                    name
                                }
                            }
                        }
                    }`,
                    variables: { categorySlug: "", skip, limit, filters: {} }
                })
            });
            const json = await res.json();
            
            total = json.data.problemsetQuestionList.total;
            const qs = json.data.problemsetQuestionList.questions;
            
            if (!qs || qs.length === 0) break;
            
            for (const q of qs) {
                const tags = q.topicTags.map(t => t.name);
                allLeetCodeTags.set(q.titleSlug, tags);
            }
            
            skip += limit;
        } catch (e) {
            console.error("Error fetching", e);
            break;
        }
    }
    
    console.log(`Fetched tags for ${allLeetCodeTags.size} problems from LeetCode.`);
    
    let updatedCount = 0;
    for (const p of problems) {
        if (allLeetCodeTags.has(p.slug)) {
            const freshTags = allLeetCodeTags.get(p.slug);
            if (freshTags && freshTags.length > 0) {
                // Check if they are different
                if (JSON.stringify(p.topics) !== JSON.stringify(freshTags)) {
                    p.topics = freshTags;
                    updatedCount++;
                }
            }
        }
    }
    
    if (updatedCount > 0) {
        fs.writeFileSync(problemsFile, JSON.stringify(problems, null, 2));
        console.log(`Successfully updated tags for ${updatedCount} problems.`);
    } else {
        console.log("No updates were necessary.");
    }
}

main();
