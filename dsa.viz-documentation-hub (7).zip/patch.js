const fs = require("fs");
const file = "src/lib/prompts/visualizer.prompt.ts";
let code = fs.readFileSync(file, "utf8");

// Add rule 11 for DP
code = code.replace(
  `10) DUAL POINTERS ACROSS MULTIPLE ARRAYS:`,
  `10) DUAL POINTERS ACROSS MULTIPLE ARRAYS:
   - For Array 1: use "left" and "right".
   - For Array 2 ("secondaryArray"): use "left2" and "right2".

11) ARRAY / STRING ALGORITHMS:
   - For standard array/string problems (Two Pointers, Sliding Window, Prefix Sum), set "type": "array".
   - Provide the array in "array". Use "left", "right", and "current" (number indices) to track pointers.
   - Do NOT use "linkedlist" unless the problem explicitly operates on a Linked List data structure.

12) DYNAMIC PROGRAMMING (DP):
   - For DP problems, set "type": "dp".
   - Place the DP table in the "matrix" field (if 1D DP, provide it as a 1-row matrix e.g. [[dp0, dp1, ...]]).
   - Place the input array in the "array" field.
   - Set "current" to "r,c" to highlight the active cell being computed.`
);

// We need to make sure we didn't duplicate it. Let's just do a string replace on rule 10.
// Wait, the previous block has:
/*
10) DUAL POINTERS ACROSS MULTIPLE ARRAYS:
   - For Array 1: use "left" and "right".
   - For Array 2 ("secondaryArray"): use "left2" and "right2".
*/

fs.writeFileSync(file, code);
