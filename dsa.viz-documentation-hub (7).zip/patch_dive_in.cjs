const fs = require('fs');
let code = fs.readFileSync('src/components/landing/DiveInPortal.tsx', 'utf8');

if (!code.includes('useAuth')) {
    code = code.replace('import { Link } from "@tanstack/react-router";', 'import { Link } from "@tanstack/react-router";\nimport { useAuth } from "@/hooks/useAuth";');
    
    code = code.replace('export function DiveInPortal() {', 'export function DiveInPortal() {\n  const { user, signInWithGoogle } = useAuth();');
    
    const actionsRegex = /<div className="relative z-10 mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">([\s\S]*?)<\/div>/;
    
    const loggedOutActions = `
        <div className="relative z-10 mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          {!user ? (
            <button
              onClick={() => signInWithGoogle()}
              className="group/dive relative inline-flex items-center gap-4 rounded-2xl bg-gradient-to-r from-primary via-primary to-accent px-9 py-5 text-base sm:text-lg font-mono font-bold text-primary-foreground shadow-xl shadow-primary/30 transition-all duration-300 hover:scale-[1.03] hover:shadow-primary/50 active:scale-[0.98] overflow-hidden"
            >
              <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-1000 group-hover/dive:translate-x-full" />
              <span className="tracking-wide">Sign in with Google to Start</span>
              <span className="relative flex size-8 items-center justify-center rounded-full bg-white/20 text-primary-foreground transition-all duration-300 group-hover/dive:translate-x-1.5">
                <ArrowRight className="size-5 transition-transform duration-300 group-hover/dive:scale-110" />
              </span>
            </button>
          ) : (
            <>
              <Link
                to="/problems"
                className="group/dive relative inline-flex items-center gap-4 rounded-2xl bg-gradient-to-r from-primary via-primary to-accent px-9 py-5 text-base sm:text-lg font-mono font-bold text-primary-foreground shadow-xl shadow-primary/30 transition-all duration-300 hover:scale-[1.03] hover:shadow-primary/50 active:scale-[0.98] overflow-hidden"
              >
                <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-1000 group-hover/dive:translate-x-full" />
                <span className="tracking-wide">Explore 800+ Problems</span>
                <span className="relative flex size-8 items-center justify-center rounded-full bg-white/20 text-primary-foreground transition-all duration-300 group-hover/dive:translate-x-1.5">
                  <ArrowRight className="size-5 transition-transform duration-300 group-hover/dive:scale-110" />
                </span>
              </Link>
              <Link
                to="/playground"
                className="inline-flex items-center gap-2 rounded-2xl border border-border/80 bg-secondary/60 px-7 py-5 text-sm sm:text-base font-mono font-semibold text-foreground hover:bg-secondary hover:border-primary/40 transition-all duration-200 backdrop-blur-md"
              >
                <Sparkles className="size-4 text-primary" />
                <span>Open Playground</span>
              </Link>
            </>
          )}
        </div>
    `;
    code = code.replace(actionsRegex, loggedOutActions);
    fs.writeFileSync('src/components/landing/DiveInPortal.tsx', code);
    console.log("Patched DiveInPortal");
}
