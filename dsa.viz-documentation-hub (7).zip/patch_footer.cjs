const fs = require('fs');
let code = fs.readFileSync('src/routes/index.tsx', 'utf8');

if (!code.includes('const { user, signInWithGoogle } = useAuth();')) {
    code = code.replace(
      'export const Route = createFileRoute("/")({',
      'import { useAuth } from "@/hooks/useAuth";\n\nexport const Route = createFileRoute("/")({'
    );

    code = code.replace(
      'function LandingPage() {',
      'function LandingPage() {\n  const { user, signInWithGoogle } = useAuth();'
    );
}

const originalFooterNav = `<div className="flex items-center gap-5 font-mono text-xs text-muted-foreground">
            <Link to="/problems" className="hover:text-primary transition-colors">
              Problems
            </Link>
            <Link to="/playground" className="hover:text-primary transition-colors">
              Playground
            </Link>
            <Link to="/compiler" className="hover:text-primary transition-colors">
              C++ Compiler
            </Link>
          </div>`;

const newFooterNav = `{user ? (
          <div className="flex items-center gap-5 font-mono text-xs text-muted-foreground">
            <Link to="/problems" className="hover:text-primary transition-colors">
              Problems
            </Link>
            <Link to="/playground" className="hover:text-primary transition-colors">
              Playground
            </Link>
            <Link to="/compiler" className="hover:text-primary transition-colors">
              C++ Compiler
            </Link>
          </div>
          ) : (
          <div className="flex items-center gap-5 font-mono text-sm font-bold text-primary cursor-pointer hover:text-accent transition-colors" onClick={() => signInWithGoogle()}>
            Sign in to start your journey &rarr;
          </div>
          )}`;

if (code.includes(originalFooterNav)) {
    code = code.replace(originalFooterNav, newFooterNav);
    fs.writeFileSync('src/routes/index.tsx', code);
    console.log("Patched footer in index.tsx");
} else {
    console.log("Could not find original footer nav");
}
