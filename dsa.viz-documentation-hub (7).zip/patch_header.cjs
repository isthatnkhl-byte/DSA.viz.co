const fs = require('fs');
let code = fs.readFileSync('src/components/SiteHeader.tsx', 'utf8');

if (!code.includes('const { user, signOut, loading } = useAuth();')) {
    // wait, does SiteHeader already import useAuth?
    console.log("Could not find useAuth");
}

const navStart = `<nav className="hidden md:flex flex-1 items-center justify-center gap-1.5">`;
const navEnd = `        </nav>`;

if (code.includes(navStart) && code.includes(navEnd)) {
    const originalNav = code.substring(code.indexOf(navStart), code.indexOf(navEnd) + navEnd.length);
    let newNav = originalNav.replace(navStart, navStart + '\n          {user && (\n            <>');
    newNav = newNav.replace(navEnd, '            </>\n          )}\n' + navEnd);
    code = code.replace(originalNav, newNav);
}

const mobileLinksStart = `<Link
            to="/problems"`;
const mobileLinksEnd = `<div className="my-1 border-t border-border/60" />`;
if (code.includes(mobileLinksStart) && code.includes(mobileLinksEnd)) {
    const originalMobile = code.substring(code.indexOf(mobileLinksStart), code.indexOf(mobileLinksEnd));
    let newMobile = '{user && (\n            <>\n              ' + originalMobile.trim() + '\n            </>\n          )}\n          ';
    code = code.replace(originalMobile, newMobile);
}

fs.writeFileSync('src/components/SiteHeader.tsx', code);
console.log("Patched SiteHeader.tsx");
