const fs = require('fs');
let code = fs.readFileSync('src/components/SiteHeader.tsx', 'utf8');

const navStart = `<nav className="hidden md:flex items-center gap-1 rounded-full border border-border/70 bg-card/70 px-2 py-1 shadow-xs backdrop-blur-md">`;
const navEnd = `        </nav>`;

if (code.includes(navStart) && code.includes(navEnd)) {
    // Check if we didn't already patch it
    if (!code.includes('{user && (\n            <>              <Link')) {
       // do it
    }
}
