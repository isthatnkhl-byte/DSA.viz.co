const fs = require('fs');
let code = fs.readFileSync('src/routes/index.tsx', 'utf8');

if (!code.includes('DsaSheetSection')) {
    code = code.replace('import { DiveInPortal } from "@/components/landing/DiveInPortal";', 'import { DiveInPortal } from "@/components/landing/DiveInPortal";\nimport { DsaSheetSection } from "@/components/landing/DsaSheetSection";');
    
    code = code.replace('{/* 6. The Propulsive "Dive In" Launcher Section */}', '{/* 5.5. DSA Sheets */}\n        <DsaSheetSection />\n\n        {/* 6. The Propulsive "Dive In" Launcher Section */}');
    
    fs.writeFileSync('src/routes/index.tsx', code);
    console.log("Patched index.tsx");
}
