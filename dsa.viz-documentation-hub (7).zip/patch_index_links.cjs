const fs = require('fs');
let code = fs.readFileSync('src/routes/index.tsx', 'utf8');

// Replace the Explore all 800+ problems link
const exploreLinkStart = `<Link
              to="/problems"
              className="inline-flex items-center gap-2 font-mono text-xs sm:text-sm font-bold text-primary hover:underline hover:translate-x-1 transition-all"
            >`;
const exploreLinkEnd = `</Link>`;

if (code.includes(exploreLinkStart)) {
  const startIndex = code.indexOf(exploreLinkStart);
  const endIndex = code.indexOf(exploreLinkEnd, startIndex) + exploreLinkEnd.length;
  
  const exploreOriginal = code.substring(startIndex, endIndex);
  
  const exploreNew = `{user ? (
            <Link
              to="/problems"
              className="inline-flex items-center gap-2 font-mono text-xs sm:text-sm font-bold text-primary hover:underline hover:translate-x-1 transition-all"
            >
              <span>Explore all {TOTAL_PROBLEMS}+ problems</span>
              <ArrowRight className="size-4" />
            </Link>
          ) : (
            <Link
              to="/auth"
              className="inline-flex items-center gap-2 font-mono text-xs sm:text-sm font-bold text-primary hover:underline hover:translate-x-1 transition-all"
            >
              <span>Explore all {TOTAL_PROBLEMS}+ problems</span>
              <ArrowRight className="size-4" />
            </Link>
          )}`;
  
  code = code.replace(exploreOriginal, exploreNew);
}

// Replace the problem loop link
const problemLinkStart = `<Link
                key={p.slug}
                to="/problem/$slug"
                params={{ slug: p.slug }}
                className="group relative flex flex-col justify-between gap-3 rounded-2xl border border-border/80 bg-card/75 p-5 shadow-sm backdrop-blur-md hover:border-primary/50 hover:shadow-lg hover:-translate-y-1 transition-all duration-200"
              >`;
const problemLinkEnd = `</Link>
            ))}`;

if (code.includes(problemLinkStart)) {
  const startIndex = code.indexOf(problemLinkStart);
  const endIndex = code.indexOf(problemLinkEnd, startIndex) + problemLinkEnd.length - 8; // subtract 8 for `\n            ))}`
  
  const problemOriginal = code.substring(startIndex, endIndex);
  
  const problemNew = `user ? (
              <Link
                key={p.slug}
                to="/problem/$slug"
                params={{ slug: p.slug }}
                className="group relative flex flex-col justify-between gap-3 rounded-2xl border border-border/80 bg-card/75 p-5 shadow-sm backdrop-blur-md hover:border-primary/50 hover:shadow-lg hover:-translate-y-1 transition-all duration-200"
              >
${problemOriginal.substring(problemLinkStart.length)}
              </Link>
            ) : (
              <Link
                key={p.slug}
                to="/auth"
                className="group relative flex flex-col justify-between gap-3 rounded-2xl border border-border/80 bg-card/75 p-5 shadow-sm backdrop-blur-md hover:border-primary/50 hover:shadow-lg hover:-translate-y-1 transition-all duration-200"
              >
${problemOriginal.substring(problemLinkStart.length)}
              </Link>
            )`;
  
  code = code.replace(problemOriginal, problemNew);
}

fs.writeFileSync('src/routes/index.tsx', code);
console.log("Patched index.tsx links");
