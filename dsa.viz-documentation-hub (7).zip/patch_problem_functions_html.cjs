const fs = require('fs');
let code = fs.readFileSync('src/lib/problem.functions.ts', 'utf8');

const replacement = `import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { statementForSlug } from "./statements.server";

export const getStatement = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (
      typeof input === "object" &&
      input !== null &&
      "slug" in input &&
      typeof (input as { slug?: unknown }).slug === "string"
    ) {
      return { slug: (input as { slug: string }).slug };
    }
    return z.object({ slug: z.string() }).parse(input);
  })
  .handler(async ({ data }) => {
    try {
      let statement = statementForSlug(data?.slug ?? "");
      
      if (!statement && data?.slug) {
        // Fetch from LeetCode GraphQL
        const res = await fetch("https://leetcode.com/graphql", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                query: \`query questionData($titleSlug: String!) {
                    question(titleSlug: $titleSlug) {
                        content
                    }
                }\`,
                variables: { titleSlug: data.slug }
            })
        });
        const json = await res.json();
        if (json?.data?.question?.content) {
            statement = json.data.question.content;
        }
      }

      return { statement };
    } catch (e) {
      console.error(e);
      return { statement: "" };
    }
  });`;

fs.writeFileSync('src/lib/problem.functions.ts', replacement);
console.log("Patched problem.functions.ts without turndown");
