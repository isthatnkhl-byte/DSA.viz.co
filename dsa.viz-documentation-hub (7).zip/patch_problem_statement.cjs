const fs = require('fs');
let code = fs.readFileSync('src/routes/problem.$slug.tsx', 'utf8');

if (!code.includes('import { getStatement } from "@/lib/problem.functions";')) {
  code = code.replace(
    'import { statementForSlug } from "@/lib/statements";',
    'import { statementForSlug } from "@/lib/statements";\nimport { getStatement } from "@/lib/problem.functions";'
  );
}

const findHookSection = `  const statement = loaderData?.statement || (problem?.slug ? statementForSlug(problem.slug) : "");`;

if (code.includes(findHookSection)) {
  const replaceHookSection = `  const initialStatement = loaderData?.statement || (problem?.slug ? statementForSlug(problem.slug) : "");
  const fetchStatement = useServerFn(getStatement);
  
  const { data: remoteStatement, isLoading: isStatementLoading } = useQuery({
    queryKey: ['problem-statement', problem?.slug],
    queryFn: () => fetchStatement({ data: { slug: problem?.slug || "" } }),
    enabled: !!problem?.slug && !initialStatement, // Only fetch if not already in JSON
    staleTime: Infinity,
  });

  const statement = initialStatement || (remoteStatement?.statement ?? "");
`;

  code = code.replace(findHookSection, replaceHookSection);
}

fs.writeFileSync('src/routes/problem.$slug.tsx', code);
console.log("Patched problem.$slug.tsx to fetch statement");
