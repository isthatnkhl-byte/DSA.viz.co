const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace('const app = express();\nconst PORT = 3000;', 'const app = express();\napp.set("trust proxy", 1);\nconst PORT = 3000;');

const apiLimiterMatch = `const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 100,
  message: { error: "Too many requests, please try again later." }
});`;

const apiLimiterReplace = `const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 100,
  message: { error: "Too many requests, please try again later." },
  validate: { trustProxy: false, xForwardedForHeader: false, forwardedHeader: false }
});`;

const aiLimiterMatch = `const aiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 5,
  message: { error: "AI rate limit exceeded. Max 5 requests per minute." }
});`;

const aiLimiterReplace = `const aiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 5,
  message: { error: "AI rate limit exceeded. Max 5 requests per minute." },
  validate: { trustProxy: false, xForwardedForHeader: false, forwardedHeader: false }
});`;

code = code.replace(apiLimiterMatch, apiLimiterReplace);
code = code.replace(aiLimiterMatch, aiLimiterReplace);

fs.writeFileSync('server.ts', code);
console.log("Patched proxy and ratelimits");
