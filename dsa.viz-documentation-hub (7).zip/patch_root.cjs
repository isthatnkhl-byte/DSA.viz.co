const fs = require('fs');
let code = fs.readFileSync('src/routes/__root.tsx', 'utf8');

if (!code.includes('AuthGuard')) {
    code = code.replace('import { AuthProvider } from "@/hooks/useAuth";', 'import { AuthProvider } from "@/hooks/useAuth";\nimport { AuthGuard } from "@/components/AuthGuard";');
    code = code.replace('<Outlet />', '<AuthGuard><Outlet /></AuthGuard>');
    fs.writeFileSync('src/routes/__root.tsx', code);
    console.log("Patched __root.tsx");
} else {
    console.log("Already patched");
}
