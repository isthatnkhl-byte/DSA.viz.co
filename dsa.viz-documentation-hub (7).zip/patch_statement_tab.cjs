const fs = require('fs');
let code = fs.readFileSync('src/components/problem/ProblemStatementTab.tsx', 'utf8');

if (!code.includes('rehypeRaw')) {
  code = code.replace(
    'import ReactMarkdown from "react-markdown";',
    'import ReactMarkdown from "react-markdown";\nimport rehypeRaw from "rehype-raw";'
  );
  
  code = code.replace(
    '<ReactMarkdown>{statement}</ReactMarkdown>',
    '<ReactMarkdown rehypePlugins={[rehypeRaw]}>{statement}</ReactMarkdown>'
  );
  
  fs.writeFileSync('src/components/problem/ProblemStatementTab.tsx', code);
  console.log("Patched ProblemStatementTab.tsx");
}
