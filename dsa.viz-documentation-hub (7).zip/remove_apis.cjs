const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// The file APIs block starts around app.get("/api/files/tree" and ends before // API: Execute C++ code or // Generate Image endpoint
// Let's just use regex to remove each app.get/app.post for /api/files/* and /api/compiler/execute

// Find start of file apis:
const fileStart = code.indexOf('// --- File System APIs ---');
const fileEnd = code.indexOf('// API: Execute C++ code');

if (fileStart !== -1 && fileEnd !== -1) {
    code = code.substring(0, fileStart) + code.substring(fileEnd);
} else {
    console.log("Could not find file APIs block by comments.");
}

const compStart = code.indexOf('// API: Execute C++ code');
const compEnd = code.indexOf('// --- Image Generation API ---');

if (compStart !== -1 && compEnd !== -1) {
    code = code.substring(0, compStart) + code.substring(compEnd);
} else {
    console.log("Could not find compiler block by comments.");
}

fs.writeFileSync('server.ts', code);
console.log("Removed sections.");
