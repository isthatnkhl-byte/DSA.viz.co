import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  Trophy,
  Sparkles,
  Target,
  ArrowLeft,
  RefreshCw,
  Save,
  Flame,
  Calendar,
  Code2,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  Edit2,
  Database,
  Layers,
  Award,
  BarChart2,
} from "lucide-react";
import { useState, useMemo } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import {
  getProfileStats,
  syncLeetCodeData,
  updateLeetcodeUsername,
} from "@/lib/submissions.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Profile & LeetCode Connect — DSA.viz" },
      {
        name: "description",
        content: "Track your connected LeetCode profile, heatmap, and algorithmic attempts.",
      },
      { property: "og:title", content: "Profile & LeetCode Connect — DSA.viz" },
      {
        property: "og:description",
        content: "Your connected LeetCode profile progress and submission history.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProfilePage,
});

/** Interactive 52-Week Submission Activity Heatmap */
function LeetCodeHeatmap({
  calendar,
  streak = 0,
  totalActiveDays = 0,
}: {
  calendar: Record<string, number>;
  streak?: number;
  totalActiveDays?: number;
}) {
  const [hoveredCell, setHoveredCell] = useState<{ date: string; count: number } | null>(null);

  // Generate 52 weeks (7 days x 52 weeks) ending today
  const { weeks, totalSubmissionsYear, maxDaily } = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const days: { date: Date; dateStr: string; timestampSec: number; count: number }[] = [];
    const totalDays = 52 * 7;

    let totalSubmissions = 0;
    let max = 0;

    for (let i = totalDays - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const timestampSec = Math.floor(d.getTime() / 1000);
      const dateStr = d.toISOString().split("T")[0]!;

      // LeetCode calendar maps UNIX timestamp (seconds) to count
      // Also check exact timestamp or nearest within day
      let count = calendar[String(timestampSec)] || 0;
      if (!count) {
        // Search matching day in calendar keys
        for (const [k, v] of Object.entries(calendar)) {
          const keyNum = Number(k);
          if (Math.abs(keyNum - timestampSec) < 43200) {
            count = Number(v) || 0;
            break;
          }
        }
      }

      totalSubmissions += count;
      if (count > max) max = count;

      days.push({ date: d, dateStr, timestampSec, count });
    }

    const weekList: (typeof days)[] = [];
    for (let w = 0; w < 52; w++) {
      weekList.push(days.slice(w * 7, (w + 1) * 7));
    }

    return {
      weeks: weekList,
      totalSubmissionsYear: totalSubmissions,
      maxDaily: max,
    };
  }, [calendar]);

  function getIntensityClass(count: number) {
    if (count === 0) return "bg-muted/30 border-transparent hover:border-border";
    if (count <= 2) return "bg-emerald-500/40 border-emerald-500/50";
    if (count <= 5) return "bg-emerald-500/70 border-emerald-400";
    if (count <= 9) return "bg-emerald-400 border-emerald-300 shadow-xs shadow-emerald-400/40";
    return "bg-emerald-300 border-emerald-200 shadow-sm shadow-emerald-300/60";
  }

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border/80 bg-background/60 p-4 shadow-sm backdrop-blur-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/40 pb-2.5">
        <div className="flex items-center gap-2">
          <Calendar className="size-4 text-primary" />
          <span className="font-mono text-xs font-bold uppercase tracking-wider text-foreground">
            Submission Activity Heatmap (Past 12 Months)
          </span>
        </div>
        <div className="flex items-center gap-3 font-mono text-[11px]">
          <span className="text-muted-foreground">
            Total: <strong className="text-primary">{totalSubmissionsYear}</strong> submissions
          </span>
          <span className="text-muted-foreground">
            Active: <strong className="text-emerald-400">{totalActiveDays}</strong> days
          </span>
          <span className="flex items-center gap-1 font-bold text-orange-400">
            <Flame className="size-3.5 fill-orange-400 text-orange-400" />
            <span>{streak} Day Streak</span>
          </span>
        </div>
      </div>

      {/* Grid Canvas */}
      <div className="overflow-x-auto pb-1">
        <div className="flex gap-1 min-w-[620px] py-1">
          {weeks.map((week, wIdx) => (
            <div key={`week-${wIdx}`} className="flex flex-col gap-1">
              {week.map((day) => (
                <div
                  key={`day-${day.dateStr}`}
                  onMouseEnter={() => setHoveredCell({ date: day.dateStr, count: day.count })}
                  onMouseLeave={() => setHoveredCell(null)}
                  className={`size-3 rounded-xs border transition-all cursor-pointer ${getIntensityClass(
                    day.count,
                  )}`}
                />
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Footer Legend & Tooltip */}
      <div className="flex items-center justify-between text-[10px] font-mono text-muted-foreground">
        <div>
          {hoveredCell ? (
            <span className="text-foreground font-semibold">
              📅 {hoveredCell.date}: <strong>{hoveredCell.count}</strong> submission{hoveredCell.count === 1 ? "" : "s"}
            </span>
          ) : (
            <span>Hover over any day to see submissions</span>
          )}
        </div>
        <div className="flex items-center gap-1.5">
          <span>Less</span>
          <div className="size-2.5 rounded-xs bg-muted/30 border border-border/40" />
          <div className="size-2.5 rounded-xs bg-emerald-500/40" />
          <div className="size-2.5 rounded-xs bg-emerald-500/70" />
          <div className="size-2.5 rounded-xs bg-emerald-400" />
          <div className="size-2.5 rounded-xs bg-emerald-300" />
          <span>More</span>
        </div>
      </div>
    </div>
  );
}

function ProfilePage() {
  const { user } = useAuth();
  const fetchStats = useServerFn(getProfileStats);
  const syncLeetCodeFn = useServerFn(syncLeetCodeData);
  const updateUsernameFn = useServerFn(updateLeetcodeUsername);
  const queryClient = useQueryClient();

  const [inputUsername, setInputUsername] = useState("");
  const [editingLc, setEditingLc] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["profile-stats"],
    queryFn: () => fetchStats(),
  });

  const syncMutation = useMutation({
    mutationFn: (username: string) => syncLeetCodeFn({ data: { username } }),
    onSuccess: (res) => {
      if (res.ok) {
        toast.success("LeetCode profile & heatmap synced with Supabase!");
        queryClient.invalidateQueries({ queryKey: ["profile-stats"] });
        setEditingLc(false);
        setInputUsername("");
      } else {
        toast.error(res.error || "Could not find LeetCode account.");
      }
    },
    onError: (err: any) => {
      toast.error(err?.message || "Sync failed.");
    },
  });

  const profile = data?.profile;
  const leetcodeStats = (profile as any)?.leetcode_stats;
  const leetcodeUsername = (profile as any)?.leetcode_username;

  function handleConnectOrSync(overrideUsername?: string) {
    const target = (overrideUsername ?? inputUsername ?? leetcodeUsername ?? "").trim();
    if (!target) {
      toast.error("Please enter a valid LeetCode username.");
      return;
    }
    syncMutation.mutate(target);
  }

  return (
    <div className="min-h-screen pb-20">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl px-4 py-8 sm:px-6">
        <Link
          to="/"
          className="group mb-6 inline-flex items-center gap-1.5 font-mono text-xs text-muted-foreground hover:text-primary transition-colors"
        >
          <ArrowLeft className="size-3.5 transition-transform group-hover:-translate-x-1" />
          <span>Back to Problem Explorer</span>
        </Link>

        {isLoading || !data ? (
          <div className="flex min-h-[320px] flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border/80 bg-card/40 p-8 text-center animate-pulse">
            <Trophy className="size-8 text-primary animate-bounce" />
            <p className="font-mono text-sm text-muted-foreground">
              Loading your profile &amp; Supabase data…
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-6 animate-rise">
            {/* User Profile Header Card */}
            <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-border/80 bg-card/75 p-6 shadow-sm backdrop-blur-sm">
              <div className="flex items-center gap-4">
                {profile?.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt={`${profile.display_name ?? "User"} avatar`}
                    className="size-16 rounded-2xl border-2 border-primary/40 shadow-sm"
                  />
                ) : (
                  <div className="flex size-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30 text-2xl font-black text-primary shadow-sm">
                    {(profile?.display_name ?? user?.email ?? "?").charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <h2 className="text-2xl font-black tracking-tight text-foreground">
                      {profile?.display_name ?? "Algorithm Explorer"}
                    </h2>
                    <span className="rounded-full border border-primary/40 bg-primary/10 px-2.5 py-0.5 font-mono text-[10px] font-bold text-primary">
                      SUPABASE SYNCED
                    </span>
                  </div>
                  <p className="font-mono text-xs text-muted-foreground mt-0.5">
                    {user?.email ? user.email : "Authenticated User"} • Member since{" "}
                    {new Date(profile?.created_at ?? Date.now()).toLocaleDateString()}
                  </p>
                </div>
              </div>

              {/* Local Attempt Counter */}
              <div className="flex items-center gap-3">
                <div className="flex flex-col items-end">
                  <span className="text-[10px] uppercase font-mono font-bold text-muted-foreground">
                    DSA.viz Attempts
                  </span>
                  <span className="text-xl font-mono font-black text-primary">
                    {data.attempts}
                  </span>
                </div>
              </div>
            </div>

            {/* ------------------------------------------------------------------ */}
            {/* CONNECT WITH LEETCODE MODULE                                       */}
            {/* ------------------------------------------------------------------ */}
            <div className="flex flex-col gap-5 rounded-2xl border border-border/80 bg-card/75 p-6 shadow-sm backdrop-blur-sm">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="flex size-9 items-center justify-center rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400">
                    <Target className="size-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground flex items-center gap-2">
                      <span>LeetCode Profile &amp; Heatmap Integration</span>
                      {leetcodeUsername && (
                        <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 font-mono text-[10px] font-bold text-emerald-400 border border-emerald-500/30">
                          CONNECTED
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      Connect your LeetCode handle to pull activity heatmaps, global rankings, and problem statistics saved to Supabase.
                    </p>
                  </div>
                </div>

                {leetcodeUsername && !editingLc && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleConnectOrSync(leetcodeUsername)}
                      disabled={syncMutation.isPending}
                      className="h-8 gap-1.5 font-mono text-xs border-primary/40 hover:bg-primary/10 text-primary"
                    >
                      <RefreshCw
                        className={`size-3.5 ${syncMutation.isPending ? "animate-spin" : ""}`}
                      />
                      <span>Sync Data</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setInputUsername(leetcodeUsername);
                        setEditingLc(true);
                      }}
                      className="h-8 font-mono text-xs text-muted-foreground"
                    >
                      <Edit2 className="size-3.5 mr-1" /> Switch Account
                    </Button>
                  </div>
                )}
              </div>

              {/* Connected LeetCode Dashboard View */}
              {leetcodeStats && !editingLc ? (
                <div className="flex flex-col gap-6 animate-rise">
                  {/* Account Header & Overview Banner */}
                  <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-border/70 bg-background/50 p-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={leetcodeStats.avatar || "https://leetcode.com/static/images/LeetCode_logo.png"}
                        alt="LeetCode Avatar"
                        className="size-11 rounded-xl border border-border/60 shadow-xs"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-base font-bold text-foreground">
                            {leetcodeStats.name || leetcodeStats.username}
                          </h4>
                          <a
                            href={`https://leetcode.com/u/${leetcodeStats.username}/`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-primary transition-colors"
                            title="Open LeetCode Profile"
                          >
                            <ExternalLink className="size-3.5" />
                          </a>
                        </div>
                        <div className="font-mono text-xs text-muted-foreground">
                          @{leetcodeStats.username} • Global Rank:{" "}
                          <strong className="text-foreground font-bold">{leetcodeStats.ranking}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="flex items-center gap-1 rounded-lg border border-orange-500/30 bg-orange-500/10 px-2.5 py-1 font-mono text-xs font-bold text-orange-400">
                        <Flame className="size-4 fill-orange-400" />
                        <span>Streak: {leetcodeStats.streak || 0}d</span>
                      </span>
                      <span className="flex items-center gap-1 rounded-lg border border-primary/30 bg-primary/10 px-2.5 py-1 font-mono text-xs font-bold text-primary">
                        <Award className="size-4" />
                        <span>Reputation: {leetcodeStats.reputation || 0}</span>
                      </span>
                    </div>
                  </div>

                  {/* Problem Solving Counts Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="flex flex-col justify-between rounded-xl border border-border/70 bg-background/70 p-3.5 shadow-xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                        Total Solved
                      </span>
                      <div className="mt-2 flex items-baseline justify-between">
                        <span className="font-mono text-2xl font-black text-primary">
                          {leetcodeStats.totalSolved}
                        </span>
                        <span className="font-mono text-[11px] text-muted-foreground">
                          / {leetcodeStats.totalQuestions}
                        </span>
                      </div>
                      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted/40">
                        <div
                          className="h-full bg-primary rounded-full transition-all"
                          style={{
                            width: `${Math.min(
                              100,
                              Math.round(
                                (leetcodeStats.totalSolved / (leetcodeStats.totalQuestions || 3000)) *
                                  100,
                              ),
                            )}%`,
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex flex-col justify-between rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3.5 shadow-xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                        Easy Solved
                      </span>
                      <div className="mt-2 flex items-baseline justify-between">
                        <span className="font-mono text-2xl font-black text-emerald-400">
                          {leetcodeStats.easySolved}
                        </span>
                        <span className="font-mono text-[11px] text-muted-foreground">
                          / {leetcodeStats.totalEasy}
                        </span>
                      </div>
                      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted/40">
                        <div
                          className="h-full bg-emerald-500 rounded-full transition-all"
                          style={{
                            width: `${Math.min(
                              100,
                              Math.round(
                                (leetcodeStats.easySolved / (leetcodeStats.totalEasy || 800)) * 100,
                              ),
                            )}%`,
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex flex-col justify-between rounded-xl border border-amber-500/30 bg-amber-500/5 p-3.5 shadow-xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                        Medium Solved
                      </span>
                      <div className="mt-2 flex items-baseline justify-between">
                        <span className="font-mono text-2xl font-black text-amber-400">
                          {leetcodeStats.mediumSolved}
                        </span>
                        <span className="font-mono text-[11px] text-muted-foreground">
                          / {leetcodeStats.totalMedium}
                        </span>
                      </div>
                      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted/40">
                        <div
                          className="h-full bg-amber-500 rounded-full transition-all"
                          style={{
                            width: `${Math.min(
                              100,
                              Math.round(
                                (leetcodeStats.mediumSolved / (leetcodeStats.totalMedium || 1700)) *
                                  100,
                              ),
                            )}%`,
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex flex-col justify-between rounded-xl border border-rose-500/30 bg-rose-500/5 p-3.5 shadow-xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                        Hard Solved
                      </span>
                      <div className="mt-2 flex items-baseline justify-between">
                        <span className="font-mono text-2xl font-black text-rose-400">
                          {leetcodeStats.hardSolved}
                        </span>
                        <span className="font-mono text-[11px] text-muted-foreground">
                          / {leetcodeStats.totalHard}
                        </span>
                      </div>
                      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted/40">
                        <div
                          className="h-full bg-rose-500 rounded-full transition-all"
                          style={{
                            width: `${Math.min(
                              100,
                              Math.round(
                                (leetcodeStats.hardSolved / (leetcodeStats.totalHard || 700)) * 100,
                              ),
                            )}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Submission Calendar Activity Heatmap */}
                  <LeetCodeHeatmap
                    calendar={leetcodeStats.submissionCalendar || {}}
                    streak={leetcodeStats.streak}
                    totalActiveDays={leetcodeStats.totalActiveDays}
                  />

                  {/* Recent Submissions Log */}
                  {Array.isArray(leetcodeStats.recentSubmissions) &&
                    leetcodeStats.recentSubmissions.length > 0 && (
                      <div className="flex flex-col gap-2.5 rounded-2xl border border-border/80 bg-background/60 p-4 shadow-sm backdrop-blur-sm">
                        <div className="flex items-center justify-between border-b border-border/40 pb-2">
                          <div className="flex items-center gap-2">
                            <Code2 className="size-4 text-primary" />
                            <span className="font-mono text-xs font-bold uppercase tracking-wider text-foreground">
                              Recent LeetCode Submissions
                            </span>
                          </div>
                          <span className="font-mono text-[10px] text-muted-foreground">
                            Last synced:{" "}
                            {new Date(leetcodeStats.lastSyncedAt || Date.now()).toLocaleTimeString()}
                          </span>
                        </div>

                        <div className="divide-y divide-border/40">
                          {leetcodeStats.recentSubmissions.map((sub: any, idx: number) => {
                            const isAccepted = sub.statusDisplay === "Accepted";
                            return (
                              <div
                                key={`sub-${idx}`}
                                className="flex items-center justify-between py-2 text-xs font-mono"
                              >
                                <div className="flex items-center gap-2">
                                  {isAccepted ? (
                                    <CheckCircle2 className="size-4 text-emerald-400 shrink-0" />
                                  ) : (
                                    <XCircle className="size-4 text-rose-400 shrink-0" />
                                  )}
                                  <span className="font-bold text-foreground">{sub.title}</span>
                                </div>

                                <div className="flex items-center gap-3">
                                  <span
                                    className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                                      isAccepted
                                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                                        : "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                                    }`}
                                  >
                                    {sub.statusDisplay}
                                  </span>
                                  <span className="rounded bg-muted/40 px-1.5 py-0.5 text-[10px] text-muted-foreground">
                                    {sub.lang}
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                </div>
              ) : (
                /* Connect Input Form */
                <div className="flex flex-col gap-4 rounded-xl border border-dashed border-border/80 bg-background/40 p-6 text-center">
                  <div className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-orange-500/15 text-orange-400 border border-orange-500/30">
                    <Target className="size-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-foreground">
                      Connect Your LeetCode Account
                    </h4>
                    <p className="text-xs text-muted-foreground mt-1 max-w-md mx-auto">
                      Enter your public LeetCode handle to synchronize your problem-solving streak, 52-week activity heatmap, and recent submission telemetry saved directly on Supabase.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-2 max-w-md mx-auto w-full pt-2">
                    <Input
                      placeholder="e.g. neetcode, tourist, your_handle"
                      value={inputUsername}
                      onChange={(e) => setInputUsername(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleConnectOrSync();
                      }}
                      className="font-mono text-sm h-10"
                    />
                    <Button
                      onClick={() => handleConnectOrSync()}
                      disabled={syncMutation.isPending || !inputUsername.trim()}
                      className="h-10 px-5 font-bold font-mono text-xs gap-2 shrink-0 bg-primary text-primary-foreground"
                    >
                      {syncMutation.isPending ? (
                        <>
                          <RefreshCw className="size-3.5 animate-spin" />
                          <span>Connecting…</span>
                        </>
                      ) : (
                        <>
                          <Save className="size-3.5" />
                          <span>Connect Account</span>
                        </>
                      )}
                    </Button>
                  </div>

                  {editingLc && leetcodeUsername && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEditingLc(false)}
                      className="text-xs font-mono text-muted-foreground hover:text-foreground self-center"
                    >
                      Cancel &amp; Keep Current Account ({leetcodeUsername})
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default ProfilePage;
