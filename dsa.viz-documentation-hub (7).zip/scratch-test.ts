import {
  raceModels,
  REVIEW_MODELS,
  getOpenRouterKey,
  getGeminiKey,
} from "./src/lib/openrouter.server";

async function testApi() {
  const orKey = getOpenRouterKey();
  const gemKey = getGeminiKey();
  console.log("OpenRouter Key:", orKey ? `Found (length ${orKey.length})` : "Not found");
  console.log("Gemini Key:", gemKey ? `Found (length ${gemKey.length})` : "Not found");

  if (!orKey && !gemKey) {
    console.log("No keys found! Exiting.");
    return;
  }

  console.log("\nRunning raceModels with a test prompt...");
  const systemPrompt = "You are a test bot. Output JSON with a 'message' field.";
  const userPrompt = "Say hello world.";
  const okFn = (json: any) => typeof json?.message === "string";

  const { json, model, error } = await raceModels(
    REVIEW_MODELS.slice(0, 5), // Try first 5 models
    orKey || gemKey, // Fallback key if needed
    systemPrompt,
    userPrompt,
    okFn,
  );

  console.log("\n--- RESULT ---");
  console.log("Model:", model);
  console.log("JSON:", json);
  console.log("Error:", error);
}

testApi().catch(console.error);
