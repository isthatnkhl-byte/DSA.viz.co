import {
  raceModels,
  REVIEW_MODELS,
  getOpenRouterKey,
  getGeminiKey,
} from "./src/lib/openrouter.server";

async function testApi() {
  const orKey = getOpenRouterKey();
  const gemKey = getGeminiKey();
  const systemPrompt = "You are a test bot. Output JSON with a 'message' field.";
  const userPrompt = "Say hello world.";
  const okFn = (json: any) => typeof json?.message === "string";

  // Modify queryModelWithFallbacks locally to log attempts
  // We can just import and run it, but let's test a specific OpenRouter model
  const { json, model, error } = await raceModels(
    ["nvidia/nemotron-3.5-lightning:free", "google/gemini-2.0-flash-001"],
    orKey || gemKey,
    systemPrompt,
    userPrompt,
    okFn,
  );

  console.log("\n--- RESULT ---");
  console.log("Model:", model);
  console.log("JSON:", json);
  console.log("Error:", error);
}

testApi().catch(console.error);
