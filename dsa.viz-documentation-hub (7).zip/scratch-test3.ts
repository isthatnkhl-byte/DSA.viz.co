import {
  raceModels,
  REVIEW_MODELS,
  getOpenRouterKey,
  getGeminiKey,
} from "./src/lib/openrouter.server";

async function testApi() {
  const orKey = getOpenRouterKey();
  const gemKey = getGeminiKey();
  const systemPrompt = "You are a test bot. Output JSON with a 'message' field.";
  const userPrompt = "Say hello world.";
  const okFn = (json: any) => typeof json?.message === "string";

  const { json, model, error } = await raceModels(
    REVIEW_MODELS,
    orKey || gemKey,
    systemPrompt,
    userPrompt,
    okFn,
  );

  console.log("\n--- RESULT ---");
  console.log("Model:", model);
  console.log("JSON:", json);
  console.log("Error:", error);
}

testApi().catch(console.error);
