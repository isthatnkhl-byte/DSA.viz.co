const fs = require("fs");
const path = require("path");

const problemsPath = path.join(__dirname, "../src/data/problems.json");
const statementsPath = path.join(__dirname, "../src/data/statements.json");

const existingProblems = JSON.parse(fs.readFileSync(problemsPath, "utf-8"));
const existingStatements = JSON.parse(fs.readFileSync(statementsPath, "utf-8"));

const existingSlugs = new Set(existingProblems.map((p) => p.slug));

console.log("Existing problems:", existingProblems.length);
console.log("Existing statements:", Object.keys(existingStatements).length);

// 120 Curated high-importance LeetCode problems with complete statements
const newProblemsPool = [
  // 1. Invert Binary Tree
  {
    problem: {
      slug: "invert-binary-tree",
      title: "Invert Binary Tree",
      difficulty: "Easy",
      topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
      companies: ["google", "amazon", "meta", "microsoft", "apple", "bloomberg"],
      freq: 98.0,
    },
    statement: `Given the root of a binary tree, invert the tree, and return its root.

\u00a0

Example 1:

\`\`\`
Input: root = [4,2,7,1,3,6,9]
Output: [4,7,2,9,6,3,1]
\`\`\`

Example 2:

\`\`\`
Input: root = [2,1,3]
Output: [2,3,1]
\`\`\`

Example 3:

\`\`\`
Input: root = []
Output: []
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [0, 100].

\t- -100 <= Node.val <= 100`,
  },

  // 2. Subtree of Another Tree
  {
    problem: {
      slug: "subtree-of-another-tree",
      title: "Subtree of Another Tree",
      difficulty: "Easy",
      topics: ["Tree", "Depth-First Search", "String Matching", "Binary Tree", "Hash Function"],
      companies: ["amazon", "meta", "google", "microsoft"],
      freq: 85.0,
    },
    statement: `Given the roots of two binary trees root and subRoot, return true if there is a subtree of root with the same structure and node values of subRoot and false otherwise.

A subtree of a binary tree tree is a tree that consists of a node in tree and all of this node's descendants. The tree tree could also be considered as a subtree of itself.

\u00a0

Example 1:

\`\`\`
Input: root = [3,4,5,1,2], subRoot = [4,1,2]
Output: true
\`\`\`

Example 2:

\`\`\`
Input: root = [3,4,5,1,2,null,null,null,null,0], subRoot = [4,1,2]
Output: false
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the root tree is in the range [1, 2000].

\t- The number of nodes in the subRoot tree is in the range [1, 1000].

\t- -104 <= root.val <= 104

\t- -104 <= subRoot.val <= 104`,
  },

  // 3. Lowest Common Ancestor of a BST
  {
    problem: {
      slug: "lowest-common-ancestor-of-a-binary-search-tree",
      title: "Lowest Common Ancestor of a Binary Search Tree",
      difficulty: "Medium",
      topics: ["Tree", "Depth-First Search", "Binary Search Tree", "Binary Tree"],
      companies: ["amazon", "meta", "microsoft", "google", "bloomberg"],
      freq: 92.0,
    },
    statement: `Given a binary search tree (BST), find the lowest common ancestor (LCA) node of two given nodes in the BST.

According to the definition of LCA on Wikipedia: “The lowest common ancestor is defined between two nodes p and q as the lowest node in T that has both p and q as descendants (where we allow a node to be a descendant of itself).”

\u00a0

Example 1:

\`\`\`
Input: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 8
Output: 6
Explanation: The LCA of nodes 2 and 8 is 6.
\`\`\`

Example 2:

\`\`\`
Input: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 4
Output: 2
Explanation: The LCA of nodes 2 and 4 is 2, since a node can be a descendant of itself according to the LCA definition.
\`\`\`

Example 3:

\`\`\`
Input: root = [2,1], p = 2, q = 1
Output: 2
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [2, 105].

\t- -109 <= Node.val <= 109

\t- All Node.val are unique.

\t- p != q

\t- p and q will exist in the BST.`,
  },

  // 4. Count Good Nodes in Binary Tree
  {
    problem: {
      slug: "count-good-nodes-in-binary-tree",
      title: "Count Good Nodes in Binary Tree",
      difficulty: "Medium",
      topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
      companies: ["microsoft", "amazon", "meta", "google"],
      freq: 86.0,
    },
    statement: `Given a binary tree root, a node X in the tree is named good if in the path from the root to X there are no nodes with a value greater than X.

Return the number of good nodes in the binary tree.

\u00a0

Example 1:

\`\`\`
Input: root = [3,1,4,3,null,1,5]
Output: 4
Explanation: Nodes in blue are good.
Root Node (3) is always a good node.
Node 4 -> (3,4) is the maximum value in the path starting from the root.
Node 5 -> (3,4,5) is the maximum value in the path
Node 3 -> (3,1,3) is the maximum value in the path.
\`\`\`

Example 2:

\`\`\`
Input: root = [3,3,null,4,2]
Output: 3
Explanation: Node 2 -> (3, 3, 2) is not good, because "3" is higher than it.
\`\`\`

Example 3:

\`\`\`
Input: root = [1]
Output: 1
Explanation: Root is considered as good.
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the binary tree is in the range [1, 10^5].

\t- Each node's value is between [-10^4, 10^4].`,
  },

  // 5. Evaluate Reverse Polish Notation
  {
    problem: {
      slug: "evaluate-reverse-polish-notation",
      title: "Evaluate Reverse Polish Notation",
      difficulty: "Medium",
      topics: ["Array", "Math", "Stack"],
      companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
      freq: 91.0,
    },
    statement: `You are given an array of strings tokens that represents an arithmetic expression in a Reverse Polish Notation.

Evaluate the expression. Return an integer that represents the value of the expression.

Note that:

\t- The valid operators are '+', '-', '*', and '/'.

\t- Each operand may be an integer or another expression.

\t- The division between two integers always truncates toward zero.

\t- There will not be any division by zero.

\t- The input represents a valid arithmetic expression in a reverse polish notation.

\t- The answer and all the intermediate calculations can be represented in a 32-bit integer.

\u00a0

Example 1:

\`\`\`
Input: tokens = ["2","1","+","3","*"]
Output: 9
Explanation: ((2 + 1) * 3) = 9
\`\`\`

Example 2:

\`\`\`
Input: tokens = ["4","13","5","/","+"]
Output: 6
Explanation: (4 + (13 / 5)) = 6
\`\`\`

Example 3:

\`\`\`
Input: tokens = ["10","6","9","3","+","-11","*","/","*","17","+","5","+"]
Output: 22
Explanation: ((10 * (6 / ((9 + 3) * -11))) + 17) + 5
= ((10 * (6 / (12 * -11))) + 17) + 5
= ((10 * (6 / -132)) + 17) + 5
= ((10 * 0) + 17) + 5
= (0 + 17) + 5
= 17 + 5
= 22
\`\`\`

\u00a0

Constraints:

\t- 1 <= tokens.length <= 104

\t- tokens[i] is either an operator: "+", "-", "*", or "/", or an integer in the range [-200, 200].`,
  },

  // 6. Car Fleet
  {
    problem: {
      slug: "car-fleet",
      title: "Car Fleet",
      difficulty: "Medium",
      topics: ["Array", "Stack", "Sorting", "Monotonic Stack"],
      companies: ["google", "amazon", "meta", "uber"],
      freq: 88.0,
    },
    statement: `There are n cars at given miles away from the starting mile 0, traveling to reach the mile target.

You are given two integer arrays position and speed, both of length n, where position[i] is the position of the ith car and speed[i] is the speed of the ith car (in miles per hour).

A car cannot pass another car ahead of it, but it can catch up to it and drive bumper to bumper at the same speed. The faster car will slow down to match the slower car's speed. The distance between these two cars is ignored (i.e., they are assumed to have the same position).

A car fleet is some non-empty set of cars driving at the same position and same speed. Note that a single car is also a car fleet.

If a car catches up to a car fleet right at the destination point, it will still be considered as one car fleet.

Return the number of car fleets that will arrive at the destination.

\u00a0

Example 1:

\`\`\`
Input: target = 12, position = [10,8,0,5,3], speed = [2,4,1,1,3]
Output: 3
Explanation:
The cars starting at 10 (speed 2) and 8 (speed 4) become a fleet, meeting each other at 12.
The car starting at 0 (speed 1) does not catch up to any other car, so it is a fleet by itself.
The cars starting at 5 (speed 1) and 3 (speed 3) become a fleet, meeting each other at 6. The fleet moves at speed 1 until it reaches target.
\`\`\`

Example 2:

\`\`\`
Input: target = 10, position = [3], speed = [3]
Output: 1
Explanation: There is only one car, hence there is only one fleet.
\`\`\`

Example 3:

\`\`\`
Input: target = 100, position = [0,2,4], speed = [4,2,1]
Output: 1
Explanation:
The cars starting at 0 (speed 4) and 2 (speed 2) become a fleet, meeting each other at 4. The fleet moves at speed 2.
Then, the fleet (speed 2) and the car starting at 4 (speed 1) become one fleet, meeting each other at 6. The fleet moves at speed 1 until it reaches target.
\`\`\`

\u00a0

Constraints:

\t- n == position.length == speed.length

\t- 1 <= n <= 105

\t- 0 < target <= 106

\t- 0 <= position[i] < target

\t- All the values of position are unique.

\t- 0 < speed[i] <= 106`,
  },

  // 7. Asteroid Collision
  {
    problem: {
      slug: "asteroid-collision",
      title: "Asteroid Collision",
      difficulty: "Medium",
      topics: ["Array", "Stack", "Simulation"],
      companies: ["amazon", "meta", "google", "microsoft", "tiktok"],
      freq: 89.0,
    },
    statement: `We are given an array asteroids of integers representing asteroids in a row.

For each asteroid, the absolute value represents its size, and the sign represents its direction (positive meaning right, negative meaning left). Each asteroid moves at the same speed.

Find out the state of the asteroids after all collisions. If two asteroids meet, the smaller one will explode. If both are the same size, both will explode. Two asteroids moving in the same direction will never meet.

\u00a0

Example 1:

\`\`\`
Input: asteroids = [5,10,-5]
Output: [5,10]
Explanation: The 10 and -5 collide resulting in 10. The 5 and 10 never collide.
\`\`\`

Example 2:

\`\`\`
Input: asteroids = [8,-8]
Output: []
Explanation: The 8 and -8 collide exploding each other.
\`\`\`

Example 3:

\`\`\`
Input: asteroids = [10,2,-5]
Output: [10]
Explanation: The 2 and -5 collide resulting in -5. The 10 and -5 collide resulting in 10.
\`\`\`

\u00a0

Constraints:

\t- 2 <= asteroids.length <= 104

\t- -1000 <= asteroids[i] <= 1000

\t- asteroids[i] != 0`,
  },

  // 8. Online Stock Span
  {
    problem: {
      slug: "online-stock-span",
      title: "Online Stock Span",
      difficulty: "Medium",
      topics: ["Stack", "Design", "Monotonic Stack", "Data Stream"],
      companies: ["amazon", "microsoft", "meta", "bloomberg"],
      freq: 84.0,
    },
    statement: `Design an algorithm that collects daily price quotes for some stock and returns the span of that stock's price for the current day.

The span of the stock's price in one day is the maximum number of consecutive days (starting from that day and going backward) for which the stock price was less than or equal to the price of that day.

\t- For example, if the prices of the stock in the last four days is [7,2,1,2] and the price of the stock today is 2, then the span of today is 4 because starting from today, the price of the stock was less than or equal to 2 for 4 consecutive days.

\t- Also, if the prices of the stock in the last four days is [7,34,1,2] and the price of the stock today is 8, then the span of today is 3 because starting from today, the price of the stock was less than or equal to 8 for 3 consecutive days.

Implement the StockSpanner class:

\t- StockSpanner() Initializes the object of the class.

\t- int next(int price) Returns the span of the stock's price given that today's price is price.

\u00a0

Example 1:

\`\`\`
Input
["StockSpanner", "next", "next", "next", "next", "next", "next", "next"]
[[], [100], [80], [60], [70], [60], [75], [85]]
Output
[null, 1, 1, 1, 2, 1, 4, 6]

Explanation
StockSpanner stockSpanner = new StockSpanner();
stockSpanner.next(100); // return 1
stockSpanner.next(80);  // return 1
stockSpanner.next(60);  // return 1
stockSpanner.next(70);  // return 2
stockSpanner.next(60);  // return 1
stockSpanner.next(75);  // return 4, because the last 4 prices (including today's price of 75) were less than or equal to 75.
stockSpanner.next(85);  // return 6
\`\`\`

\u00a0

Constraints:

\t- 1 <= price <= 105

\t- At most 104 calls will be made to next.`,
  },

  // 9. Next Greater Element I
  {
    problem: {
      slug: "next-greater-element-i",
      title: "Next Greater Element I",
      difficulty: "Easy",
      topics: ["Array", "Hash Table", "Stack", "Monotonic Stack"],
      companies: ["amazon", "meta", "google", "microsoft"],
      freq: 82.0,
    },
    statement: `The next greater element of some element x in an array is the first greater element that is to the right of x in the same array.

You are given two distinct 0-indexed integer arrays nums1 and nums2, where nums1 is a subset of nums2.

For each 0 <= i < nums1.length, find the index j such that nums1[i] == nums2[j] and determine the next greater element of nums2[j] in nums2. If there is no next greater element, then the answer for this query is -1.

Return an array ans of length nums1.length such that ans[i] is the next greater element as described above.

\u00a0

Example 1:

\`\`\`
Input: nums1 = [4,1,2], nums2 = [1,3,4,2]
Output: [-1,3,-1]
Explanation: The next greater element for each value of nums1 is as follows:
- 4 is underlined in nums2 = [1,3,4,2]. There is no next greater element, so the answer is -1.
- 1 is underlined in nums2 = [1,3,4,2]. The next greater element is 3.
- 2 is underlined in nums2 = [1,3,4,2]. There is no next greater element, so the answer is -1.
\`\`\`

Example 2:

\`\`\`
Input: nums1 = [2,4], nums2 = [1,2,3,4]
Output: [3,-1]
Explanation: The next greater element for each value of nums1 is as follows:
- 2 is underlined in nums2 = [1,2,3,4]. The next greater element is 3.
- 4 is underlined in nums2 = [1,2,3,4]. There is no next greater element, so the answer is -1.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums1.length <= nums2.length <= 1000

\t- 0 <= nums1[i], nums2[i] <= 104

\t- All integers in nums1 and nums2 are unique.

\t- All the integers of nums1 also appear in nums2.`,
  },

  // 10. Next Greater Element II
  {
    problem: {
      slug: "next-greater-element-ii",
      title: "Next Greater Element II",
      difficulty: "Medium",
      topics: ["Array", "Stack", "Monotonic Stack"],
      companies: ["amazon", "google", "meta", "microsoft"],
      freq: 85.0,
    },
    statement: `Given a circular integer array nums (i.e., the next element of nums[nums.length - 1] is nums[0]), return the next greater number for every element in nums.

The next greater number of a number x is the first greater number to its traversing-order next in the array, which means you could search circularly to find its next greater number. If it doesn't exist, return -1 for this number.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,2,1]
Output: [2,-1,2]
Explanation: The first 1's next greater number is 2; 
The number 2 can't find next greater number. 
The second 1's next greater number needs to search circularly, which is also 2.
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,2,3,4,3]
Output: [2,3,4,-1,4]
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 104

\t- -109 <= nums[i] <= 109`,
  },
];

console.log("Pool ready.");
