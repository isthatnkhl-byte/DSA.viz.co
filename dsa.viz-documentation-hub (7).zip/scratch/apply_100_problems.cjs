const fs = require("fs");
const path = require("path");
const assert = require("assert");

const part1 = require("./part1_problems.cjs");
const part2 = require("./part2_problems.cjs");
const part3 = require("./part3_problems.cjs");
const part4 = require("./part4_problems.cjs");

const newQuestions = [...part1, ...part2, ...part3, ...part4];
assert.equal(newQuestions.length, 100, "Must be exactly 100 questions");

const problemsPath = path.join(__dirname, "../src/data/problems.json");
const statementsPath = path.join(__dirname, "../src/data/statements.json");

const existingProblems = JSON.parse(fs.readFileSync(problemsPath, "utf-8"));
const existingStatements = JSON.parse(fs.readFileSync(statementsPath, "utf-8"));

console.log("Initial problems count:", existingProblems.length);
console.log("Initial statements count:", Object.keys(existingStatements).length);

const updatedProblems = [...existingProblems];
const updatedStatements = { ...existingStatements };

const existingSlugs = new Set(existingProblems.map((p) => p.slug));

let addedCount = 0;
for (const item of newQuestions) {
  if (existingSlugs.has(item.slug)) {
    throw new Error(`Duplicate slug found: ${item.slug}`);
  }
  existingSlugs.add(item.slug);

  const problemObj = {
    slug: item.slug,
    title: item.title,
    difficulty: item.difficulty,
    topics: item.topics,
    companies: item.companies,
    freq: item.freq,
  };

  updatedProblems.push(problemObj);
  updatedStatements[item.slug] = item.statement;
  addedCount++;
}

fs.writeFileSync(problemsPath, JSON.stringify(updatedProblems, null, 2) + "\n", "utf-8");
fs.writeFileSync(statementsPath, JSON.stringify(updatedStatements, null, 2) + "\n", "utf-8");

console.log(`Successfully added ${addedCount} problems!`);
console.log("New total problems count:", updatedProblems.length);
console.log("New total statements count:", Object.keys(updatedStatements).length);
