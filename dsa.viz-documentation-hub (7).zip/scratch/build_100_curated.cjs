const fs = require("fs");
const path = require("path");

const problemsPath = path.join(__dirname, "../src/data/problems.json");
const statementsPath = path.join(__dirname, "../src/data/statements.json");

const existingProblems = JSON.parse(fs.readFileSync(problemsPath, "utf-8"));
const existingStatements = JSON.parse(fs.readFileSync(statementsPath, "utf-8"));
const existingSlugs = new Set(existingProblems.map((p) => p.slug));

console.log("Current problems count:", existingProblems.length);
console.log("Current statements count:", Object.keys(existingStatements).length);

// Curated array of new LeetCode questions
const questionsToAdd = [
  // 1. Invert Binary Tree
  {
    slug: "invert-binary-tree",
    title: "Invert Binary Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["google", "amazon", "meta", "microsoft", "apple", "bloomberg"],
    freq: 98.0,
    statement:
      "Given the root of a binary tree, invert the tree, and return its root.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [4,2,7,1,3,6,9]\nOutput: [4,7,2,9,6,3,1]\n```\n\nExample 2:\n\n```\nInput: root = [2,1,3]\nOutput: [2,3,1]\n```\n\nExample 3:\n\n```\nInput: root = []\nOutput: []\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 100].\n\n\t- -100 <= Node.val <= 100",
  },
  // 2. Subtree of Another Tree
  {
    slug: "subtree-of-another-tree",
    title: "Subtree of Another Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "String Matching", "Binary Tree", "Hash Function"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 85.0,
    statement:
      "Given the roots of two binary trees root and subRoot, return true if there is a subtree of root with the same structure and node values of subRoot and false otherwise.\n\nA subtree of a binary tree tree is a tree that consists of a node in tree and all of this node's descendants. The tree tree could also be considered as a subtree of itself.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,4,5,1,2], subRoot = [4,1,2]\nOutput: true\n```\n\nExample 2:\n\n```\nInput: root = [3,4,5,1,2,null,null,null,null,0], subRoot = [4,1,2]\nOutput: false\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the root tree is in the range [1, 2000].\n\n\t- The number of nodes in the subRoot tree is in the range [1, 1000].\n\n\t- -104 <= root.val <= 104\n\n\t- -104 <= subRoot.val <= 104",
  },
  // 3. Lowest Common Ancestor of a BST
  {
    slug: "lowest-common-ancestor-of-a-binary-search-tree",
    title: "Lowest Common Ancestor of a Binary Search Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "meta", "microsoft", "google", "bloomberg"],
    freq: 92.0,
    statement:
      "Given a binary search tree (BST), find the lowest common ancestor (LCA) node of two given nodes in the BST.\n\nAccording to the definition of LCA on Wikipedia: “The lowest common ancestor is defined between two nodes p and q as the lowest node in T that has both p and q as descendants (where we allow a node to be a descendant of itself).”\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 8\nOutput: 6\nExplanation: The LCA of nodes 2 and 8 is 6.\n```\n\nExample 2:\n\n```\nInput: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 4\nOutput: 2\nExplanation: The LCA of nodes 2 and 4 is 2, since a node can be a descendant of itself according to the LCA definition.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [2, 105].\n\n\t- -109 <= Node.val <= 109\n\n\t- All Node.val are unique.\n\n\t- p != q\n\n\t- p and q will exist in the BST.",
  },
  // 4. Count Good Nodes in Binary Tree
  {
    slug: "count-good-nodes-in-binary-tree",
    title: "Count Good Nodes in Binary Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["microsoft", "amazon", "meta", "google"],
    freq: 86.0,
    statement:
      "Given a binary tree root, a node X in the tree is named good if in the path from the root to X there are no nodes with a value greater than X.\n\nReturn the number of good nodes in the binary tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,1,4,3,null,1,5]\nOutput: 4\nExplanation: Root Node (3) is always a good node. Node 4 -> (3,4) is the max value. Node 5 -> (3,4,5) is the max value. Node 3 -> (3,1,3) is the max value.\n```\n\nExample 2:\n\n```\nInput: root = [3,3,null,4,2]\nOutput: 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the binary tree is in the range [1, 10^5].\n\n\t- Each node's value is between [-10^4, 10^4].",
  },
  // 5. Evaluate Reverse Polish Notation
  {
    slug: "evaluate-reverse-polish-notation",
    title: "Evaluate Reverse Polish Notation",
    difficulty: "Medium",
    topics: ["Array", "Math", "Stack"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 91.0,
    statement:
      'You are given an array of strings tokens that represents an arithmetic expression in a Reverse Polish Notation.\n\nEvaluate the expression. Return an integer that represents the value of the expression.\n\nNote that the valid operators are \'+\', \'-\', \'*\', and \'/\'. Each operand may be an integer or another expression. Division between two integers always truncates toward zero.\n\n\u00a0\n\nExample 1:\n\n```\nInput: tokens = ["2","1","+","3","*"]\nOutput: 9\nExplanation: ((2 + 1) * 3) = 9\n```\n\nExample 2:\n\n```\nInput: tokens = ["4","13","5","/","+"]\nOutput: 6\nExplanation: (4 + (13 / 5)) = 6\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= tokens.length <= 104\n\n\t- tokens[i] is either an operator: "+", "-", "*", or "/", or an integer in the range [-200, 200].',
  },
  // 6. Car Fleet
  {
    slug: "car-fleet",
    title: "Car Fleet",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Sorting", "Monotonic Stack"],
    companies: ["google", "amazon", "meta", "uber"],
    freq: 88.0,
    statement:
      "There are n cars at given miles away from the starting mile 0, traveling to reach the mile target.\n\nYou are given two integer arrays position and speed, both of length n, where position[i] is the position of the ith car and speed[i] is the speed of the ith car (in miles per hour).\n\nA car cannot pass another car ahead of it, but it can catch up to it and drive bumper to bumper at the same speed. Return the number of car fleets that will arrive at the destination.\n\n\u00a0\n\nExample 1:\n\n```\nInput: target = 12, position = [10,8,0,5,3], speed = [2,4,1,1,3]\nOutput: 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == position.length == speed.length\n\n\t- 1 <= n <= 105\n\n\t- 0 < target <= 106\n\n\t- 0 <= position[i] < target\n\n\t- 0 < speed[i] <= 106",
  },
  // 7. Online Stock Span
  {
    slug: "online-stock-span",
    title: "Online Stock Span",
    difficulty: "Medium",
    topics: ["Stack", "Design", "Monotonic Stack", "Data Stream"],
    companies: ["amazon", "microsoft", "meta", "bloomberg"],
    freq: 84.0,
    statement:
      'Design an algorithm that collects daily price quotes for some stock and returns the span of that stock\'s price for the current day.\n\nThe span of the stock\'s price in one day is the maximum number of consecutive days (starting from that day and going backward) for which the stock price was less than or equal to the price of that day.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["StockSpanner", "next", "next", "next", "next", "next", "next", "next"]\n[[], [100], [80], [60], [70], [60], [75], [85]]\nOutput\n[null, 1, 1, 1, 2, 1, 4, 6]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= price <= 105\n\n\t- At most 104 calls will be made to next.',
  },
  // 8. Next Greater Element I
  {
    slug: "next-greater-element-i",
    title: "Next Greater Element I",
    difficulty: "Easy",
    topics: ["Array", "Hash Table", "Stack", "Monotonic Stack"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 82.0,
    statement:
      "The next greater element of some element x in an array is the first greater element that is to the right of x in the same array.\n\nYou are given two distinct 0-indexed integer arrays nums1 and nums2, where nums1 is a subset of nums2.\n\nReturn an array ans of length nums1.length such that ans[i] is the next greater element as described above.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums1 = [4,1,2], nums2 = [1,3,4,2]\nOutput: [-1,3,-1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums1.length <= nums2.length <= 1000\n\n\t- 0 <= nums1[i], nums2[i] <= 104",
  },
  // 9. Next Greater Element II
  {
    slug: "next-greater-element-ii",
    title: "Next Greater Element II",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Monotonic Stack"],
    companies: ["amazon", "google", "meta", "microsoft"],
    freq: 85.0,
    statement:
      "Given a circular integer array nums, return the next greater number for every element in nums.\n\nThe next greater number of a number x is the first greater number to its traversing-order next in the array, which means you could search circularly to find its next greater number. If it doesn't exist, return -1 for this number.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,1]\nOutput: [2,-1,2]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 104\n\n\t- -109 <= nums[i] <= 109",
  },
  // 10. 132 Pattern
  {
    slug: "132-pattern",
    title: "132 Pattern",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Stack", "Monotonic Stack", "Ordered Set"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 81.0,
    statement:
      "Given an array of n integers nums, a 132 pattern is a subsequence of three integers nums[i], nums[j] and nums[k] such that i < j < k and nums[i] < nums[k] < nums[j].\n\nReturn true if there is a 132 pattern in nums, otherwise, return false.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,3,4]\nOutput: false\n```\n\nExample 2:\n\n```\nInput: nums = [3,1,4,2]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 2 * 105\n\n\t- -109 <= nums[i] <= 109",
  },
  // 11. Sum of Subarray Minimums
  {
    slug: "sum-of-subarray-minimums",
    title: "Sum of Subarray Minimums",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Stack", "Monotonic Stack"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 87.0,
    statement:
      "Given an array of integers arr, find the sum of min(b), where b ranges over every (contiguous) subarray of arr. Since the answer may be large, return the answer modulo 109 + 7.\n\n\u00a0\n\nExample 1:\n\n```\nInput: arr = [3,1,2,4]\nOutput: 17\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= arr.length <= 3 * 104\n\n\t- 1 <= arr[i] <= 3 * 104",
  },
  // 12. Maximal Rectangle
  {
    slug: "maximal-rectangle",
    title: "Maximal Rectangle",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming", "Stack", "Matrix", "Monotonic Stack"],
    companies: ["amazon", "google", "meta", "microsoft", "apple"],
    freq: 86.0,
    statement:
      'Given a rows x cols binary matrix filled with 0\'s and 1\'s, find the largest rectangle containing only 1\'s and return its area.\n\n\u00a0\n\nExample 1:\n\n```\nInput: matrix = [["1","0","1","0","0"],["1","0","1","1","1"],["1","1","1","1","1"],["1","0","0","1","0"]]\nOutput: 6\n```\n\n\u00a0\n\nConstraints:\n\n\t- rows == matrix.length\n\n\t- cols == matrix[i].length\n\n\t- 1 <= row, cols <= 200\n\n\t- matrix[i][j] is \'0\' or \'1\'.',
  },
  // 13. Remove Duplicates from Sorted Array II
  {
    slug: "remove-duplicates-from-sorted-array-ii",
    title: "Remove Duplicates from Sorted Array II",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers"],
    companies: ["meta", "amazon", "microsoft", "google"],
    freq: 89.0,
    statement:
      "Given an integer array nums sorted in non-decreasing order, remove some duplicates in-place such that each unique element appears at most twice. The relative order of the elements should be kept the same.\n\nReturn k after placing the final result in the first k slots of nums.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,1,2,2,3]\nOutput: 5, nums = [1,1,2,2,3,_]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 3 * 104\n\n\t- -104 <= nums[i] <= 104",
  },
  // 14. Ransom Note
  {
    slug: "ransom-note",
    title: "Ransom Note",
    difficulty: "Easy",
    topics: ["Hash Table", "String", "Counting"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 90.0,
    statement:
      'Given two strings ransomNote and magazine, return true if ransomNote can be constructed by using the letters from magazine and false otherwise.\n\nEach letter in magazine can only be used once in ransomNote.\n\n\u00a0\n\nExample 1:\n\n```\nInput: ransomNote = "a", magazine = "b"\nOutput: false\n```\n\nExample 2:\n\n```\nInput: ransomNote = "aa", magazine = "ab"\nOutput: false\n```\n\nExample 3:\n\n```\nInput: ransomNote = "aa", magazine = "aab"\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= ransomNote.length, magazine.length <= 105\n\n\t- ransomNote and magazine consist of lowercase English letters.',
  },
  // 15. H-Index
  {
    slug: "h-index",
    title: "H-Index",
    difficulty: "Medium",
    topics: ["Array", "Sorting", "Counting Sort"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 87.0,
    statement:
      "Given an array of integers citations where citations[i] is the number of citations a researcher received for their ith paper, return the researcher's h-index.\n\n\u00a0\n\nExample 1:\n\n```\nInput: citations = [3,0,6,1,5]\nOutput: 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == citations.length\n\n\t- 1 <= n <= 5000\n\n\t- 0 <= citations[i] <= 1000",
  },
  // 16. Candy
  {
    slug: "candy",
    title: "Candy",
    difficulty: "Hard",
    topics: ["Array", "Greedy"],
    companies: ["google", "amazon", "meta", "microsoft", "apple"],
    freq: 90.0,
    statement:
      "There are n children standing in a line. Each child is assigned a rating value given in the integer array ratings.\n\nYou are giving candies to these children subjected to the following requirements:\n\n\t- Each child must have at least one candy.\n\n\t- Children with a higher rating get more candies than their neighbors.\n\nReturn the minimum number of candies you need to have to distribute the candies to the children.\n\n\u00a0\n\nExample 1:\n\n```\nInput: ratings = [1,0,2]\nOutput: 5\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == ratings.length\n\n\t- 1 <= n <= 2 * 104\n\n\t- 0 <= ratings[i] <= 2 * 104",
  },
  // 17. Minimum Size Subarray Sum
  {
    slug: "minimum-size-subarray-sum",
    title: "Minimum Size Subarray Sum",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Sliding Window", "Prefix Sum"],
    companies: ["meta", "amazon", "google", "microsoft", "apple"],
    freq: 89.0,
    statement:
      "Given an array of positive integers nums and a positive integer target, return the minimal length of a subarray whose sum is greater than or equal to target. If there is no such subarray, return 0 instead.\n\n\u00a0\n\nExample 1:\n\n```\nInput: target = 7, nums = [2,3,1,2,4,3]\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= target <= 109\n\n\t- 1 <= nums.length <= 105\n\n\t- 1 <= nums[i] <= 104",
  },
  // 18. Substring with Concatenation of All Words
  {
    slug: "substring-with-concatenation-of-all-words",
    title: "Substring with Concatenation of All Words",
    difficulty: "Hard",
    topics: ["Hash Table", "String", "Sliding Window"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 80.0,
    statement:
      'You are given a string s and an array of strings words. All the strings of words are of the same length.\n\nReturn an array of the starting indices of all the concatenated substrings in s. You can return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "barfoothefoobarman", words = ["foo","bar"]\nOutput: [0,9]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 104\n\n\t- 1 <= words.length <= 5000\n\n\t- 1 <= words[i].length <= 30',
  },
  // 19. 3Sum Closest
  {
    slug: "3sum-closest",
    title: "3Sum Closest",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Sorting"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 86.0,
    statement:
      "Given an integer array nums of length n and an integer target, find three integers in nums such that the sum is closest to target.\n\nReturn the sum of the three integers.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [-1,2,1,-4], target = 1\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- 3 <= nums.length <= 500\n\n\t- -1000 <= nums[i] <= 1000\n\n\t- -104 <= target <= 104",
  },
  // 20. Two Sum II - Input Array Is Sorted
  {
    slug: "two-sum-ii-input-array-is-sorted",
    title: "Two Sum II - Input Array Is Sorted",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Binary Search"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 95.0,
    statement:
      "Given a 1-indexed array of integers numbers that is already sorted in non-decreasing order, find two numbers such that they add up to a specific target number.\n\nReturn the indices of the two numbers, index1 and index2, added by one as an integer array [index1, index2] of length 2.\n\n\u00a0\n\nExample 1:\n\n```\nInput: numbers = [2,7,11,15], target = 9\nOutput: [1,2]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= numbers.length <= 3 * 104\n\n\t- -1000 <= numbers[i] <= 1000\n\n\t- numbers is sorted in non-decreasing order.\n\n\t- -1000 <= target <= 1000",
  },
  // 21. Remove Duplicates from Sorted List
  {
    slug: "remove-duplicates-from-sorted-list",
    title: "Remove Duplicates from Sorted List",
    difficulty: "Easy",
    topics: ["Linked List"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 88.0,
    statement:
      "Given the head of a sorted linked list, delete all duplicates such that each element appears only once. Return the linked list sorted as well.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,1,2]\nOutput: [1,2]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 300].\n\n\t- -100 <= Node.val <= 100",
  },
  // 22. Partition List
  {
    slug: "partition-list",
    title: "Partition List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 86.0,
    statement:
      "Given the head of a linked list and a value x, partition it such that all nodes less than x come before nodes greater than or equal to x.\n\nYou should preserve the original relative order of the nodes in each of the two partitions.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,4,3,2,5,2], x = 3\nOutput: [1,2,2,4,3,5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 200].\n\n\t- -100 <= Node.val <= 100\n\n\t- -200 <= x <= 200",
  },
  // 23. Rotate List
  {
    slug: "rotate-list",
    title: "Rotate List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 88.0,
    statement:
      "Given the head of a linked list, rotate the list to the right by k places.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,4,5], k = 2\nOutput: [4,5,1,2,3]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 500].\n\n\t- -100 <= Node.val <= 100\n\n\t- 0 <= k <= 2 * 109",
  },
  // 24. Odd Even Linked List
  {
    slug: "odd-even-linked-list",
    title: "Odd Even Linked List",
    difficulty: "Medium",
    topics: ["Linked List"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 89.0,
    statement:
      "Given the head of a singly linked list, group all the nodes with odd indices together followed by the nodes with even indices, and return the reordered list.\n\nYou must solve the problem in O(1) extra space complexity and O(n) time complexity.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,4,5]\nOutput: [1,3,5,2,4]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the linked list is in the range [0, 104].\n\n\t- -106 <= Node.val <= 106",
  },
  // 25. Palindrome Linked List
  {
    slug: "palindrome-linked-list",
    title: "Palindrome Linked List",
    difficulty: "Easy",
    topics: ["Linked List", "Two Pointers", "Stack", "Recursion"],
    companies: ["amazon", "meta", "microsoft", "google", "apple"],
    freq: 94.0,
    statement:
      "Given the head of a singly linked list, return true if it is a palindrome or false otherwise.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,2,1]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [1, 105].\n\n\t- 0 <= Node.val <= 9",
  },
  // 26. Insertion Sort List
  {
    slug: "insertion-sort-list",
    title: "Insertion Sort List",
    difficulty: "Medium",
    topics: ["Linked List", "Sorting"],
    companies: ["amazon", "google", "microsoft"],
    freq: 78.0,
    statement:
      "Given the head of a singly linked list, sort the list using insertion sort, and return the sorted list's head.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [4,2,1,3]\nOutput: [1,2,3,4]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [1, 5000].\n\n\t- -5000 <= Node.val <= 5000",
  },
  // 27. Path Sum III
  {
    slug: "path-sum-iii",
    title: "Path Sum III",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Binary Tree", "Prefix Sum"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement:
      "Given the root of a binary tree and an integer targetSum, return the number of paths where the sum of the values in the path equals targetSum.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [10,5,-3,3,2,null,11,3,-2,null,1], targetSum = 8\nOutput: 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 1000].\n\n\t- -109 <= Node.val <= 109\n\n\t- -1000 <= targetSum <= 1000",
  },
  // 28. Binary Tree Paths
  {
    slug: "binary-tree-paths",
    title: "Binary Tree Paths",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "String", "Backtracking", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 85.0,
    statement:
      'Given the root of a binary tree, return all root-to-leaf paths in any order.\n\nA leaf is a node with no children.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3,null,5]\nOutput: ["1->2->5","1->3"]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 100].\n\n\t- -100 <= Node.val <= 100',
  },
  // 29. Sum Root to Leaf Numbers
  {
    slug: "sum-root-to-leaf-numbers",
    title: "Sum Root to Leaf Numbers",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 89.0,
    statement:
      "You are given the root of a binary tree containing digits from 0 to 9 only.\n\nEach root-to-leaf path in the tree represents a number.\n\nReturn the total sum of all root-to-leaf numbers.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3]\nOutput: 25\nExplanation: 12 + 13 = 25.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 1000].\n\n\t- 0 <= Node.val <= 9",
  },
  // 30. Flatten Binary Tree to Linked List
  {
    slug: "flatten-binary-tree-to-linked-list",
    title: "Flatten Binary Tree to Linked List",
    difficulty: "Medium",
    topics: ["Linked List", "Stack", "Tree", "Depth-First Search", "Binary Tree"],
    companies: ["meta", "amazon", "microsoft", "google", "bloomberg"],
    freq: 91.0,
    statement:
      'Given the root of a binary tree, flatten the tree into a "linked list" in-place following preorder traversal.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,5,3,4,null,6]\nOutput: [1,null,2,null,3,null,4,null,5,null,6]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 2000].\n\n\t- -100 <= Node.val <= 100',
  },
  // 31. Populating Next Right Pointers in Each Node
  {
    slug: "populating-next-right-pointers-in-each-node",
    title: "Populating Next Right Pointers in Each Node",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Linked List", "Binary Tree"],
    companies: ["meta", "amazon", "microsoft", "google", "bloomberg"],
    freq: 90.0,
    statement:
      "You are given a perfect binary tree where all leaves are on the same level, and every parent has two children.\n\nPopulate each next pointer to point to its next right node. If there is no next right node, the next pointer should be set to NULL.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3,4,5,6,7]\nOutput: [1,#,2,3,#,4,5,6,7,#]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 212 - 1].\n\n\t- -1000 <= Node.val <= 1000",
  },
  // 32. Populating Next Right Pointers in Each Node II
  {
    slug: "populating-next-right-pointers-in-each-node-ii",
    title: "Populating Next Right Pointers in Each Node II",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Linked List", "Binary Tree"],
    companies: ["meta", "amazon", "microsoft", "google", "bloomberg"],
    freq: 88.0,
    statement:
      "Given a binary tree, populate each next pointer to point to its next right node. If there is no next right node, the next pointer should be set to NULL.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3,4,5,null,7]\nOutput: [1,#,2,3,#,4,5,7,#]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 6000].\n\n\t- -100 <= Node.val <= 100",
  },
  // 33. Binary Search Tree Iterator
  {
    slug: "binary-search-tree-iterator",
    title: "Binary Search Tree Iterator",
    difficulty: "Medium",
    topics: ["Stack", "Tree", "Design", "Binary Search Tree", "Binary Tree", "Iterator"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 91.0,
    statement:
      'Implement the BSTIterator class that represents an iterator over the in-order traversal of a binary search tree (BST).\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["BSTIterator", "next", "next", "hasNext", "next", "hasNext", "next", "hasNext", "next", "hasNext"]\n[[[7, 3, 15, null, null, 9, 20]], [], [], [], [], [], [], [], [], []]\nOutput\n[null, 3, 7, true, 9, true, 15, true, 20, false]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 105].\n\n\t- 0 <= Node.val <= 106',
  },
  // 34. Delete Node in a BST
  {
    slug: "delete-node-in-a-bst",
    title: "Delete Node in a BST",
    difficulty: "Medium",
    topics: ["Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "microsoft", "meta", "google"],
    freq: 86.0,
    statement:
      "Given a root node reference of a BST and a key, delete the node with the given key in the BST. Return the root node reference (possibly updated) of the BST.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [5,3,6,2,4,null,7], key = 3\nOutput: [5,4,6,2,null,null,7]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 104].\n\n\t- -105 <= Node.val <= 105",
  },
  // 35. Trim a Binary Search Tree
  {
    slug: "trim-a-binary-search-tree",
    title: "Trim a Binary Search Tree",
    difficulty: "Medium",
    topics: ["Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 82.0,
    statement:
      "Given the root of a binary search tree and the lowest and highest boundaries as low and high, trim the tree so that all its elements lie in [low, high].\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,0,2], low = 1, high = 2\nOutput: [1,null,2]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 104].\n\n\t- 0 <= Node.val <= 104",
  },
  // 36. Convert Sorted Array to Binary Search Tree
  {
    slug: "convert-sorted-array-to-binary-search-tree",
    title: "Convert Sorted Array to Binary Search Tree",
    difficulty: "Easy",
    topics: ["Array", "Divide and Conquer", "Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft", "apple"],
    freq: 92.0,
    statement:
      "Given an integer array nums where the elements are sorted in ascending order, convert it to a height-balanced binary search tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [-10,-3,0,5,9]\nOutput: [0,-3,9,-10,null,5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 104\n\n\t- -104 <= nums[i] <= 104",
  },
  // 37. Convert Sorted List to Binary Search Tree
  {
    slug: "convert-sorted-list-to-binary-search-tree",
    title: "Convert Sorted List to Binary Search Tree",
    difficulty: "Medium",
    topics: ["Linked List", "Divide and Conquer", "Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 85.0,
    statement:
      "Given the head of a singly linked list where elements are sorted in ascending order, convert it to a height-balanced binary search tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [-10,-3,0,5,9]\nOutput: [0,-3,9,-10,null,5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in head is in the range [0, 2 * 104].\n\n\t- -105 <= Node.val <= 105",
  },
  // 38. Maximum Width of Binary Tree
  {
    slug: "maximum-width-of-binary-tree",
    title: "Maximum Width of Binary Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 88.0,
    statement:
      "Given the root of a binary tree, return the maximum width of the given tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,3,2,5,3,null,9]\nOutput: 4\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 3000].\n\n\t- -100 <= Node.val <= 100",
  },
  // 39. Search in Rotated Sorted Array II
  {
    slug: "search-in-rotated-sorted-array-ii",
    title: "Search in Rotated Sorted Array II",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 85.0,
    statement:
      "There is an integer array nums sorted in non-decreasing order (not necessarily with distinct values), rotated at an unknown pivot index. Given the array nums and target, return true if target is in nums, or false if it is not.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [2,5,6,0,0,1,2], target = 0\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 5000\n\n\t- -104 <= nums[i] <= 104",
  },
  // 40. Surrounded Regions
  {
    slug: "surrounded-regions",
    title: "Surrounded Regions",
    difficulty: "Medium",
    topics: ["Array", "Depth-First Search", "Breadth-First Search", "Union Find", "Matrix"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 89.0,
    statement:
      'You are given an m x n matrix board containing letters \'X\' and \'O\', capture regions that are surrounded.\n\n\u00a0\n\nExample 1:\n\n```\nInput: board = [["X","X","X","X"],["X","O","O","X"],["X","X","O","X"],["X","O","X","X"]]\nOutput: [["X","X","X","X"],["X","X","X","X"],["X","X","X","X"],["X","O","X","X"]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- m == board.length\n\n\t- n == board[i].length\n\n\t- 1 <= m, n <= 200',
  },
  // 41. Graph Valid Tree
  {
    slug: "graph-valid-tree",
    title: "Graph Valid Tree",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 88.0,
    statement:
      "You have a graph of n nodes labeled from 0 to n - 1. You are given an integer n and a list of edges. Return true if the edges of the given graph make up a valid tree, and false otherwise.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 5, edges = [[0,1],[0,2],[0,3],[1,4]]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 2000\n\n\t- 0 <= edges.length <= 5000",
  },
  // 42. Number of Connected Components in an Undirected Graph
  {
    slug: "number-of-connected-components-in-an-undirected-graph",
    title: "Number of Connected Components in an Undirected Graph",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 89.0,
    statement:
      "You have a graph of n nodes. Return the number of connected components in the graph.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 5, edges = [[0,1],[1,2],[3,4]]\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 2000\n\n\t- 1 <= edges.length <= 5000",
  },
  // 43. Redundant Connection
  {
    slug: "redundant-connection",
    title: "Redundant Connection",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 87.0,
    statement:
      "Given an undirected graph with n nodes labeled from 1 to n, return an edge that can be removed so that the resulting graph is a tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: edges = [[1,2],[1,3],[2,3]]\nOutput: [2,3]\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == edges.length\n\n\t- 3 <= n <= 1000",
  },
  // 44. Is Graph Bipartite?
  {
    slug: "is-graph-bipartite",
    title: "Is Graph Bipartite?",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 86.0,
    statement:
      "There is an undirected graph with n nodes. Return true if and only if it is bipartite.\n\n\u00a0\n\nExample 1:\n\n```\nInput: graph = [[1,2,3],[0,2],[0,1,3],[0,2]]\nOutput: false\n```\n\n\u00a0\n\nConstraints:\n\n\t- graph.length == n\n\n\t- 1 <= n <= 100",
  },
  // 45. Minimum Height Trees
  {
    slug: "minimum-height-trees",
    title: "Minimum Height Trees",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Graph", "Topological Sort"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 86.0,
    statement:
      "Given a tree of n nodes, return a list of all MHTs' root labels. You can return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 4, edges = [[1,0],[1,2],[1,3]]\nOutput: [1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 2 * 104\n\n\t- edges.length == n - 1",
  },
  // 46. All Paths From Source to Target
  {
    slug: "all-paths-from-source-to-target",
    title: "All Paths From Source to Target",
    difficulty: "Medium",
    topics: ["Backtracking", "Depth-First Search", "Breadth-First Search", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 84.0,
    statement:
      "Given a DAG of n nodes labeled from 0 to n - 1, find all possible paths from node 0 to node n - 1.\n\n\u00a0\n\nExample 1:\n\n```\nInput: graph = [[1,2],[3],[3],[]]\nOutput: [[0,1,3],[0,2,3]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == graph.length\n\n\t- 2 <= n <= 15",
  },
  // 47. Keys and Rooms
  {
    slug: "keys-and-rooms",
    title: "Keys and Rooms",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Graph"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 85.0,
    statement:
      "There are n rooms labeled from 0 to n - 1 and all the rooms are locked except for room 0. Return true if you can visit all the rooms, or false otherwise.\n\n\u00a0\n\nExample 1:\n\n```\nInput: rooms = [[1],[2],[3],[]]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == rooms.length\n\n\t- 2 <= n <= 1000",
  },
  // 48. As Far from Land as Possible
  {
    slug: "as-far-from-land-as-possible",
    title: "As Far from Land as Possible",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Breadth-First Search", "Matrix"],
    companies: ["amazon", "meta", "google"],
    freq: 80.0,
    statement:
      "Given an n x n grid containing only values 0 and 1, find a water cell such that its distance to the nearest land cell is maximized.\n\n\u00a0\n\nExample 1:\n\n```\nInput: grid = [[1,0,1],[0,0,0],[1,0,1]]\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == grid.length\n\n\t- 1 <= n <= 100",
  },
  // 49. Shortest Path in Binary Matrix
  {
    slug: "shortest-path-in-binary-matrix",
    title: "Shortest Path in Binary Matrix",
    difficulty: "Medium",
    topics: ["Array", "Breadth-First Search", "Matrix"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 92.0,
    statement:
      "Given an n x n binary matrix grid, return the length of the shortest clear path in the matrix. If there is no clear path, return -1.\n\n\u00a0\n\nExample 1:\n\n```\nInput: grid = [[0,1],[1,0]]\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == grid.length\n\n\t- 1 <= n <= 100",
  },
  // 50. Design Twitter
  {
    slug: "design-twitter",
    title: "Design Twitter",
    difficulty: "Medium",
    topics: ["Hash Table", "Linked List", "Design", "Heap (Priority Queue)"],
    companies: ["twitter", "amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement:
      'Design a simplified version of Twitter with postTweet, getNewsFeed, follow, and unfollow features.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["Twitter", "postTweet", "getNewsFeed", "follow", "postTweet", "getNewsFeed", "unfollow", "getNewsFeed"]\n[[], [1, 5], [1], [1, 2], [2, 6], [1], [1, 2], [1]]\nOutput\n[null, null, [5], null, null, [6, 5], null, [5]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= userId, followerId, followeeId <= 500\n\n\t- 0 <= tweetId <= 104',
  },
  // 51. Seat Reservation Manager
  {
    slug: "seat-reservation-manager",
    title: "Seat Reservation Manager",
    difficulty: "Medium",
    topics: ["Design", "Heap (Priority Queue)"],
    companies: ["amazon", "meta", "google"],
    freq: 81.0,
    statement:
      'Design a system that manages the reservation state of n seats that are numbered from 1 to n.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["SeatManager", "reserve", "reserve", "unreserve", "reserve", "reserve", "reserve", "reserve", "unreserve"]\n[[5], [], [], [2], [], [], [], [], [5]]\nOutput\n[null, 1, 2, null, 2, 3, 4, 5, null]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 105\n\n\t- 1 <= seatNumber <= n',
  },
  // 52. Single-Threaded CPU
  {
    slug: "single-threaded-cpu",
    title: "Single-Threaded CPU",
    difficulty: "Medium",
    topics: ["Array", "Sorting", "Heap (Priority Queue)"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 84.0,
    statement:
      "You have a single-threaded CPU that processes tasks based on shortest processing time. Return the order in which the CPU will process the tasks.\n\n\u00a0\n\nExample 1:\n\n```\nInput: tasks = [[1,2],[2,4],[3,2],[4,1]]\nOutput: [0,2,3,1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- tasks.length == n\n\n\t- 1 <= n <= 105",
  },
  // 53. Maximum Subsequence Score
  {
    slug: "maximum-subsequence-score",
    title: "Maximum Subsequence Score",
    difficulty: "Medium",
    topics: ["Array", "Greedy", "Sorting", "Heap (Priority Queue)"],
    companies: ["amazon", "meta", "google"],
    freq: 83.0,
    statement:
      "Given two 0-indexed integer arrays nums1 and nums2 of length n and integer k, return the maximum possible score.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums1 = [1,3,3,2], nums2 = [2,1,3,4], k = 3\nOutput: 12\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == nums1.length == nums2.length\n\n\t- 1 <= n <= 105\n\n\t- 1 <= k <= n",
  },
  // 54. IPO
  {
    slug: "ipo",
    title: "IPO",
    difficulty: "Hard",
    topics: ["Array", "Greedy", "Sorting", "Heap (Priority Queue)"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 85.0,
    statement:
      "Pick a list of at most k distinct projects from given projects to maximize your final capital, and return the final maximized capital.\n\n\u00a0\n\nExample 1:\n\n```\nInput: k = 2, w = 0, profits = [1,2,3], capital = [0,1,1]\nOutput: 4\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= k <= 105\n\n\t- 0 <= w <= 109\n\n\t- 1 <= n <= 105",
  },
  // 55. Subsets II
  {
    slug: "subsets-ii",
    title: "Subsets II",
    difficulty: "Medium",
    topics: ["Array", "Backtracking", "Bit Manipulation"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 90.0,
    statement:
      "Given an integer array nums that may contain duplicates, return all possible subsets without duplicate subsets.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,2]\nOutput: [[],[1],[1,2],[1,2,2],[2],[2,2]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 10\n\n\t- -10 <= nums[i] <= 10",
  },
  // 56. Combination Sum III
  {
    slug: "combination-sum-iii",
    title: "Combination Sum III",
    difficulty: "Medium",
    topics: ["Array", "Backtracking"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 84.0,
    statement:
      "Find all valid combinations of k numbers from 1 to 9 that sum up to n, using each number at most once.\n\n\u00a0\n\nExample 1:\n\n```\nInput: k = 3, n = 7\nOutput: [[1,2,4]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= k <= 9\n\n\t- 1 <= n <= 60",
  },
  // 57. Permutations II
  {
    slug: "permutations-ii",
    title: "Permutations II",
    difficulty: "Medium",
    topics: ["Array", "Backtracking", "Sorting"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 89.0,
    statement:
      "Given a collection of numbers, nums, that might contain duplicates, return all possible unique permutations in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,2]\nOutput: [[1,1,2],[1,2,1],[2,1,1]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 8\n\n\t- -10 <= nums[i] <= 10",
  },
  // 58. Palindrome Partitioning
  {
    slug: "palindrome-partitioning",
    title: "Palindrome Partitioning",
    difficulty: "Medium",
    topics: ["String", "Dynamic Programming", "Backtracking"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg", "tiktok"],
    freq: 92.0,
    statement:
      'Given a string s, partition s such that every substring of the partition is a palindrome. Return all possible palindrome partitioning of s.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "aab"\nOutput: [["a","a","b"],["aa","b"]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 16\n\n\t- s contains only lowercase English letters.',
  },
  // 59. Min Cost Climbing Stairs
  {
    slug: "min-cost-climbing-stairs",
    title: "Min Cost Climbing Stairs",
    difficulty: "Easy",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 93.0,
    statement:
      "You are given an integer array cost where cost[i] is the cost of ith step on a staircase. Return the minimum cost to reach the top of the floor.\n\n\u00a0\n\nExample 1:\n\n```\nInput: cost = [10,15,20]\nOutput: 15\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= cost.length <= 1000\n\n\t- 0 <= cost[i] <= 999",
  },
  // 60. Coin Change II
  {
    slug: "coin-change-ii",
    title: "Coin Change II",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 91.0,
    statement:
      "You are given an integer array coins and an integer amount. Return the number of combinations that make up that amount.\n\n\u00a0\n\nExample 1:\n\n```\nInput: amount = 5, coins = [1,2,5]\nOutput: 4\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= coins.length <= 300\n\n\t- 0 <= amount <= 5000",
  },
  // 61. Target Sum
  {
    slug: "target-sum",
    title: "Target Sum",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Backtracking"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 90.0,
    statement:
      "You are given an integer array nums and an integer target. Return the number of different expressions that you can build with '+' and '-' which evaluates to target.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,1,1,1], target = 3\nOutput: 5\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 20\n\n\t- 0 <= nums[i] <= 1000\n\n\t- -1000 <= target <= 1000",
  },
  // 62. Interleaving String
  {
    slug: "interleaving-string",
    title: "Interleaving String",
    difficulty: "Medium",
    topics: ["String", "Dynamic Programming"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 88.0,
    statement:
      'Given strings s1, s2, and s3, find whether s3 is formed by an interleaving of s1 and s2.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s1 = "aabcc", s2 = "dbbca", s3 = "aadbbcbcac"\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= s1.length, s2.length <= 100\n\n\t- 0 <= s3.length <= 200',
  },
  // 63. Best Time to Buy and Sell Stock with Cooldown
  {
    slug: "best-time-to-buy-and-sell-stock-with-cooldown",
    title: "Best Time to Buy and Sell Stock with Cooldown",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 89.0,
    statement:
      "You are given an array prices where prices[i] is the price of a given stock on the ith day. Find the maximum profit you can achieve with a 1-day cooldown after selling.\n\n\u00a0\n\nExample 1:\n\n```\nInput: prices = [1,2,3,0,2]\nOutput: 3\nExplanation: transactions = [buy, sell, cooldown, buy, sell]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= prices.length <= 5000\n\n\t- 0 <= prices[i] <= 1000",
  },
  // 64. Best Time to Buy and Sell Stock IV
  {
    slug: "best-time-to-buy-and-sell-stock-iv",
    title: "Best Time to Buy and Sell Stock IV",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 86.0,
    statement:
      "You are given an integer array prices and an integer k. Find the maximum profit you can achieve with at most k transactions.\n\n\u00a0\n\nExample 1:\n\n```\nInput: k = 2, prices = [2,4,1]\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= k <= 100\n\n\t- 1 <= prices.length <= 1000\n\n\t- 0 <= prices[i] <= 1000",
  },
  // 65. Unique Binary Search Trees II
  {
    slug: "unique-binary-search-trees-ii",
    title: "Unique Binary Search Trees II",
    difficulty: "Medium",
    topics: ["Dynamic Programming", "Backtracking", "Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 84.0,
    statement:
      "Given an integer n, return all the structurally unique BST's (binary search trees), which has exactly n nodes of unique values from 1 to n. Return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 3\nOutput: [[1,null,2,null,3],[1,null,3,2],[2,1,3],[3,1,null,null,2],[3,2,null,1]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 8",
  },
  // 66. Balanced Binary Tree
  {
    slug: "balanced-binary-tree",
    title: "Balanced Binary Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 94.0,
    statement:
      "Given a binary tree, determine if it is height-balanced (a binary tree in which the depth of the two subtrees of every node never differs by more than one).\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,9,20,null,null,15,7]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 5000].\n\n\t- -104 <= Node.val <= 104",
  },
  // 67. Diameter of Binary Tree
  {
    slug: "diameter-of-binary-tree",
    title: "Diameter of Binary Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft", "apple", "bloomberg"],
    freq: 97.0,
    statement:
      "Given the root of a binary tree, return the length of the diameter of the tree.\n\nThe diameter of a binary tree is the length of the longest path between any two nodes in a tree. This path may or may not pass through the root.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3,4,5]\nOutput: 3\nExplanation: 3 is the length of the path [4,2,1,3] or [5,2,1,3].\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 104].\n\n\t- -100 <= Node.val <= 100",
  },
  // 68. Same Tree
  {
    slug: "same-tree",
    title: "Same Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 95.0,
    statement:
      "Given the roots of two binary trees p and q, write a function to check if they are the same or not.\n\nTwo binary trees are considered the same if they are structurally identical, and the nodes have the same value.\n\n\u00a0\n\nExample 1:\n\n```\nInput: p = [1,2,3], q = [1,2,3]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in both trees is in the range [0, 100].\n\n\t- -104 <= Node.val <= 104",
  },
  // 69. Symmetric Tree
  {
    slug: "symmetric-tree",
    title: "Symmetric Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 96.0,
    statement:
      "Given the root of a binary tree, check whether it is a mirror of itself (i.e., symmetric around its center).\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,2,3,4,4,3]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 1000].\n\n\t- -100 <= Node.val <= 100",
  },
  // 70. Minimum Depth of Binary Tree
  {
    slug: "minimum-depth-of-binary-tree",
    title: "Minimum Depth of Binary Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 89.0,
    statement:
      "Given a binary tree, find its minimum depth.\n\nThe minimum depth is the number of nodes along the shortest path from the root node down to the nearest leaf node.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,9,20,null,null,15,7]\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 105].\n\n\t- -1000 <= Node.val <= 1000",
  },
  // 71. Path Sum
  {
    slug: "path-sum",
    title: "Path Sum",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 92.0,
    statement:
      "Given the root of a binary tree and an integer targetSum, return true if the tree has a root-to-leaf path such that adding up all the values along the path equals targetSum.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [5,4,8,11,null,13,4,7,2,null,null,null,1], targetSum = 22\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 5000].\n\n\t- -1000 <= Node.val <= 1000\n\n\t- -1000 <= targetSum <= 1000",
  },
  // 72. Path Sum II
  {
    slug: "path-sum-ii",
    title: "Path Sum II",
    difficulty: "Medium",
    topics: ["Backtracking", "Tree", "Depth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 90.0,
    statement:
      "Given the root of a binary tree and an integer targetSum, return all root-to-leaf paths where the sum of the node values in the path equals targetSum.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [5,4,8,11,null,13,4,7,2,null,null,5,1], targetSum = 22\nOutput: [[5,4,11,2],[5,8,4,5]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 5000].\n\n\t- -1000 <= Node.val <= 1000\n\n\t- -1000 <= targetSum <= 1000",
  },
  // 73. Binary Tree Level Order Traversal II
  {
    slug: "binary-tree-level-order-traversal-ii",
    title: "Binary Tree Level Order Traversal II",
    difficulty: "Medium",
    topics: ["Tree", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 85.0,
    statement:
      "Given the root of a binary tree, return the bottom-up level order traversal of its nodes' values. (i.e., from left to right, level by level from leaf to root).\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,9,20,null,null,15,7]\nOutput: [[15,7],[9,20],[3]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 2000].\n\n\t- -1000 <= Node.val <= 1000",
  },
  // 74. Construct Binary Tree from Inorder and Postorder Traversal
  {
    slug: "construct-binary-tree-from-inorder-and-postorder-traversal",
    title: "Construct Binary Tree from Inorder and Postorder Traversal",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Divide and Conquer", "Tree", "Binary Tree"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 88.0,
    statement:
      "Given two integer arrays inorder and postorder where inorder is the inorder traversal of a binary tree and postorder is the postorder traversal of the same tree, construct and return the binary tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: inorder = [9,3,15,20,7], postorder = [9,15,7,20,3]\nOutput: [3,9,20,null,null,15,7]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= inorder.length <= 3000\n\n\t- postorder.length == inorder.length\n\n\t- -3000 <= inorder[i], postorder[i] <= 3000\n\n\t- inorder and postorder consist of unique values.",
  },
  // 75. N-Queens II
  {
    slug: "n-queens-ii",
    title: "N-Queens II",
    difficulty: "Hard",
    topics: ["Backtracking"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 86.0,
    statement:
      "The n-queens puzzle is the problem of placing n queens on an n x n chessboard such that no two queens attack each other. Given an integer n, return the number of distinct solutions to the n-queens puzzle.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 4\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 9",
  },
  // 76. Combinations
  {
    slug: "combinations",
    title: "Combinations",
    difficulty: "Medium",
    topics: ["Backtracking"],
    companies: ["meta", "amazon", "google", "microsoft", "apple"],
    freq: 92.0,
    statement:
      "Given two integers n and k, return all possible combinations of k numbers chosen from the range [1, n]. You may return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 4, k = 2\nOutput: [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 20\n\n\t- 1 <= k <= n",
  },
  // 77. Gray Code
  {
    slug: "gray-code",
    title: "Gray Code",
    difficulty: "Medium",
    topics: ["Math", "Backtracking", "Bit Manipulation"],
    companies: ["amazon", "meta", "google"],
    freq: 79.0,
    statement:
      "An n-bit gray code sequence is a sequence of 2n integers where: every integer is in the range [0, 2n - 1], the first integer is 0, each integer appears exactly once, and adjacent integers differ by exactly one bit. Given n, return any valid n-bit gray code sequence.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 2\nOutput: [0,1,3,2]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 16",
  },
  // 78. Remove Invalid Parentheses
  {
    slug: "remove-invalid-parentheses",
    title: "Remove Invalid Parentheses",
    difficulty: "Hard",
    topics: ["String", "Backtracking", "Breadth-First Search"],
    companies: ["meta", "google", "amazon", "microsoft", "uber"],
    freq: 94.0,
    statement:
      'Given a string s that contains parentheses and letters, remove the minimum number of invalid parentheses to make the input string valid. Return a list of unique strings that are valid with the minimum number of removals.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "()())()"\nOutput: ["(())()","()()()"]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 25\n\n\t- s consists of lowercase English letters and parentheses \'(\' and \')\'.',
  },
  // 79. Longest Valid Parentheses
  {
    slug: "longest-valid-parentheses",
    title: "Longest Valid Parentheses",
    difficulty: "Hard",
    topics: ["String", "Dynamic Programming", "Stack"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 93.0,
    statement:
      "Given a string containing just the characters '(' and ')', return the length of the longest valid (well-formed) parentheses substring.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = \")()())\"\nOutput: 4\nExplanation: The longest valid parentheses substring is \"()()\".\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= s.length <= 3 * 104\n\n\t- s[i] is '(', or ')'.",
  },
  // 80. Basic Calculator III
  {
    slug: "basic-calculator-iii",
    title: "Basic Calculator III",
    difficulty: "Hard",
    topics: ["Math", "String", "Stack", "Recursion"],
    companies: ["meta", "amazon", "google", "microsoft", "apple", "bloomberg"],
    freq: 91.0,
    statement:
      "Implement a basic calculator to evaluate a simple expression string containing non-negative integers, '+', '-', '*', '/' operators, and open '(' and closing ')' parentheses.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = \"2*(5+5*2)/3+(6/2+8)\"\nOutput: 21\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 104\n\n\t- s consists of digits, '+', '-', '*', '/', '(', and ')'.",
  },
  // 81. Spiral Matrix II
  {
    slug: "spiral-matrix-ii",
    title: "Spiral Matrix II",
    difficulty: "Medium",
    topics: ["Array", "Matrix", "Simulation"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 89.0,
    statement:
      "Given a positive integer n, generate an n x n matrix filled with elements from 1 to n2 in spiral order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 3\nOutput: [[1,2,3],[8,9,4],[7,6,5]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 20",
  },
  // 82. Valid Palindrome II
  {
    slug: "valid-palindrome-ii",
    title: "Valid Palindrome II",
    difficulty: "Easy",
    topics: ["Two Pointers", "String", "Greedy"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 95.0,
    statement:
      'Given a string s, return true if the s can be palindrome after deleting at most one character from it.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "aba"\nOutput: true\n```\n\nExample 2:\n\n```\nInput: s = "abca"\nOutput: true\nExplanation: You could delete the character \'c\'.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 105\n\n\t- s consists of lowercase English letters.',
  },
  // 83. Reverse Words in a String III
  {
    slug: "reverse-words-in-a-string-iii",
    title: "Reverse Words in a String III",
    difficulty: "Easy",
    topics: ["Two Pointers", "String"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 87.0,
    statement:
      'Given a string s, reverse the order of characters in each word within a sentence while still preserving whitespace and initial word order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "Let\'s take LeetCode contest"\nOutput: "s\'teL ekat edoCteeL tsetnoc"\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 5 * 104\n\n\t- s contains printable ASCII characters.',
  },
  // 84. Group Shifted Strings
  {
    slug: "group-shifted-strings",
    title: "Group Shifted Strings",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "String"],
    companies: ["meta", "amazon", "google"],
    freq: 88.0,
    statement:
      'Perform the shifting operation on a string: "abc" -> "bcd" -> ... -> "xyz". Given an array of strings strings, group all strings[i] that belong to the same shifting sequence. Return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: strings = ["abc","bcd","acef","xyz","az","ba","a","z"]\nOutput: [["acef"],["a","z"],["abc","bcd","xyz"],["az","ba"]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= strings.length <= 200\n\n\t- 1 <= strings[i].length <= 50',
  },
  // 85. Longest Substring with At Least K Repeating Characters
  {
    slug: "longest-substring-with-at-least-k-repeating-characters",
    title: "Longest Substring with At Least K Repeating Characters",
    difficulty: "Medium",
    topics: ["Hash Table", "String", "Divide and Conquer", "Sliding Window"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 87.0,
    statement:
      'Given a string s and an integer k, return the length of the longest substring of s such that the frequency of each character in this substring is greater than or equal to k.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "aaabb", k = 3\nOutput: 3\nExplanation: The longest substring is "aaa", as \'a\' is repeated 3 times.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 104\n\n\t- s consists of only lowercase English letters.\n\n\t- 1 <= k <= 105',
  },
  // 86. Minimum Window Subsequence
  {
    slug: "minimum-window-subsequence",
    title: "Minimum Window Subsequence",
    difficulty: "Hard",
    topics: ["String", "Dynamic Programming", "Sliding Window"],
    companies: ["google", "meta", "amazon"],
    freq: 84.0,
    statement:
      'Given strings s1 and s2, return the minimum contiguous substring W of s1, so that s2 is a subsequence of W.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s1 = "abcdebdde", s2 = "bde"\nOutput: "bcde"\nExplanation: "bcde" is the answer and its length is 4.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s1.length <= 2 * 104\n\n\t- 1 <= s2.length <= 100',
  },
  // 87. Single Number II
  {
    slug: "single-number-ii",
    title: "Single Number II",
    difficulty: "Medium",
    topics: ["Array", "Bit Manipulation"],
    companies: ["amazon", "google", "meta", "microsoft"],
    freq: 88.0,
    statement:
      "Given an integer array nums where every element appears three times except for one, which appears exactly once. Find the single element and return it.\n\nYou must implement a solution with a linear runtime complexity and use only constant extra space.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [2,2,3,2]\nOutput: 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 3 * 104\n\n\t- -231 <= nums[i] <= 231 - 1",
  },
  // 88. Single Number III
  {
    slug: "single-number-iii",
    title: "Single Number III",
    difficulty: "Medium",
    topics: ["Array", "Bit Manipulation"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 86.0,
    statement:
      "Given an integer array nums, in which exactly two elements appear only once and all the other elements appear exactly twice. Find the two elements that appear only once.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,1,3,2,5]\nOutput: [3,5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= nums.length <= 3 * 104\n\n\t- -231 <= nums[i] <= 231 - 1",
  },
  // 89. Bitwise AND of Numbers Range
  {
    slug: "bitwise-and-of-numbers-range",
    title: "Bitwise AND of Numbers Range",
    difficulty: "Medium",
    topics: ["Bit Manipulation"],
    companies: ["amazon", "google", "microsoft"],
    freq: 83.0,
    statement:
      "Given two integers left and right that represent the range [left, right], return the bitwise AND of all numbers in this range, inclusive.\n\n\u00a0\n\nExample 1:\n\n```\nInput: left = 5, right = 7\nOutput: 4\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= left <= right <= 231 - 1",
  },
  // 90. Maximum XOR of Two Numbers in an Array
  {
    slug: "maximum-xor-of-two-numbers-in-an-array",
    title: "Maximum XOR of Two Numbers in an Array",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Bit Manipulation", "Trie"],
    companies: ["google", "amazon", "meta"],
    freq: 85.0,
    statement:
      "Given an integer array nums, return the maximum result of nums[i] XOR nums[j], where 0 <= i <= j < n.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [3,10,5,25,2,8]\nOutput: 28\nExplanation: The maximum result is 5 XOR 25 = 28.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 2 * 105\n\n\t- 0 <= nums[i] <= 231 - 1",
  },
  // 91. Swim in Rising Water
  {
    slug: "swim-in-rising-water",
    title: "Swim in Rising Water",
    difficulty: "Hard",
    topics: [
      "Array",
      "Binary Search",
      "Depth-First Search",
      "Breadth-First Search",
      "Union Find",
      "Heap (Priority Queue)",
      "Matrix",
    ],
    companies: ["google", "meta", "amazon"],
    freq: 88.0,
    statement:
      "You are given an n x n integer matrix grid where each term grid[i][j] represents the elevation at that point (i, j). Return the least time until you can reach the bottom right square (n - 1, n - 1) if you start at the top left square (0, 0).\n\n\u00a0\n\nExample 1:\n\n```\nInput: grid = [[0,2],[1,3]]\nOutput: 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == grid.length\n\n\t- n == grid[i].length\n\n\t- 1 <= n <= 50\n\n\t- 0 <= grid[i][j] < n2",
  },
  // 92. Alien Dictionary
  {
    slug: "alien-dictionary",
    title: "Alien Dictionary",
    difficulty: "Hard",
    topics: [
      "Array",
      "String",
      "Depth-First Search",
      "Breadth-First Search",
      "Graph",
      "Topological Sort",
    ],
    companies: ["meta", "amazon", "google", "microsoft", "apple", "bloomberg", "uber", "airbnb"],
    freq: 96.0,
    statement:
      'There is a new alien language that uses the English alphabet. However, the order of the letters is unknown to you.\n\nYou are given a list of strings words from the alien language\'s dictionary, where the strings in words are sorted lexicographically by the rules of this new language.\n\nReturn a string of the unique letters in the new alien language sorted in lexicographically increasing order by the new language\'s rules. If there is no solution, return "". If there are multiple solutions, return any of them.\n\n\u00a0\n\nExample 1:\n\n```\nInput: words = ["wrt","wrf","er","ett","rftt"]\nOutput: "wertf"\n```\n\nExample 2:\n\n```\nInput: words = ["z","x"]\nOutput: "zx"\n```\n\nExample 3:\n\n```\nInput: words = ["z","x","z"]\nOutput: ""\nExplanation: The order is invalid, so return "".\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= words.length <= 100\n\n\t- 1 <= words[i].length <= 100\n\n\t- words[i] consists of only lowercase English letters.',
  },
  // 93. Course Schedule III
  {
    slug: "course-schedule-iii",
    title: "Course Schedule III",
    difficulty: "Hard",
    topics: ["Array", "Greedy", "Sorting", "Heap (Priority Queue)"],
    companies: ["google", "amazon", "meta"],
    freq: 85.0,
    statement:
      "There are n different online courses numbered from 1 to n. You are given an array courses where courses[i] = [durationi, lastDayi]. Return the maximum number of courses that you can take.\n\n\u00a0\n\nExample 1:\n\n```\nInput: courses = [[100,200],[200,1300],[1000,1250],[2000,3200]]\nOutput: 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= courses.length <= 104\n\n\t- 1 <= durationi, lastDayi <= 104",
  },
  // 94. Minimum Cost to Hire K Workers
  {
    slug: "minimum-cost-to-hire-k-workers",
    title: "Minimum Cost to Hire K Workers",
    difficulty: "Hard",
    topics: ["Array", "Greedy", "Sorting", "Heap (Priority Queue)"],
    companies: ["google", "amazon", "meta"],
    freq: 87.0,
    statement:
      "There are n workers. You are given two integer arrays quality and wage where quality[i] is the quality of the ith worker and wage[i] is the minimum wage expectation for the ith worker. Given integer k, return the least amount of money needed to form a paid group satisfying the rules.\n\n\u00a0\n\nExample 1:\n\n```\nInput: quality = [10,20,5], wage = [70,50,30], k = 2\nOutput: 105.00000\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == quality.length == wage.length\n\n\t- 1 <= k <= n <= 104\n\n\t- 1 <= quality[i] <= 104\n\n\t- 1 <= wage[i] <= 104",
  },
  // 95. Kth Smallest Element in a Sorted Matrix
  {
    slug: "kth-smallest-element-in-a-sorted-matrix",
    title: "Kth Smallest Element in a Sorted Matrix",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Sorting", "Heap (Priority Queue)", "Matrix"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 91.0,
    statement:
      "Given an n x n matrix where each of the rows and columns is sorted in ascending order, return the kth smallest element in the matrix.\n\n\u00a0\n\nExample 1:\n\n```\nInput: matrix = [[1,5,9],[10,11,13],[12,13,15]], k = 8\nOutput: 13\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == matrix.length == matrix[i].length\n\n\t- 1 <= n <= 300\n\n\t- -109 <= matrix[i][j] <= 109\n\n\t- 1 <= k <= n2",
  },
  // 96. Find K Pairs with Smallest Sums
  {
    slug: "find-k-pairs-with-smallest-sums",
    title: "Find K Pairs with Smallest Sums",
    difficulty: "Medium",
    topics: ["Array", "Heap (Priority Queue)"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement:
      "You are given two integer arrays nums1 and nums2 sorted in non-decreasing order and an integer k. Return the k pairs [u, v] with the smallest sums.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums1 = [1,7,11], nums2 = [2,4,6], k = 3\nOutput: [[1,2],[1,4],[1,6]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums1.length, nums2.length <= 105\n\n\t- -109 <= nums1[i], nums2[i] <= 109\n\n\t- 1 <= k <= 104",
  },
  // 97. Split Array into Consecutive Subsequences
  {
    slug: "split-array-into-consecutive-subsequences",
    title: "Split Array into Consecutive Subsequences",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Greedy", "Heap (Priority Queue)"],
    companies: ["google", "amazon", "meta"],
    freq: 85.0,
    statement:
      "You are given an integer array nums that is sorted in ascending order. Determine if it's possible to split nums into one or more subsequences such that each subsequence consists of 3 or more consecutive integers.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,3,3,4,5]\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 104\n\n\t- -1000 <= nums[i] <= 1000",
  },
  // 98. Merge Two Binary Trees
  {
    slug: "merge-two-binary-trees",
    title: "Merge Two Binary Trees",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 92.0,
    statement:
      "You are given two binary trees root1 and root2.\n\nImagine that when you put one of them to cover the other, some nodes of the two trees are overlapped while the others are not. You need to merge the two trees into a new binary tree. The merge rule is that if two nodes overlap, then sum node values up as the new value of the merged node. Otherwise, the NOT null node will be used as the node of the new tree.\n\nReturn the merged tree.\n\nNote: The merging process must start from the root nodes of both trees.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root1 = [1,3,2,5], root2 = [2,1,3,null,4,null,7]\nOutput: [3,4,5,5,4,null,7]\n```\n\nExample 2:\n\n```\nInput: root1 = [1], root2 = [1,2]\nOutput: [2,2]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in both trees is in the range [0, 2000].\n\n\t- -104 <= Node.val <= 104",
  },
  // 99. Delete the Middle Node of a Linked List
  {
    slug: "delete-the-middle-node-of-a-linked-list",
    title: "Delete the Middle Node of a Linked List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 91.0,
    statement:
      "You are given the head of a linked list. Delete the middle node, and return the head of the modified linked list.\n\nThe middle node of a linked list of size n is the ⌊n / 2⌋th node from the start using 0-based indexing, where ⌊x⌋ denotes the largest integer less than or equal to x.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,3,4,7,1,2,6]\nOutput: [1,3,4,1,2,6]\nExplanation:\nThe above figure represents the given linked list. The indices of the nodes are 0, 1, 2, 3, 4, 5, 6.\nNode 3 with value 7 is the middle node, which is marked in red.\nWe return the new list after removing this node.\n```\n\nExample 2:\n\n```\nInput: head = [1,2,3,4]\nOutput: [1,2,4]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [1, 105].\n\n\t- 1 <= Node.val <= 105",
  },
  // 100. Maximum Twin Sum of a Linked List
  {
    slug: "maximum-twin-sum-of-a-linked-list",
    title: "Maximum Twin Sum of a Linked List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers", "Stack"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 89.0,
    statement:
      "In a linked list of size n, where n is even, the ith node (0-indexed) of the linked list is known as the twin of the (n-1-i)th node, if 0 <= i <= (n / 2) - 1.\n\n\t- For example, if n = 4, then node 0 is the twin of node 3, and node 1 is the twin of node 2. These are the only nodes with twins for n = 4.\n\nThe twin sum is defined as the sum of a node and its twin.\n\nGiven the head of a linked list with even length, return the maximum twin sum of the linked list.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [5,4,2,1]\nOutput: 6\nExplanation:\nNodes 0 and 1 are the twins of nodes 3 and 2, respectively. All have twin sum = 6.\nThere are no other nodes with twins in the linked list.\nThus, the maximum twin sum of the linked list is 6.\n```\n\nExample 2:\n\n```\nInput: head = [4,2,2,3]\nOutput: 7\nExplanation:\nThe nodes with twins present in this linked list are:\n- Node 0 is the twin of node 3 having a twin sum of 4 + 3 = 7.\n- Node 1 is the twin of node 2 having a twin sum of 2 + 2 = 4.\nThus, the maximum twin sum of the linked list is max(7, 4) = 7.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is an even integer in the range [2, 105].\n\n\t- 1 <= Node.val <= 105",
  },
];

console.log("Candidate pool size:", questionsToAdd.length);

const toAdd = [];
const seenSlugs = new Set();

for (const q of questionsToAdd) {
  if (existingSlugs.has(q.slug)) {
    console.log("Skipping already existing:", q.slug);
    continue;
  }
  if (seenSlugs.has(q.slug)) {
    console.log("Skipping duplicate candidate:", q.slug);
    continue;
  }
  seenSlugs.add(q.slug);
  toAdd.push(q);
}

console.log("Total unique to add:", toAdd.length);

if (toAdd.length === 100) {
  const updatedProblems = [...existingProblems];
  const updatedStatements = { ...existingStatements };

  for (const item of toAdd) {
    const { statement, ...problemData } = item;
    // Validate schema
    if (
      !problemData.slug ||
      !problemData.title ||
      !problemData.difficulty ||
      !Array.isArray(problemData.topics) ||
      !Array.isArray(problemData.companies)
    ) {
      throw new Error(`Invalid schema for problem ${item.slug}`);
    }
    updatedProblems.push(problemData);
    updatedStatements[item.slug] = statement;
  }

  fs.writeFileSync(problemsPath, JSON.stringify(updatedProblems, null, 2) + "\n", "utf-8");
  fs.writeFileSync(statementsPath, JSON.stringify(updatedStatements, null, 2) + "\n", "utf-8");
  console.log(
    "SUCCESS! Added 100 problems. New total problems:",
    updatedProblems.length,
    "New total statements:",
    Object.keys(updatedStatements).length,
  );
} else {
  console.log("Need adjustments to match exactly 100. Count is:", toAdd.length);
}
