const fs = require("fs");
const path = require("path");

const problemsPath = path.join(__dirname, "../src/data/problems.json");
const statementsPath = path.join(__dirname, "../src/data/statements.json");

const existingProblems = JSON.parse(fs.readFileSync(problemsPath, "utf-8"));
const existingStatements = JSON.parse(fs.readFileSync(statementsPath, "utf-8"));
const existingSlugs = new Set(existingProblems.map((p) => p.slug));

// 100 High-Importance LeetCode Problems Dataset
const hundredProblems = [
  // 1. Invert Binary Tree
  {
    slug: "invert-binary-tree",
    title: "Invert Binary Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["google", "amazon", "meta", "microsoft", "apple", "bloomberg"],
    freq: 98.0,
    statement:
      "Given the root of a binary tree, invert the tree, and return its root.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [4,2,7,1,3,6,9]\nOutput: [4,7,2,9,6,3,1]\n```\n\nExample 2:\n\n```\nInput: root = [2,1,3]\nOutput: [2,3,1]\n```\n\nExample 3:\n\n```\nInput: root = []\nOutput: []\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 100].\n\n\t- -100 <= Node.val <= 100",
  },
  // 2. Subtree of Another Tree
  {
    slug: "subtree-of-another-tree",
    title: "Subtree of Another Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "String Matching", "Binary Tree", "Hash Function"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 85.0,
    statement:
      "Given the roots of two binary trees root and subRoot, return true if there is a subtree of root with the same structure and node values of subRoot and false otherwise.\n\nA subtree of a binary tree tree is a tree that consists of a node in tree and all of this node's descendants. The tree tree could also be considered as a subtree of itself.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,4,5,1,2], subRoot = [4,1,2]\nOutput: true\n```\n\nExample 2:\n\n```\nInput: root = [3,4,5,1,2,null,null,null,null,0], subRoot = [4,1,2]\nOutput: false\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the root tree is in the range [1, 2000].\n\n\t- The number of nodes in the subRoot tree is in the range [1, 1000].\n\n\t- -104 <= root.val <= 104\n\n\t- -104 <= subRoot.val <= 104",
  },
  // 3. Lowest Common Ancestor of a BST
  {
    slug: "lowest-common-ancestor-of-a-binary-search-tree",
    title: "Lowest Common Ancestor of a Binary Search Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "meta", "microsoft", "google", "bloomberg"],
    freq: 92.0,
    statement:
      "Given a binary search tree (BST), find the lowest common ancestor (LCA) node of two given nodes in the BST.\n\nAccording to the definition of LCA on Wikipedia: “The lowest common ancestor is defined between two nodes p and q as the lowest node in T that has both p and q as descendants (where we allow a node to be a descendant of itself).”\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 8\nOutput: 6\nExplanation: The LCA of nodes 2 and 8 is 6.\n```\n\nExample 2:\n\n```\nInput: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 4\nOutput: 2\nExplanation: The LCA of nodes 2 and 4 is 2, since a node can be a descendant of itself according to the LCA definition.\n```\n\nExample 3:\n\n```\nInput: root = [2,1], p = 2, q = 1\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [2, 105].\n\n\t- -109 <= Node.val <= 109\n\n\t- All Node.val are unique.\n\n\t- p != q\n\n\t- p and q will exist in the BST.",
  },
  // 4. Count Good Nodes in Binary Tree
  {
    slug: "count-good-nodes-in-binary-tree",
    title: "Count Good Nodes in Binary Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["microsoft", "amazon", "meta", "google"],
    freq: 86.0,
    statement:
      "Given a binary tree root, a node X in the tree is named good if in the path from the root to X there are no nodes with a value greater than X.\n\nReturn the number of good nodes in the binary tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,1,4,3,null,1,5]\nOutput: 4\nExplanation: Nodes in blue are good.\nRoot Node (3) is always a good node.\nNode 4 -> (3,4) is the maximum value in the path starting from the root.\nNode 5 -> (3,4,5) is the maximum value in the path\nNode 3 -> (3,1,3) is the maximum value in the path.\n```\n\nExample 2:\n\n```\nInput: root = [3,3,null,4,2]\nOutput: 3\n```\n\nExample 3:\n\n```\nInput: root = [1]\nOutput: 1\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the binary tree is in the range [1, 10^5].\n\n\t- Each node's value is between [-10^4, 10^4].",
  },
  // 5. Evaluate Reverse Polish Notation
  {
    slug: "evaluate-reverse-polish-notation",
    title: "Evaluate Reverse Polish Notation",
    difficulty: "Medium",
    topics: ["Array", "Math", "Stack"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 91.0,
    statement:
      'You are given an array of strings tokens that represents an arithmetic expression in a Reverse Polish Notation.\n\nEvaluate the expression. Return an integer that represents the value of the expression.\n\nNote that:\n\n\t- The valid operators are \'+\', \'-\', \'*\', and \'/\'.\n\n\t- Each operand may be an integer or another expression.\n\n\t- The division between two integers always truncates toward zero.\n\n\t- There will not be any division by zero.\n\n\t- The input represents a valid arithmetic expression in a reverse polish notation.\n\n\t- The answer and all the intermediate calculations can be represented in a 32-bit integer.\n\n\u00a0\n\nExample 1:\n\n```\nInput: tokens = ["2","1","+","3","*"]\nOutput: 9\nExplanation: ((2 + 1) * 3) = 9\n```\n\nExample 2:\n\n```\nInput: tokens = ["4","13","5","/","+"]\nOutput: 6\nExplanation: (4 + (13 / 5)) = 6\n```\n\nExample 3:\n\n```\nInput: tokens = ["10","6","9","3","+","-11","*","/","*","17","+","5","+"]\nOutput: 22\nExplanation: ((10 * (6 / ((9 + 3) * -11))) + 17) + 5\n= ((10 * (6 / (12 * -11))) + 17) + 5\n= ((10 * (6 / -132)) + 17) + 5\n= ((10 * 0) + 17) + 5\n= (0 + 17) + 5\n= 17 + 5\n= 22\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= tokens.length <= 104\n\n\t- tokens[i] is either an operator: "+", "-", "*", or "/", or an integer in the range [-200, 200].',
  },
  // 6. Car Fleet
  {
    slug: "car-fleet",
    title: "Car Fleet",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Sorting", "Monotonic Stack"],
    companies: ["google", "amazon", "meta", "uber"],
    freq: 88.0,
    statement:
      "There are n cars at given miles away from the starting mile 0, traveling to reach the mile target.\n\nYou are given two integer arrays position and speed, both of length n, where position[i] is the position of the ith car and speed[i] is the speed of the ith car (in miles per hour).\n\nA car cannot pass another car ahead of it, but it can catch up to it and drive bumper to bumper at the same speed. The faster car will slow down to match the slower car's speed. The distance between these two cars is ignored (i.e., they are assumed to have the same position).\n\nA car fleet is some non-empty set of cars driving at the same position and same speed. Note that a single car is also a car fleet.\n\nIf a car catches up to a car fleet right at the destination point, it will still be considered as one car fleet.\n\nReturn the number of car fleets that will arrive at the destination.\n\n\u00a0\n\nExample 1:\n\n```\nInput: target = 12, position = [10,8,0,5,3], speed = [2,4,1,1,3]\nOutput: 3\nExplanation:\nThe cars starting at 10 (speed 2) and 8 (speed 4) become a fleet, meeting each other at 12.\nThe car starting at 0 (speed 1) does not catch up to any other car, so it is a fleet by itself.\nThe cars starting at 5 (speed 1) and 3 (speed 3) become a fleet, meeting each other at 6. The fleet moves at speed 1 until it reaches target.\n```\n\nExample 2:\n\n```\nInput: target = 10, position = [3], speed = [3]\nOutput: 1\nExplanation: There is only one car, hence there is only one fleet.\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == position.length == speed.length\n\n\t- 1 <= n <= 105\n\n\t- 0 < target <= 106\n\n\t- 0 <= position[i] < target\n\n\t- All the values of position are unique.\n\n\t- 0 < speed[i] <= 106",
  },
  // 7. Asteroid Collision
  {
    slug: "asteroid-collision",
    title: "Asteroid Collision",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Simulation"],
    companies: ["amazon", "meta", "google", "microsoft", "tiktok"],
    freq: 89.0,
    statement:
      "We are given an array asteroids of integers representing asteroids in a row.\n\nFor each asteroid, the absolute value represents its size, and the sign represents its direction (positive meaning right, negative meaning left). Each asteroid moves at the same speed.\n\nFind out the state of the asteroids after all collisions. If two asteroids meet, the smaller one will explode. If both are the same size, both will explode. Two asteroids moving in the same direction will never meet.\n\n\u00a0\n\nExample 1:\n\n```\nInput: asteroids = [5,10,-5]\nOutput: [5,10]\nExplanation: The 10 and -5 collide resulting in 10. The 5 and 10 never collide.\n```\n\nExample 2:\n\n```\nInput: asteroids = [8,-8]\nOutput: []\nExplanation: The 8 and -8 collide exploding each other.\n```\n\nExample 3:\n\n```\nInput: asteroids = [10,2,-5]\nOutput: [10]\nExplanation: The 2 and -5 collide resulting in -5. The 10 and -5 collide resulting in 10.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= asteroids.length <= 104\n\n\t- -1000 <= asteroids[i] <= 1000\n\n\t- asteroids[i] != 0",
  },
  // 8. Online Stock Span
  {
    slug: "online-stock-span",
    title: "Online Stock Span",
    difficulty: "Medium",
    topics: ["Stack", "Design", "Monotonic Stack", "Data Stream"],
    companies: ["amazon", "microsoft", "meta", "bloomberg"],
    freq: 84.0,
    statement:
      'Design an algorithm that collects daily price quotes for some stock and returns the span of that stock\'s price for the current day.\n\nThe span of the stock\'s price in one day is the maximum number of consecutive days (starting from that day and going backward) for which the stock price was less than or equal to the price of that day.\n\nImplement the StockSpanner class:\n\n\t- StockSpanner() Initializes the object of the class.\n\n\t- int next(int price) Returns the span of the stock\'s price given that today\'s price is price.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["StockSpanner", "next", "next", "next", "next", "next", "next", "next"]\n[[], [100], [80], [60], [70], [60], [75], [85]]\nOutput\n[null, 1, 1, 1, 2, 1, 4, 6]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= price <= 105\n\n\t- At most 104 calls will be made to next.',
  },
  // 9. Next Greater Element I
  {
    slug: "next-greater-element-i",
    title: "Next Greater Element I",
    difficulty: "Easy",
    topics: ["Array", "Hash Table", "Stack", "Monotonic Stack"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 82.0,
    statement:
      "The next greater element of some element x in an array is the first greater element that is to the right of x in the same array.\n\nYou are given two distinct 0-indexed integer arrays nums1 and nums2, where nums1 is a subset of nums2.\n\nFor each 0 <= i < nums1.length, find the index j such that nums1[i] == nums2[j] and determine the next greater element of nums2[j] in nums2. If there is no next greater element, then the answer for this query is -1.\n\nReturn an array ans of length nums1.length such that ans[i] is the next greater element as described above.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums1 = [4,1,2], nums2 = [1,3,4,2]\nOutput: [-1,3,-1]\n```\n\nExample 2:\n\n```\nInput: nums1 = [2,4], nums2 = [1,2,3,4]\nOutput: [3,-1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums1.length <= nums2.length <= 1000\n\n\t- 0 <= nums1[i], nums2[i] <= 104\n\n\t- All integers in nums1 and nums2 are unique.\n\n\t- All the integers of nums1 also appear in nums2.",
  },
  // 10. Next Greater Element II
  {
    slug: "next-greater-element-ii",
    title: "Next Greater Element II",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Monotonic Stack"],
    companies: ["amazon", "google", "meta", "microsoft"],
    freq: 85.0,
    statement:
      "Given a circular integer array nums (i.e., the next element of nums[nums.length - 1] is nums[0]), return the next greater number for every element in nums.\n\nThe next greater number of a number x is the first greater number to its traversing-order next in the array, which means you could search circularly to find its next greater number. If it doesn't exist, return -1 for this number.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,1]\nOutput: [2,-1,2]\nExplanation: The first 1's next greater number is 2; The number 2 can't find next greater number. The second 1's next greater number needs to search circularly, which is also 2.\n```\n\nExample 2:\n\n```\nInput: nums = [1,2,3,4,3]\nOutput: [2,3,4,-1,4]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 104\n\n\t- -109 <= nums[i] <= 109",
  },
  // 11. 132 Pattern
  {
    slug: "132-pattern",
    title: "132 Pattern",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Stack", "Monotonic Stack", "Ordered Set"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 81.0,
    statement:
      "Given an array of n integers nums, a 132 pattern is a subsequence of three integers nums[i], nums[j] and nums[k] such that i < j < k and nums[i] < nums[k] < nums[j].\n\nReturn true if there is a 132 pattern in nums, otherwise, return false.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,3,4]\nOutput: false\nExplanation: There is no 132 pattern in the sequence.\n```\n\nExample 2:\n\n```\nInput: nums = [3,1,4,2]\nOutput: true\nExplanation: There is a 132 pattern in the sequence: [1, 4, 2].\n```\n\nExample 3:\n\n```\nInput: nums = [-1,3,2,0]\nOutput: true\nExplanation: There are three 132 patterns in the sequence: [-1, 3, 2], [-1, 3, 0] and [-1, 2, 0].\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == nums.length\n\n\t- 1 <= n <= 2 * 105\n\n\t- -109 <= nums[i] <= 109",
  },
  // 12. Remove All Adjacent Duplicates in String II
  {
    slug: "remove-all-adjacent-duplicates-in-string-ii",
    title: "Remove All Adjacent Duplicates in String II",
    difficulty: "Medium",
    topics: ["String", "Stack"],
    companies: ["bloomberg", "amazon", "meta", "google"],
    freq: 83.0,
    statement:
      'You are given a string s and an integer k, a k duplicate removal consists of choosing k adjacent and equal letters from s and removing them, causing the left and the right side of the deleted substring to concatenate together.\n\nWe repeatedly make k duplicate removals on s until we no longer can.\n\nReturn the final string after all such duplicate removals have been made. It is guaranteed that the answer is unique.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "abcd", k = 2\nOutput: "abcd"\nExplanation: There\'s nothing to delete.\n```\n\nExample 2:\n\n```\nInput: s = "deeedbbcccbdaa", k = 3\nOutput: "aa"\nExplanation: \nFirst delete "eee" and "ccc", get "ddbbbdaa"\nThen delete "bbb", get "dddaa"\nFinally delete "ddd", get "aa"\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 105\n\n\t- 2 <= k <= 104\n\n\t- s only contains lowercase English letters.',
  },
  // 13. Sum of Subarray Minimums
  {
    slug: "sum-of-subarray-minimums",
    title: "Sum of Subarray Minimums",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Stack", "Monotonic Stack"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 87.0,
    statement:
      "Given an array of integers arr, find the sum of min(b), where b ranges over every (contiguous) subarray of arr. Since the answer may be large, return the answer modulo 109 + 7.\n\n\u00a0\n\nExample 1:\n\n```\nInput: arr = [3,1,2,4]\nOutput: 17\nExplanation: \nSubarrays are [3], [1], [2], [4], [3,1], [1,2], [2,4], [3,1,2], [1,2,4], [3,1,2,4].\nMinimums are 3, 1, 2, 4, 1, 1, 2, 1, 1, 1.\nSum is 17.\n```\n\nExample 2:\n\n```\nInput: arr = [11,81,94,43,3]\nOutput: 444\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= arr.length <= 3 * 104\n\n\t- 1 <= arr[i] <= 3 * 104",
  },
  // 14. Maximal Rectangle
  {
    slug: "maximal-rectangle",
    title: "Maximal Rectangle",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming", "Stack", "Matrix", "Monotonic Stack"],
    companies: ["amazon", "google", "meta", "microsoft", "apple"],
    freq: 86.0,
    statement:
      'Given a rows x cols binary matrix filled with 0\'s and 1\'s, find the largest rectangle containing only 1\'s and return its area.\n\n\u00a0\n\nExample 1:\n\n```\nInput: matrix = [["1","0","1","0","0"],["1","0","1","1","1"],["1","1","1","1","1"],["1","0","0","1","0"]]\nOutput: 6\nExplanation: The maximal rectangle is shown in the above grid with area = 6.\n```\n\nExample 2:\n\n```\nInput: matrix = [["0"]]\nOutput: 0\n```\n\n\u00a0\n\nConstraints:\n\n\t- rows == matrix.length\n\n\t- cols == matrix[i].length\n\n\t- 1 <= row, cols <= 200\n\n\t- matrix[i][j] is \'0\' or \'1\'.',
  },
  // 15. Remove Element
  {
    slug: "remove-element",
    title: "Remove Element",
    difficulty: "Easy",
    topics: ["Array", "Two Pointers"],
    companies: ["amazon", "google", "meta", "microsoft", "apple"],
    freq: 92.0,
    statement:
      "Given an integer array nums and an integer val, remove all occurrences of val in nums in-place. The order of the elements may be changed. Then return the number of elements in nums which are not equal to val.\n\nConsider the number of elements in nums which are not equal to val be k, to get accepted, you need to do the following things:\n\n\t- Change the array nums such that the first k elements of nums contain the elements which are not equal to val. The remaining elements of nums are not important as well as the size of nums.\n\n\t- Return k.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [3,2,2,3], val = 3\nOutput: 2, nums = [2,2,_,_]\nExplanation: Your function should return k = 2, with the first two elements of nums being 2.\nIt does not matter what you leave beyond the returned k (hence they are underscores).\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= nums.length <= 100\n\n\t- 0 <= nums[i] <= 50\n\n\t- 0 <= val <= 100",
  },
  // 16. Remove Duplicates from Sorted Array
  {
    slug: "remove-duplicates-from-sorted-array",
    title: "Remove Duplicates from Sorted Array",
    difficulty: "Easy",
    topics: ["Array", "Two Pointers"],
    companies: ["meta", "amazon", "google", "microsoft", "apple", "bloomberg"],
    freq: 96.0,
    statement:
      "Given an integer array nums sorted in non-decreasing order, remove the duplicates in-place such that each unique element appears only once. The relative order of the elements should be kept the same. Then return the number of unique elements in nums.\n\nConsider the number of unique elements of nums to be k, to get accepted, you need to do the following things:\n\n\t- Change the array nums such that the first k elements of nums contain the unique elements in the order they were present in nums initially. The remaining elements of nums are not important as well as the size of nums.\n\n\t- Return k.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,2]\nOutput: 2, nums = [1,2,_]\nExplanation: Your function should return k = 2, with the first two elements of nums being 1 and 2 respectively.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 3 * 104\n\n\t- -100 <= nums[i] <= 100\n\n\t- nums is sorted in non-decreasing order.",
  },
  // 17. Remove Duplicates from Sorted Array II
  {
    slug: "remove-duplicates-from-sorted-array-ii",
    title: "Remove Duplicates from Sorted Array II",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers"],
    companies: ["meta", "amazon", "microsoft", "google"],
    freq: 89.0,
    statement:
      "Given an integer array nums sorted in non-decreasing order, remove some duplicates in-place such that each unique element appears at most twice. The relative order of the elements should be kept the same.\n\nSince it is impossible to change the length of the array in some languages, you must instead have the result be placed in the first part of the array nums. More formally, if there are k elements after removing the duplicates, then the first k elements of nums should hold the final result. It does not matter what you leave beyond the first k elements.\n\nReturn k after placing the final result in the first k slots of nums.\n\nDo not allocate extra space for another array. You must do this by modifying the input array in-place with O(1) extra memory.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,1,2,2,3]\nOutput: 5, nums = [1,1,2,2,3,_]\nExplanation: Your function should return k = 5, with the first five elements of nums being 1, 1, 2, 2 and 3 respectively.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 3 * 104\n\n\t- -104 <= nums[i] <= 104\n\n\t- nums is sorted in non-decreasing order.",
  },
  // 18. Ransom Note
  {
    slug: "ransom-note",
    title: "Ransom Note",
    difficulty: "Easy",
    topics: ["Hash Table", "String", "Counting"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 90.0,
    statement:
      'Given two strings ransomNote and magazine, return true if ransomNote can be constructed by using the letters from magazine and false otherwise.\n\nEach letter in magazine can only be used once in ransomNote.\n\n\u00a0\n\nExample 1:\n\n```\nInput: ransomNote = "a", magazine = "b"\nOutput: false\n```\n\nExample 2:\n\n```\nInput: ransomNote = "aa", magazine = "ab"\nOutput: false\n```\n\nExample 3:\n\n```\nInput: ransomNote = "aa", magazine = "aab"\nOutput: true\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= ransomNote.length, magazine.length <= 105\n\n\t- ransomNote and magazine consist of lowercase English letters.',
  },
  // 19. Is Subsequence
  {
    slug: "is-subsequence",
    title: "Is Subsequence",
    difficulty: "Easy",
    topics: ["Two Pointers", "String", "Dynamic Programming"],
    companies: ["amazon", "google", "meta", "microsoft"],
    freq: 91.0,
    statement:
      'Given two strings s and t, return true if s is a subsequence of t, or false otherwise.\n\nA subsequence of a string is a new string that is formed from the original string by deleting some (can be none) of the characters without disturbing the relative positions of the remaining characters. (i.e., "ace" is a subsequence of "abcde" while "aec" is not).\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "abc", t = "ahbgdc"\nOutput: true\n```\n\nExample 2:\n\n```\nInput: s = "axc", t = "ahbgdc"\nOutput: false\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= s.length <= 100\n\n\t- 0 <= t.length <= 104\n\n\t- s and t consist only of lowercase English letters.',
  },
  // 20. Summary Ranges
  {
    slug: "summary-ranges",
    title: "Summary Ranges",
    difficulty: "Easy",
    topics: ["Array"],
    companies: ["google", "meta", "amazon", "microsoft"],
    freq: 85.0,
    statement:
      'You are given a sorted unique integer array nums.\n\nA range [a,b] is the set of all integers from a to b (inclusive).\n\nReturn the smallest sorted list of ranges that cover all the numbers in the array exactly. That is, each element of nums is covered by exactly one of the ranges, and there is no integer x such that x is in one of the ranges but not in nums.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [0,1,2,4,5,7]\nOutput: ["0->2","4->5","7"]\nExplanation: The ranges are:\n[0,2] --> "0->2"\n[4,5] --> "4->5"\n[7,7] --> "7"\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= nums.length <= 20\n\n\t- -231 <= nums[i] <= 231 - 1\n\n\t- All the values of nums are unique.\n\n\t- nums is sorted in ascending order.',
  },
  // 21. H-Index
  {
    slug: "h-index",
    title: "H-Index",
    difficulty: "Medium",
    topics: ["Array", "Sorting", "Counting Sort"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 87.0,
    statement:
      "Given an array of integers citations where citations[i] is the number of citations a researcher received for their ith paper, return the researcher's h-index.\n\nAccording to the definition of h-index on Wikipedia: The h-index is defined as the maximum value of h such that the given researcher has published at least h papers that have each been cited at least h times.\n\n\u00a0\n\nExample 1:\n\n```\nInput: citations = [3,0,6,1,5]\nOutput: 3\nExplanation: [3,0,6,1,5] means the researcher has 5 papers in total and each of them had received 3, 0, 6, 1, 5 citations respectively.\nSince the researcher has 3 papers with at least 3 citations each and the remaining two with no more than 3 citations each, their h-index is 3.\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == citations.length\n\n\t- 1 <= n <= 5000\n\n\t- 0 <= citations[i] <= 1000",
  },
  // 22. Candy
  {
    slug: "candy",
    title: "Candy",
    difficulty: "Hard",
    topics: ["Array", "Greedy"],
    companies: ["google", "amazon", "meta", "microsoft", "apple"],
    freq: 90.0,
    statement:
      "There are n children standing in a line. Each child is assigned a rating value given in the integer array ratings.\n\nYou are giving candies to these children subjected to the following requirements:\n\n\t- Each child must have at least one candy.\n\n\t- Children with a higher rating get more candies than their neighbors.\n\nReturn the minimum number of candies you need to have to distribute the candies to the children.\n\n\u00a0\n\nExample 1:\n\n```\nInput: ratings = [1,0,2]\nOutput: 5\nExplanation: You can allocate to the first, second and third child with 2, 1, 2 candies respectively.\n```\n\nExample 2:\n\n```\nInput: ratings = [1,2,2]\nOutput: 4\nExplanation: You can allocate to the first, second and third child with 1, 2, 1 candies respectively. The third child gets 1 candy because it satisfies the above two conditions.\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == ratings.length\n\n\t- 1 <= n <= 2 * 104\n\n\t- 0 <= ratings[i] <= 2 * 104",
  },
  // 23. Minimum Size Subarray Sum
  {
    slug: "minimum-size-subarray-sum",
    title: "Minimum Size Subarray Sum",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Sliding Window", "Prefix Sum"],
    companies: ["meta", "amazon", "google", "microsoft", "apple"],
    freq: 89.0,
    statement:
      "Given an array of positive integers nums and a positive integer target, return the minimal length of a subarray whose sum is greater than or equal to target. If there is no such subarray, return 0 instead.\n\n\u00a0\n\nExample 1:\n\n```\nInput: target = 7, nums = [2,3,1,2,4,3]\nOutput: 2\nExplanation: The subarray [4,3] has the minimal length under the problem constraint.\n```\n\nExample 2:\n\n```\nInput: target = 4, nums = [1,4,4]\nOutput: 1\n```\n\nExample 3:\n\n```\nInput: target = 11, nums = [1,1,1,1,1,1,1,1]\nOutput: 0\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= target <= 109\n\n\t- 1 <= nums.length <= 105\n\n\t- 1 <= nums[i] <= 104",
  },
  // 24. Substring with Concatenation of All Words
  {
    slug: "substring-with-concatenation-of-all-words",
    title: "Substring with Concatenation of All Words",
    difficulty: "Hard",
    topics: ["Hash Table", "String", "Sliding Window"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 80.0,
    statement:
      'You are given a string s and an array of strings words. All the strings of words are of the same length.\n\nA concatenated string is a string that exactly contains all the strings of any permutation of words concatenated.\n\nReturn an array of the starting indices of all the concatenated substrings in s. You can return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "barfoothefoobarman", words = ["foo","bar"]\nOutput: [0,9]\nExplanation: The substring starting at 0 is "barfoo". It is the concatenation of ["bar","foo"] which is a permutation of words.\nThe substring starting at 9 is "foobar". It is the concatenation of ["foo","bar"] which is a permutation of words.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 104\n\n\t- 1 <= words.length <= 5000\n\n\t- 1 <= words[i].length <= 30\n\n\t- s and words[i] consist of lowercase English letters.',
  },
  // 25. 4Sum
  {
    slug: "4sum",
    title: "4Sum",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Sorting"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 85.0,
    statement:
      "Given an array nums of n integers, return an array of all the unique quadruplets [nums[a], nums[b], nums[c], nums[d]] such that:\n\n\t- 0 <= a, b, c, d < n\n\n\t- a, b, c, and d are distinct.\n\n\t- nums[a] + nums[b] + nums[c] + nums[d] == target\n\nYou may return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,0,-1,0,-2,2], target = 0\nOutput: [[-2,-1,1,2],[-2,0,0,2],[-1,0,0,1]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 200\n\n\t- -109 <= nums[i] <= 109\n\n\t- -109 <= target <= 109",
  },
  // 26. 3Sum Closest
  {
    slug: "3sum-closest",
    title: "3Sum Closest",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Sorting"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 86.0,
    statement:
      "Given an integer array nums of length n and an integer target, find three integers in nums such that the sum is closest to target.\n\nReturn the sum of the three integers.\n\nYou may assume that each input would have exactly one solution.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [-1,2,1,-4], target = 1\nOutput: 2\nExplanation: The sum that is closest to the target is 2. (-1 + 2 + 1 = 2).\n```\n\n\u00a0\n\nConstraints:\n\n\t- 3 <= nums.length <= 500\n\n\t- -1000 <= nums[i] <= 1000\n\n\t- -104 <= target <= 104",
  },
  // 27. Two Sum II - Input Array Is Sorted
  {
    slug: "two-sum-ii-input-array-is-sorted",
    title: "Two Sum II - Input Array Is Sorted",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Binary Search"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 95.0,
    statement:
      "Given a 1-indexed array of integers numbers that is already sorted in non-decreasing order, find two numbers such that they add up to a specific target number. Let these two numbers be numbers[index1] and numbers[index2] where 1 <= index1 < index2 <= numbers.length.\n\nReturn the indices of the two numbers, index1 and index2, added by one as an integer array [index1, index2] of length 2.\n\nThe tests are generated such that there is exactly one solution. You may not use the same element twice.\n\nYour solution must use only constant extra space.\n\n\u00a0\n\nExample 1:\n\n```\nInput: numbers = [2,7,11,15], target = 9\nOutput: [1,2]\nExplanation: The sum of 2 and 7 is 9. Therefore, index1 = 1, index2 = 2. We return [1, 2].\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= numbers.length <= 3 * 104\n\n\t- -1000 <= numbers[i] <= 1000\n\n\t- numbers is sorted in non-decreasing order.\n\n\t- -1000 <= target <= 1000\n\n\t- The tests are generated such that there is exactly one solution.",
  },
  // 28. Remove Duplicates from Sorted List
  {
    slug: "remove-duplicates-from-sorted-list",
    title: "Remove Duplicates from Sorted List",
    difficulty: "Easy",
    topics: ["Linked List"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 88.0,
    statement:
      "Given the head of a sorted linked list, delete all duplicates such that each element appears only once. Return the linked list sorted as well.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,1,2]\nOutput: [1,2]\n```\n\nExample 2:\n\n```\nInput: head = [1,1,2,3,3]\nOutput: [1,2,3]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 300].\n\n\t- -100 <= Node.val <= 100\n\n\t- The list is guaranteed to be sorted in ascending order.",
  },
  // 29. Remove Duplicates from Sorted List II
  {
    slug: "remove-duplicates-from-sorted-list-ii",
    title: "Remove Duplicates from Sorted List II",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 87.0,
    statement:
      "Given the head of a sorted linked list, delete all nodes that have duplicate numbers, leaving only distinct numbers from the original list. Return the linked list sorted as well.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,3,4,4,5]\nOutput: [1,2,5]\n```\n\nExample 2:\n\n```\nInput: head = [1,1,1,2,3]\nOutput: [2,3]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 300].\n\n\t- -100 <= Node.val <= 100\n\n\t- The list is guaranteed to be sorted in ascending order.",
  },
  // 30. Partition List
  {
    slug: "partition-list",
    title: "Partition List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 86.0,
    statement:
      "Given the head of a linked list and a value x, partition it such that all nodes less than x come before nodes greater than or equal to x.\n\nYou should preserve the original relative order of the nodes in each of the two partitions.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,4,3,2,5,2], x = 3\nOutput: [1,2,2,4,3,5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 200].\n\n\t- -100 <= Node.val <= 100\n\n\t- -200 <= x <= 200",
  },
  // 31. Reverse Linked List II
  {
    slug: "reverse-linked-list-ii",
    title: "Reverse Linked List II",
    difficulty: "Medium",
    topics: ["Linked List"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 92.0,
    statement:
      "Given the head of a singly linked list and two integers left and right where left <= right, reverse the nodes of the list from position left to position right, and return the reversed list.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,4,5], left = 2, right = 4\nOutput: [1,4,3,2,5]\n```\n\nExample 2:\n\n```\nInput: head = [5], left = 1, right = 1\nOutput: [5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is n.\n\n\t- 1 <= n <= 500\n\n\t- -500 <= Node.val <= 500\n\n\t- 1 <= left <= right <= n",
  },
  // 32. Swap Nodes in Pairs
  {
    slug: "swap-nodes-in-pairs",
    title: "Swap Nodes in Pairs",
    difficulty: "Medium",
    topics: ["Linked List", "Recursion"],
    companies: ["amazon", "meta", "microsoft", "google", "apple"],
    freq: 90.0,
    statement:
      "Given a\u00a0linked list, swap every two adjacent nodes and return its head. You must solve the problem without\u00a0modifying the values in the list's nodes (i.e., only nodes themselves may be changed.)\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,4]\nOutput: [2,1,4,3]\n```\n\nExample 2:\n\n```\nInput: head = []\nOutput: []\n```\n\nExample 3:\n\n```\nInput: head = [1]\nOutput: [1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 100].\n\n\t- 0 <= Node.val <= 100",
  },
  // 33. Reverse Nodes in k-Group
  {
    slug: "reverse-nodes-in-k-group",
    title: "Reverse Nodes in k-Group",
    difficulty: "Hard",
    topics: ["Linked List", "Recursion"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg", "tiktok"],
    freq: 95.0,
    statement:
      "Given the head of a linked list, reverse the nodes of the list k at a time, and return the modified list.\n\nk is a positive integer and is less than or equal to the length of the linked list. If the number of nodes is not a multiple of k then left-out nodes, in the end, should remain as it is.\n\nYou may not alter the values in the list's nodes, only nodes themselves may be changed.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,4,5], k = 2\nOutput: [2,1,4,3,5]\n```\n\nExample 2:\n\n```\nInput: head = [1,2,3,4,5], k = 3\nOutput: [3,2,1,4,5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is n.\n\n\t- 1 <= k <= n <= 5000\n\n\t- 0 <= Node.val <= 1000",
  },
  // 34. Rotate List
  {
    slug: "rotate-list",
    title: "Rotate List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 88.0,
    statement:
      "Given the head of a linked\u00a0list, rotate the list to the right by k places.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,4,5], k = 2\nOutput: [4,5,1,2,3]\n```\n\nExample 2:\n\n```\nInput: head = [0,1,2], k = 4\nOutput: [2,0,1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [0, 500].\n\n\t- -100 <= Node.val <= 100\n\n\t- 0 <= k <= 2 * 109",
  },
  // 35. Odd Even Linked List
  {
    slug: "odd-even-linked-list",
    title: "Odd Even Linked List",
    difficulty: "Medium",
    topics: ["Linked List"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 89.0,
    statement:
      "Given the head of a singly linked list, group all the nodes with odd indices together followed by the nodes with even indices, and return the reordered list.\n\nThe first node is considered odd, and the second node is even, and so on.\n\nNote that the relative order inside both the even and odd groups should remain as it was in the input.\n\nYou must solve the problem in O(1) extra space complexity and O(n) time complexity.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,3,4,5]\nOutput: [1,3,5,2,4]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the linked list is in the range [0, 104].\n\n\t- -106 <= Node.val <= 106",
  },
  // 36. Palindrome Linked List
  {
    slug: "palindrome-linked-list",
    title: "Palindrome Linked List",
    difficulty: "Easy",
    topics: ["Linked List", "Two Pointers", "Stack", "Recursion"],
    companies: ["amazon", "meta", "microsoft", "google", "apple"],
    freq: 94.0,
    statement:
      "Given the head of a singly linked list, return true if it is a palindrome or false otherwise.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [1,2,2,1]\nOutput: true\n```\n\nExample 2:\n\n```\nInput: head = [1,2]\nOutput: false\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [1, 105].\n\n\t- 0 <= Node.val <= 9\n\n\u00a0\n\nFollow up: Could you do it in O(n) time and O(1) space?",
  },
  // 37. Insertion Sort List
  {
    slug: "insertion-sort-list",
    title: "Insertion Sort List",
    difficulty: "Medium",
    topics: ["Linked List", "Sorting"],
    companies: ["amazon", "google", "microsoft"],
    freq: 78.0,
    statement:
      "Given the head of a singly linked list, sort the list using insertion sort, and return the sorted list's head.\n\nThe steps of the insertion sort algorithm:\n\n\t1. Insertion sort iterates, consuming one input element each repetition and growing a sorted output list.\n\n\t2. At each iteration, insertion sort removes one element from the input data, finds the location it belongs within the sorted list and inserts it there.\n\n\t3. It repeats until no input elements remain.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [4,2,1,3]\nOutput: [1,2,3,4]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the list is in the range [1, 5000].\n\n\t- -5000 <= Node.val <= 5000",
  },
  // 38. Path Sum III
  {
    slug: "path-sum-iii",
    title: "Path Sum III",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Binary Tree", "Prefix Sum"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement:
      "Given the root of a binary tree and an integer targetSum, return the number of paths where the sum of the values in the path equals targetSum.\n\nThe path does not need to start or end at the root or a leaf, but it must go downwards (i.e., traveling only from parent nodes to child nodes).\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [10,5,-3,3,2,null,11,3,-2,null,1], targetSum = 8\nOutput: 3\nExplanation: The paths that sum to 8 are shown.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 1000].\n\n\t- -109 <= Node.val <= 109\n\n\t- -1000 <= targetSum <= 1000",
  },
  // 39. Binary Tree Paths
  {
    slug: "binary-tree-paths",
    title: "Binary Tree Paths",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "String", "Backtracking", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 85.0,
    statement:
      'Given the root of a binary tree, return all root-to-leaf paths in any order.\n\nA leaf is a node with no children.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3,null,5]\nOutput: ["1->2->5","1->3"]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 100].\n\n\t- -100 <= Node.val <= 100',
  },
  // 40. Sum Root to Leaf Numbers
  {
    slug: "sum-root-to-leaf-numbers",
    title: "Sum Root to Leaf Numbers",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 89.0,
    statement:
      "You are given the root of a binary tree containing digits from 0 to 9 only.\n\nEach root-to-leaf path in the tree represents a number.\n\n\t- For example, the root-to-leaf path 1 -> 2 -> 3 represents the number 123.\n\nReturn the total sum of all root-to-leaf numbers. Test cases are generated so that the answer will fit in a 32-bit integer.\n\nA leaf node is a node with no children.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3]\nOutput: 25\nExplanation:\nThe root-to-leaf path 1->2 represents the number 12.\nThe root-to-leaf path 1->3 represents the number 13.\nTherefore, sum = 12 + 13 = 25.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 1000].\n\n\t- 0 <= Node.val <= 9\n\n\t- The depth of the tree will not exceed 10.",
  },
  // 41. Flatten Binary Tree to Linked List
  {
    slug: "flatten-binary-tree-to-linked-list",
    title: "Flatten Binary Tree to Linked List",
    difficulty: "Medium",
    topics: ["Linked List", "Stack", "Tree", "Depth-First Search", "Binary Tree"],
    companies: ["meta", "amazon", "microsoft", "google", "bloomberg"],
    freq: 91.0,
    statement:
      'Given the root of a binary tree, flatten the tree into a "linked list":\n\n\t- The "linked list" should use the same TreeNode class where the right child pointer points to the next node in the list and the left child pointer is always null.\n\n\t- The "linked list" should be in the same order as a pre-order traversal of the binary tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,5,3,4,null,6]\nOutput: [1,null,2,null,3,null,4,null,5,null,6]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 2000].\n\n\t- -100 <= Node.val <= 100',
  },
  // 42. Populating Next Right Pointers in Each Node
  {
    slug: "populating-next-right-pointers-in-each-node",
    title: "Populating Next Right Pointers in Each Node",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Linked List", "Binary Tree"],
    companies: ["meta", "amazon", "microsoft", "google", "bloomberg"],
    freq: 90.0,
    statement:
      "You are given a perfect binary tree where all leaves are on the same level, and every parent has two children. The binary tree has the following definition:\n\n```\nstruct Node {\n  int val;\n  Node *left;\n  Node *right;\n  Node *next;\n};\n```\n\nPopulate each next pointer to point to its next right node. If there is no next right node, the next pointer should be set to NULL.\n\nInitially, all next pointers are set to NULL.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3,4,5,6,7]\nOutput: [1,#,2,3,#,4,5,6,7,#]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 212 - 1].\n\n\t- -1000 <= Node.val <= 1000",
  },
  // 43. Populating Next Right Pointers in Each Node II
  {
    slug: "populating-next-right-pointers-in-each-node-ii",
    title: "Populating Next Right Pointers in Each Node II",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Linked List", "Binary Tree"],
    companies: ["meta", "amazon", "microsoft", "google", "bloomberg"],
    freq: 88.0,
    statement:
      "Given a binary tree:\n\n```\nstruct Node {\n  int val;\n  Node *left;\n  Node *right;\n  Node *next;\n};\n```\n\nPopulate each next pointer to point to its next right node. If there is no next right node, the next pointer should be set to NULL.\n\nInitially, all next pointers are set to NULL.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,2,3,4,5,null,7]\nOutput: [1,#,2,3,#,4,5,7,#]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 6000].\n\n\t- -100 <= Node.val <= 100",
  },
  // 44. Binary Search Tree Iterator
  {
    slug: "binary-search-tree-iterator",
    title: "Binary Search Tree Iterator",
    difficulty: "Medium",
    topics: ["Stack", "Tree", "Design", "Binary Search Tree", "Binary Tree", "Iterator"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 91.0,
    statement:
      'Implement the BSTIterator class that represents an iterator over the in-order traversal of a binary search tree (BST):\n\n\t- BSTIterator(TreeNode root) Initializes an object of the BSTIterator class. The root of the BST is given as part of the constructor. The pointer should be initialized to a non-existent number smaller than any element in the BST.\n\n\t- boolean hasNext() Returns true if there exists a number in the traversal to the right of the pointer, otherwise returns false.\n\n\t- int next() Moves the pointer to the right, then returns the number at the pointer.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["BSTIterator", "next", "next", "hasNext", "next", "hasNext", "next", "hasNext", "next", "hasNext"]\n[[[7, 3, 15, null, null, 9, 20]], [], [], [], [], [], [], [], [], []]\nOutput\n[null, 3, 7, true, 9, true, 15, true, 20, false]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 105].\n\n\t- 0 <= Node.val <= 106\n\n\t- At most 105 calls will be made to hasNext, and next.',
  },
  // 45. Delete Node in a BST
  {
    slug: "delete-node-in-a-bst",
    title: "Delete Node in a BST",
    difficulty: "Medium",
    topics: ["Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "microsoft", "meta", "google"],
    freq: 86.0,
    statement:
      "Given a root node reference of a BST and a key, delete the node with the given key in the BST. Return the root node reference (possibly updated) of the BST.\n\nBasically, the deletion can be divided into two stages:\n\n\t1. Search for a node to remove.\n\n\t2. If the node is found, delete the node.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [5,3,6,2,4,null,7], key = 3\nOutput: [5,4,6,2,null,null,7]\nExplanation: Given key to delete is 3. So we find the node with value 3 and delete it.\nOne valid answer is [5,4,6,2,null,null,7], shown in the above BST.\nPlease notice that another valid answer is [5,2,6,null,4,null,7] and it's also accepted.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [0, 104].\n\n\t- -105 <= Node.val <= 105\n\n\t- Each node has a unique value.\n\n\t- root is a valid binary search tree.\n\n\t- -105 <= key <= 105",
  },
  // 46. Trim a Binary Search Tree
  {
    slug: "trim-a-binary-search-tree",
    title: "Trim a Binary Search Tree",
    difficulty: "Medium",
    topics: ["Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 82.0,
    statement:
      "Given the root of a binary search tree and the lowest and highest boundaries as low and high, trim the tree so that all its elements lie in [low, high]. Trimming the tree should not change the relative structure of the elements that will remain in the tree (i.e., any node's descendant should remain a descendant). It can be proven that there is a unique answer.\n\nReturn the root of the trimmed binary search tree. Note that the root may change depending on the given bounds.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,0,2], low = 1, high = 2\nOutput: [1,null,2]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 104].\n\n\t- 0 <= Node.val <= 104\n\n\t- The value of each node in the tree is unique.\n\n\t- root is guaranteed to be a valid binary search tree.\n\n\t- 0 <= low <= high <= 104",
  },
  // 47. Convert Sorted Array to Binary Search Tree
  {
    slug: "convert-sorted-array-to-binary-search-tree",
    title: "Convert Sorted Array to Binary Search Tree",
    difficulty: "Easy",
    topics: ["Array", "Divide and Conquer", "Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft", "apple"],
    freq: 92.0,
    statement:
      "Given an integer array nums where the elements are sorted in ascending order, convert it to a height-balanced binary search tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [-10,-3,0,5,9]\nOutput: [0,-3,9,-10,null,5]\nExplanation: [0,-10,5,null,-3,null,9] is also accepted.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 104\n\n\t- -104 <= nums[i] <= 104\n\n\t- nums is sorted in a strictly increasing order.",
  },
  // 48. Convert Sorted List to Binary Search Tree
  {
    slug: "convert-sorted-list-to-binary-search-tree",
    title: "Convert Sorted List to Binary Search Tree",
    difficulty: "Medium",
    topics: ["Linked List", "Divide and Conquer", "Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 85.0,
    statement:
      "Given the head of a singly linked list where elements are sorted in ascending order, convert it to a height-balanced binary search tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: head = [-10,-3,0,5,9]\nOutput: [0,-3,9,-10,null,5]\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in head is in the range [0, 2 * 104].\n\n\t- -105 <= Node.val <= 105",
  },
  // 49. Maximum Width of Binary Tree
  {
    slug: "maximum-width-of-binary-tree",
    title: "Maximum Width of Binary Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 88.0,
    statement:
      "Given the root of a binary tree, return the maximum width of the given tree.\n\nThe maximum width of a tree is the maximum width among all levels.\n\nThe width of one level is defined as the length between the end-nodes (the leftmost and rightmost non-null nodes), where the null nodes between the end-nodes that would be present in a complete binary tree extending down to that level are also counted into the length calculation.\n\nIt is guaranteed that the answer will in the range of a 32-bit signed integer.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [1,3,2,5,3,null,9]\nOutput: 4\nExplanation: The maximum width exists in the third level with length 4 (5,3,null,9).\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 3000].\n\n\t- -100 <= Node.val <= 100",
  },
  // 50. Binary Tree Cameras
  {
    slug: "binary-tree-cameras",
    title: "Binary Tree Cameras",
    difficulty: "Hard",
    topics: ["Dynamic Programming", "Tree", "Depth-First Search", "Binary Tree"],
    companies: ["google", "meta", "amazon", "microsoft"],
    freq: 83.0,
    statement:
      "You are given the root of a binary tree. We install cameras on the tree nodes where each camera at a node can monitor its parent, itself, and its immediate children.\n\nReturn the minimum number of cameras needed to monitor all nodes of the tree.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [0,0,null,0,0]\nOutput: 1\nExplanation: One camera is enough to monitor all nodes if placed as shown.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 1000].\n\n\t- Node.val == 0",
  },
  // 51. House Robber III
  {
    slug: "house-robber-iii",
    title: "House Robber III",
    difficulty: "Medium",
    topics: ["Dynamic Programming", "Tree", "Depth-First Search", "Binary Tree"],
    companies: ["google", "meta", "amazon", "microsoft"],
    freq: 89.0,
    statement:
      "The thief has found himself a new place for his thievery again. There is only one entrance to this area, called root.\n\nBesides the root, each house has one and only one parent house. After a tour, the smart thief realized that all houses in this place form a binary tree. It will automatically contact the police if two directly-linked houses were broken into on the same night.\n\nGiven the root of the binary tree, return the maximum amount of money the thief can rob without alerting the police.\n\n\u00a0\n\nExample 1:\n\n```\nInput: root = [3,2,3,null,3,null,1]\nOutput: 7\nExplanation: Maximum amount of money the thief can rob = 3 + 3 + 1 = 7.\n```\n\n\u00a0\n\nConstraints:\n\n\t- The number of nodes in the tree is in the range [1, 104].\n\n\t- 0 <= Node.val <= 104",
  },
  // 52. Search Insert Position
  {
    slug: "search-insert-position",
    title: "Search Insert Position",
    difficulty: "Easy",
    topics: ["Array", "Binary Search"],
    companies: ["google", "amazon", "meta", "microsoft", "apple"],
    freq: 95.0,
    statement:
      "Given a sorted array of distinct integers and a target value, return the index if the target is found. If not, return the index where it would be if it were inserted in order.\n\nYou must write an algorithm with O(log n) runtime complexity.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,3,5,6], target = 5\nOutput: 2\n```\n\nExample 2:\n\n```\nInput: nums = [1,3,5,6], target = 2\nOutput: 1\n```\n\nExample 3:\n\n```\nInput: nums = [1,3,5,6], target = 7\nOutput: 4\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 104\n\n\t- -104 <= nums[i] <= 104\n\n\t- nums contains distinct values sorted in ascending order.\n\n\t- -104 <= target <= 104",
  },
  // 53. Find First and Last Position of Element in Sorted Array
  {
    slug: "find-first-and-last-position-of-element-in-sorted-array",
    title: "Find First and Last Position of Element in Sorted Array",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["meta", "amazon", "google", "microsoft", "apple", "bloomberg"],
    freq: 94.0,
    statement:
      "Given an array of integers nums sorted in non-decreasing order, find the starting and ending position of a given target value.\n\nIf target is not found in the array, return [-1, -1].\n\nYou must write an algorithm with O(log n) runtime complexity.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [5,7,7,8,8,10], target = 8\nOutput: [3,4]\n```\n\nExample 2:\n\n```\nInput: nums = [5,7,7,8,8,10], target = 6\nOutput: [-1,-1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= nums.length <= 105\n\n\t- -109 <= nums[i] <= 109\n\n\t- nums is a non-decreasing array.\n\n\t- -109 <= target <= 109",
  },
  // 54. Search in Rotated Sorted Array II
  {
    slug: "search-in-rotated-sorted-array-ii",
    title: "Search in Rotated Sorted Array II",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 85.0,
    statement:
      "There is an integer array nums sorted in non-decreasing order (not necessarily with distinct values).\n\nBefore being passed to your function, nums is rotated at an unknown pivot index k (0 <= k < nums.length) such that the resulting array is [nums[k], nums[k+1], ..., nums[n-1], nums[0], nums[1], ..., nums[k-1]] (0-indexed).\n\nGiven the array nums after the rotation and an integer target, return true if target is in nums, or false if it is not in nums.\n\nYou must decrease the overall operation steps as much as possible.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [2,5,6,0,0,1,2], target = 0\nOutput: true\n```\n\nExample 2:\n\n```\nInput: nums = [2,5,6,0,0,1,2], target = 3\nOutput: false\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 5000\n\n\t- -104 <= nums[i] <= 104\n\n\t- nums is guaranteed to be rotated at some pivot.\n\n\t- -104 <= target <= 104",
  },
  // 55. Find Peak Element
  {
    slug: "find-peak-element",
    title: "Find Peak Element",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["meta", "amazon", "google", "microsoft", "apple", "bloomberg"],
    freq: 93.0,
    statement:
      "A peak element is an element that is strictly greater than its neighbors.\n\nGiven a 0-indexed integer array nums, find a peak element, and return its index. If the array contains multiple peaks, return the index to any of the peaks.\n\nYou may imagine that nums[-1] = nums[n] = -inf. In other words, an element is always considered to be strictly greater than a neighbor that is outside the array.\n\nYou must write an algorithm that runs in O(log n) time.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,3,1]\nOutput: 2\nExplanation: 3 is a peak element and your function should return the index number 2.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 1000\n\n\t- -231 <= nums[i] <= 231 - 1\n\n\t- nums[i] != nums[i + 1] for all valid i.",
  },
  // 56. Capacity To Ship Packages Within D Days
  {
    slug: "capacity-to-ship-packages-within-d-days",
    title: "Capacity To Ship Packages Within D Days",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["amazon", "meta", "google", "microsoft", "tiktok"],
    freq: 89.0,
    statement:
      "A conveyor belt has packages that must be shipped from one port to another within days days.\n\nThe ith package on the conveyor belt has a weight of weights[i]. Each day, we load the ship with packages on the conveyor belt (in the order given by weights). We may not load more weight than the maximum weight capacity of the ship.\n\nReturn the least weight capacity of the ship that will result in all the packages on the conveyor belt being shipped within days days.\n\n\u00a0\n\nExample 1:\n\n```\nInput: weights = [1,2,3,4,5,6,7,8,9,10], days = 5\nOutput: 15\nExplanation: A ship capacity of 15 is the minimum to ship all the packages in 5 days like this:\n1st day: 1, 2, 3, 4, 5\n2nd day: 6, 7\n3rd day: 8\n4th day: 9\n5th day: 10\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= days <= weights.length <= 5 * 104\n\n\t- 1 <= weights[i] <= 500",
  },
  // 57. Split Array Largest Sum
  {
    slug: "split-array-largest-sum",
    title: "Split Array Largest Sum",
    difficulty: "Hard",
    topics: ["Array", "Binary Search", "Dynamic Programming", "Greedy", "Prefix Sum"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 87.0,
    statement:
      "Given an integer array nums and an integer k, split nums into k non-empty subarrays such that the largest sum of any subarray is minimized.\n\nReturn the minimized largest sum of the split.\n\nA subarray is a contiguous part of the array.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [7,2,5,10,8], k = 2\nOutput: 18\nExplanation: There are four ways to split nums into two subarrays. The best way is to split it into [7,2,5] and [10,8], where the largest sum among the two subarrays is only 18.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 1000\n\n\t- 0 <= nums[i] <= 106\n\n\t- 1 <= k <= min(50, nums.length)",
  },
  // 58. Single Element in a Sorted Array
  {
    slug: "single-element-in-a-sorted-array",
    title: "Single Element in a Sorted Array",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 91.0,
    statement:
      "You are given a sorted array consisting of only integers where every element appears exactly twice, except for one element which appears exactly once.\n\nReturn the single element that appears only once.\n\nYour solution must run in O(log n) time and O(1) space.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,2,3,3,4,4,8,8]\nOutput: 2\n```\n\nExample 2:\n\n```\nInput: nums = [3,3,7,7,10,11,11]\nOutput: 10\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 105\n\n\t- 0 <= nums[i] <= 105",
  },
  // 59. Surrounded Regions
  {
    slug: "surrounded-regions",
    title: "Surrounded Regions",
    difficulty: "Medium",
    topics: ["Array", "Depth-First Search", "Breadth-First Search", "Union Find", "Matrix"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 89.0,
    statement:
      'You are given an m x n matrix board containing letters \'X\' and \'O\', capture regions that are surrounded:\n\n\t- Connect: A cell is connected to adjacent cells horizontally or vertically.\n\n\t- Region: To form a region connect every \'O\' cell.\n\n\t- Surround: The region is surrounded with \'X\' cells if no cell in the region is on the edge of the board.\n\nA surrounded region is captured by replacing all \'O\'s with \'X\'s in the input matrix board.\n\n\u00a0\n\nExample 1:\n\n```\nInput: board = [["X","X","X","X"],["X","O","O","X"],["X","X","O","X"],["X","O","X","X"]]\nOutput: [["X","X","X","X"],["X","X","X","X"],["X","X","X","X"],["X","O","X","X"]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- m == board.length\n\n\t- n == board[i].length\n\n\t- 1 <= m, n <= 200\n\n\t- board[i][j] is \'X\' or \'O\'.',
  },
  // 60. Pacific Atlantic Water Flow
  {
    slug: "pacific-atlantic-water-flow",
    title: "Pacific Atlantic Water Flow",
    difficulty: "Medium",
    topics: ["Array", "Depth-First Search", "Breadth-First Search", "Matrix"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 90.0,
    statement:
      "There is an m x n rectangular island that borders both the Pacific Ocean and Atlantic Ocean. The Pacific Ocean touches the island's left and top edges, and the Atlantic Ocean touches the island's right and bottom edges.\n\nThe island is partitioned into a grid of square cells. You are given an m x n integer matrix heights where heights[r][c] represents the height above sea level of the cell at coordinate (r, c).\n\nReturn a 2D list of grid coordinates result where result[i] = [ri, ci] denotes that rain water can flow from cell (ri, ci) to both the Pacific and Atlantic oceans.\n\n\u00a0\n\nExample 1:\n\n```\nInput: heights = [[1,2,2,3,5],[3,2,3,4,4],[2,4,5,3,1],[6,7,1,4,5],[5,1,1,2,4]]\nOutput: [[0,4],[1,3],[1,4],[2,2],[3,0],[3,1],[4,0]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- m == heights.length\n\n\t- n == heights[r].length\n\n\t- 1 <= m, n <= 200\n\n\t- 0 <= heights[r][c] <= 105",
  },
  // 61. Graph Valid Tree
  {
    slug: "graph-valid-tree",
    title: "Graph Valid Tree",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 88.0,
    statement:
      "You have a graph of n nodes labeled from 0 to n - 1. You are given an integer n and a list of edges where edges[i] = [ai, bi] indicates that there is an undirected edge between nodes ai and bi in the graph.\n\nReturn true if the edges of the given graph make up a valid tree, and false otherwise.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 5, edges = [[0,1],[0,2],[0,3],[1,4]]\nOutput: true\n```\n\nExample 2:\n\n```\nInput: n = 5, edges = [[0,1],[1,2],[2,3],[1,3],[1,4]]\nOutput: false\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 2000\n\n\t- 0 <= edges.length <= 5000\n\n\t- edges[i].length == 2\n\n\t- 0 <= ai, bi < n\n\n\t- ai != bi\n\n\t- There are no self-loops or repeated edges.",
  },
  // 62. Number of Connected Components in an Undirected Graph
  {
    slug: "number-of-connected-components-in-an-undirected-graph",
    title: "Number of Connected Components in an Undirected Graph",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 89.0,
    statement:
      "You have a graph of n nodes. You are given an integer n and an array edges where edges[i] = [ai, bi] indicates that there is an edge between ai and bi in the graph.\n\nReturn the number of connected components in the graph.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 5, edges = [[0,1],[1,2],[3,4]]\nOutput: 2\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 2000\n\n\t- 1 <= edges.length <= 5000\n\n\t- edges[i].length == 2\n\n\t- 0 <= ai <= bi < n\n\n\t- ai != bi\n\n\t- There are no repeated edges.",
  },
  // 63. Redundant Connection
  {
    slug: "redundant-connection",
    title: "Redundant Connection",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 87.0,
    statement:
      "In this problem, a tree is an undirected graph that is connected and has no cycles.\n\nYou are given a graph that started as a tree with n nodes labeled from 1 to n, with one additional edge added. The added edge has two different vertices chosen from 1 to n, and was not an edge that already existed. The graph is represented as an array edges of length n where edges[i] = [ai, bi] indicates that there is an edge between nodes ai and bi in the graph.\n\nReturn an edge that can be removed so that the resulting graph is a tree of n nodes. If there are multiple answers, return the answer that occurs last in the input.\n\n\u00a0\n\nExample 1:\n\n```\nInput: edges = [[1,2],[1,3],[2,3]]\nOutput: [2,3]\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == edges.length\n\n\t- 3 <= n <= 1000\n\n\t- edges[i].length == 2\n\n\t- 1 <= ai < bi <= edges.length\n\n\t- ai != bi\n\n\t- There are no repeated edges.",
  },
  // 64. Is Graph Bipartite?
  {
    slug: "is-graph-bipartite",
    title: "Is Graph Bipartite?",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 86.0,
    statement:
      "There is an undirected graph with n nodes, where each node is numbered between 0 and n - 1. You are given a 2D array graph, where graph[u] is an array of nodes that node u is adjacent to.\n\nA graph is bipartite if the nodes can be partitioned into two independent sets A and B such that every edge in the graph connects a node in set A and a node in set B.\n\nReturn true if and only if it is bipartite.\n\n\u00a0\n\nExample 1:\n\n```\nInput: graph = [[1,2,3],[0,2],[0,1,3],[0,2]]\nOutput: false\nExplanation: There is no way to partition the nodes into two independent sets such that every edge connects a node in one and a node in the other.\n```\n\n\u00a0\n\nConstraints:\n\n\t- graph.length == n\n\n\t- 1 <= n <= 100\n\n\t- 0 <= graph[u].length < n\n\n\t- 0 <= graph[u][i] <= n - 1\n\n\t- graph[u]\u00a0does not contain\u00a0u.\n\n\t- All the values of graph[u] are unique.\n\n\t- If graph[u] contains v, then graph[v] contains u.",
  },
  // 65. Reconstruct Itinerary
  {
    slug: "reconstruct-itinerary",
    title: "Reconstruct Itinerary",
    difficulty: "Hard",
    topics: ["Depth-First Search", "Graph", "Eulerian Circuit"],
    companies: ["google", "amazon", "meta", "uber"],
    freq: 85.0,
    statement:
      'You are given a list of airline tickets where tickets[i] = [fromi, toi] represent the departure and the arrival airports of one flight. Reconstruct the itinerary in order and return it.\n\nAll of the tickets belong to a man who departs from "JFK", thus, the itinerary must begin with "JFK". If there are multiple valid itineraries, you should return the itinerary that has the smallest lexical order when read as a single string.\n\nYou must use all the tickets once and only once.\n\n\u00a0\n\nExample 1:\n\n```\nInput: tickets = [["MUC","LHR"],["JFK","MUC"],["SFO","SJC"],["LHR","SFO"]]\nOutput: ["JFK","MUC","LHR","SFO","SJC"]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= tickets.length <= 300\n\n\t- tickets[i].length == 2\n\n\t- fromi.length == 3\n\n\t- toi.length == 3\n\n\t- fromi and toi consist of uppercase English letters.\n\n\t- fromi != toi',
  },
  // 66. Minimum Height Trees
  {
    slug: "minimum-height-trees",
    title: "Minimum Height Trees",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Graph", "Topological Sort"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 86.0,
    statement:
      "A tree is an undirected graph in which any two vertices are connected by exactly one path. In other words, any connected graph without simple cycles is a tree.\n\nGiven a tree of n nodes labelled from 0 to n - 1, and an array of n - 1 edges where edges[i] = [ai, bi] indicates that there is an undirected edge between the two nodes ai and bi in the tree, you can choose any node of the tree as the root. When you select a node x as the root, the result tree has height h. Among all possible rooted trees, those with minimum height (i.e. min(h)) are called minimum height trees (MHTs).\n\nReturn a list of all MHTs' root labels. You can return the answer in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: n = 4, edges = [[1,0],[1,2],[1,3]]\nOutput: [1]\nExplanation: As shown, the height of the tree is 1 when the root is the node with label 1 which is the only MHT.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 2 * 104\n\n\t- edges.length == n - 1\n\n\t- 0 <= ai, bi < n\n\n\t- ai != bi\n\n\t- All the pairs (ai, bi) are distinct.\n\n\t- The given input is guaranteed to be a tree and there will be no repeated edges.",
  },
  // 67. All Paths From Source to Target
  {
    slug: "all-paths-from-source-to-target",
    title: "All Paths From Source to Target",
    difficulty: "Medium",
    topics: ["Backtracking", "Depth-First Search", "Breadth-First Search", "Graph"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 84.0,
    statement:
      "Given a directed acyclic graph (DAG) of n nodes labeled from 0 to n - 1, find all possible paths from node 0 to node n - 1 and return them in any order.\n\nThe graph is given as follows: graph[i] is a list of all nodes you can visit from node i (i.e., there is a directed edge from node i to node graph[i][j]).\n\n\u00a0\n\nExample 1:\n\n```\nInput: graph = [[1,2],[3],[3],[]]\nOutput: [[0,1,3],[0,2,3]]\nExplanation: There are two paths: 0 -> 1 -> 3 and 0 -> 2 -> 3.\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == graph.length\n\n\t- 2 <= n <= 15\n\n\t- 0 <= graph[i][j] < n\n\n\t- graph[i][j] != i (i.e., there will be no self-loops).\n\n\t- All the elements of graph[i] are unique.\n\n\t- The input graph is guaranteed to be a DAG.",
  },
  // 68. Keys and Rooms
  {
    slug: "keys-and-rooms",
    title: "Keys and Rooms",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Graph"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 85.0,
    statement:
      "There are n rooms labeled from 0 to n - 1 and all the rooms are locked except for room 0. Your goal is to visit all the rooms. However, you cannot enter a locked room without having its key.\n\nWhen you visit a room, you may find a set of distinct keys in it. Each key has a number on it, denoting which room it unlocks, and you can take all of them with you to unlock other rooms.\n\nGiven an array rooms where rooms[i] is the set of keys that you can obtain if you visited room i, return true if you can visit all the rooms, or false otherwise.\n\n\u00a0\n\nExample 1:\n\n```\nInput: rooms = [[1],[2],[3],[]]\nOutput: true\nExplanation: \nWe visit room 0 and pick up key 1.\nThen we visit room 1 and pick up key 2.\nThen we visit room 2 and pick up key 3.\nThen we visit room 3.\nSince we were able to visit every room, we return true.\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == rooms.length\n\n\t- 2 <= n <= 1000\n\n\t- 0 <= rooms[i].length <= 1000\n\n\t- 1 <= sum(rooms[i].length) <= 3000\n\n\t- 0 <= rooms[i][j] < n\n\n\t- All the values of rooms[i] are unique.",
  },
  // 69. As Far from Land as Possible
  {
    slug: "as-far-from-land-as-possible",
    title: "As Far from Land as Possible",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Breadth-First Search", "Matrix"],
    companies: ["amazon", "meta", "google"],
    freq: 80.0,
    statement:
      "Given an n x n grid containing only values 0 and 1, where 0 represents water and 1 represents land, find a water cell such that its distance to the nearest land cell is maximized, and return the distance. If no land or water exists in the grid, return -1.\n\nThe distance used in this problem is the Manhattan distance: the distance between two cells (x0, y0) and (x1, y1) is |x0 - x1| + |y0 - y1|.\n\n\u00a0\n\nExample 1:\n\n```\nInput: grid = [[1,0,1],[0,0,0],[1,0,1]]\nOutput: 2\nExplanation: The cell (1, 1) is as far as possible from all the land with distance 2.\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == grid.length\n\n\t- n == grid[i].length\n\n\t- 1 <= n <= 100\n\n\t- grid[i][j] is 0 or 1",
  },
  // 70. Shortest Path in Binary Matrix
  {
    slug: "shortest-path-in-binary-matrix",
    title: "Shortest Path in Binary Matrix",
    difficulty: "Medium",
    topics: ["Array", "Breadth-First Search", "Matrix"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 92.0,
    statement:
      "Given an n x n binary matrix grid, return the length of the shortest clear path in the matrix. If there is no clear path, return -1.\n\nA clear path in a binary matrix is a path from the top-left cell (i.e., (0, 0)) to the bottom-right cell (i.e., (n - 1, n - 1)) such that:\n\n\t- All the visited cells of the path are 0.\n\n\t- All the adjacent cells of the path are 8-directionally connected.\n\nThe length of a clear path is the number of visited cells of this path.\n\n\u00a0\n\nExample 1:\n\n```\nInput: grid = [[0,1],[1,0]]\nOutput: 2\n```\n\nExample 2:\n\n```\nInput: grid = [[0,0,0],[1,1,0],[1,1,0]]\nOutput: 4\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == grid.length\n\n\t- n == grid[i].length\n\n\t- 1 <= n <= 100\n\n\t- grid[i][j] is 0 or 1",
  },
  // 71. Snakes and Ladders
  {
    slug: "snakes-and-ladders",
    title: "Snakes and Ladders",
    difficulty: "Medium",
    topics: ["Array", "Breadth-First Search", "Matrix"],
    companies: ["amazon", "meta", "google", "microsoft", "uber"],
    freq: 88.0,
    statement:
      "You are given an n x n integer matrix board where the cells are labeled from 1 to n2 in a Boustrophedon style starting from the bottom left of the board (i.e. board[n - 1][0]) and alternating direction each row.\n\nYou start on square 1 of the board. In each move, starting from square curr, do the following:\n\n\t- Choose a destination square next with a label in the range [curr + 1, min(curr + 6, n2)].\n\n\t- If next has a snake or ladder, you must move to the destination of that snake or ladder. Otherwise, you move to next.\n\n\t- The game ends when you reach square n2.\n\nReturn the least number of moves required to reach the square n2. If it is not possible to reach the square, return -1.\n\n\u00a0\n\nExample 1:\n\n```\nInput: board = [[-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1],[-1,35,-1,-1,13,-1],[-1,-1,-1,-1,-1,-1],[-1,15,-1,-1,-1,-1]]\nOutput: 4\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == board.length == board[i].length\n\n\t- 2 <= n <= 20\n\n\t- board[i][j] is either -1 or in the range [1, n2].",
  },
  // 72. Word Ladder
  {
    slug: "word-ladder",
    title: "Word Ladder",
    difficulty: "Hard",
    topics: ["Hash Table", "String", "Breadth-First Search"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 95.0,
    statement:
      'A transformation sequence from word beginWord to word endWord using a dictionary wordList is a sequence of words beginWord -> s1 -> s2 -> ... -> sk such that:\n\n\t- Every adjacent pair of words differs by a single letter.\n\n\t- Every si for 1 <= i <= k is in wordList. Note that beginWord does not need to be in wordList.\n\n\t- sk == endWord\n\nGiven two words, beginWord and endWord, and a dictionary wordList, return the number of words in the shortest transformation sequence from beginWord to endWord, or 0 if no such sequence exists.\n\n\u00a0\n\nExample 1:\n\n```\nInput: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]\nOutput: 5\nExplanation: One shortest transformation sequence is "hit" -> "hot" -> "dot" -> "dog" -> cog", which is 5 words long.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= beginWord.length <= 10\n\n\t- endWord.length == beginWord.length\n\n\t- 1 <= wordList.length <= 5000\n\n\t- wordList[i].length == beginWord.length\n\n\t- beginWord, endWord, and wordList[i] consist of lowercase English letters.\n\n\t- beginWord != endWord\n\n\t- All the words in wordList are unique.',
  },
  // 73. Kth Largest Element in a Stream
  {
    slug: "kth-largest-element-in-a-stream",
    title: "Kth Largest Element in a Stream",
    difficulty: "Easy",
    topics: [
      "Tree",
      "Design",
      "Binary Search Tree",
      "Heap (Priority Queue)",
      "Binary Tree",
      "Data Stream",
    ],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 89.0,
    statement:
      'Design a class to find the kth largest element in a stream. Note that it is the kth largest element in the sorted order, not the kth distinct element.\n\nImplement KthLargest class:\n\n\t- KthLargest(int k, int[] nums) Initializes the object with the integer k and the stream of integers nums.\n\n\t- int add(int val) Appends the integer val to the stream and returns the element representing the kth largest element in the stream.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["KthLargest", "add", "add", "add", "add", "add"]\n[[3, [4, 5, 8, 2]], [3], [5], [10], [9], [4]]\nOutput\n[null, 4, 5, 5, 8, 8]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= k <= 104\n\n\t- 0 <= nums.length <= 104\n\n\t- -104 <= nums[i] <= 104\n\n\t- -104 <= val <= 104\n\n\t- At most 104 calls will be made to add.',
  },
  // 74. Last Stone Weight
  {
    slug: "last-stone-weight",
    title: "Last Stone Weight",
    difficulty: "Easy",
    topics: ["Array", "Heap (Priority Queue)"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement:
      "You are given an array of integers stones where stones[i] is the weight of the ith stone.\n\nWe are playing a game with the stones. On each turn, we choose the heaviest two stones and smash them together. Suppose the heaviest two stones have weights x and y with x <= y. The result of this smash is:\n\n\t- If x == y, both stones are destroyed, and\n\n\t- If x != y, the stone of weight x is destroyed, and the stone of weight y has new weight y - x.\n\nAt the end of the game, there is at most one stone left.\n\nReturn the weight of the last remaining stone. If there are no stones left, return 0.\n\n\u00a0\n\nExample 1:\n\n```\nInput: stones = [2,7,4,1,8,1]\nOutput: 1\nExplanation: \nWe combine 7 and 8 to get 1 so the array converts to [2,4,1,1,1] then,\nwe combine 2 and 4 to get 2 so the array converts to [2,1,1,1] then,\nwe combine 2 and 1 to get 1 so the array converts to [1,1,1] then,\nwe combine 1 and 1 to get 0 so the array converts to [1] then that's the value of the last stone.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= stones.length <= 30\n\n\t- 1 <= stones[i] <= 1000",
  },
  // 75. K Closest Points to Origin
  {
    slug: "k-closest-points-to-origin",
    title: "K Closest Points to Origin",
    difficulty: "Medium",
    topics: [
      "Array",
      "Math",
      "Divide and Conquer",
      "Geometry",
      "Sorting",
      "Heap (Priority Queue)",
      "Quickselect",
    ],
    companies: ["meta", "amazon", "google", "microsoft", "apple", "bloomberg"],
    freq: 95.0,
    statement:
      "Given an array of points where points[i] = [xi, yi] represents a point on the X-Y plane and an integer k, return the k closest points to the origin (0, 0).\n\nThe distance between two points on the X-Y plane is the Euclidean distance (i.e., sqrt((x1 - x2)2 + (y1 - y2)2)).\n\nYou may return the answer in any order. The answer is guaranteed to be unique (except for the order that it is in).\n\n\u00a0\n\nExample 1:\n\n```\nInput: points = [[1,3],[-2,2]], k = 1\nOutput: [[-2,2]]\nExplanation:\nThe distance between (1, 3) and the origin is sqrt(10).\nThe distance between (-2, 2) and the origin is sqrt(8).\nSince sqrt(8) < sqrt(10), (-2, 2) is closer to the origin.\nWe only want the closest k = 1 points from the origin, so the answer is just [[-2,2]].\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= k <= points.length <= 104\n\n\t- -104 <= xi, yi <= 104",
  },
  // 76. Task Scheduler
  {
    slug: "task-scheduler",
    title: "Task Scheduler",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Greedy", "Sorting", "Heap (Priority Queue)", "Counting"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 94.0,
    statement:
      'You are given an array of CPU tasks, each represented by letters A to Z, and a cooling time, n. Each cycle or interval allows the completion of one task. Tasks can be completed in any order, but there\'s a constraint: identical tasks must be separated by at least n intervals due to cooling time.\n\nReturn the minimum number of intervals required to complete all tasks.\n\n\u00a0\n\nExample 1:\n\n```\nInput: tasks = ["A","A","A","B","B","B"], n = 2\nOutput: 8\nExplanation: A possible sequence is: A -> B -> idle -> A -> B -> idle -> A -> B.\nAfter completing task A, you must wait 2 CPU cycles before doing A again. The same applies to task B. In the 3rd cycle, neither A nor B can be done, so you idle. By cycle 4, A can be done again, followed by B in cycle 5, and so on.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= tasks.length <= 104\n\n\t- tasks[i] is an uppercase English letter.\n\n\t- 0 <= n <= 100',
  },
  // 77. Design Twitter
  {
    slug: "design-twitter",
    title: "Design Twitter",
    difficulty: "Medium",
    topics: ["Hash Table", "Linked List", "Design", "Heap (Priority Queue)"],
    companies: ["twitter", "amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement:
      'Design a simplified version of Twitter where users can post tweets, follow/unfollow another user, and is able to see the 10 most recent tweets in the user\'s news feed.\n\nImplement the Twitter class:\n\n\t- Twitter() Initializes your twitter object.\n\n\t- void postTweet(int userId, int tweetId) Composes a new tweet with ID tweetId by the user userId. Each call to this function will be made with a unique tweetId.\n\n\t- List<Integer> getNewsFeed(int userId) Retrieves the 10 most recent tweet IDs in the user\'s news feed. Each item in the news feed must be posted by users who the user followed or by the user themself. Tweets must be ordered from most recent to least recent.\n\n\t- void follow(int followerId, int followeeId) The user with ID followerId started following the user with ID followeeId.\n\n\t- void unfollow(int followerId, int followeeId) The user with ID followerId started unfollowing the user with ID followeeId.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["Twitter", "postTweet", "getNewsFeed", "follow", "postTweet", "getNewsFeed", "unfollow", "getNewsFeed"]\n[[], [1, 5], [1], [1, 2], [2, 6], [1], [1, 2], [1]]\nOutput\n[null, null, [5], null, null, [6, 5], null, [5]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= userId, followerId, followeeId <= 500\n\n\t- 0 <= tweetId <= 104\n\n\t- All the tweets have unique IDs.\n\n\t- At most 3 * 104 calls will be made to postTweet, getNewsFeed, follow, and unfollow.',
  },
  // 78. Find Median from Data Stream
  {
    slug: "find-median-from-data-stream",
    title: "Find Median from Data Stream",
    difficulty: "Hard",
    topics: ["Two Pointers", "Design", "Sorting", "Heap (Priority Queue)", "Data Stream"],
    companies: ["google", "amazon", "meta", "microsoft", "apple", "bloomberg"],
    freq: 96.0,
    statement:
      'The median is the middle value in an ordered integer list. If the size of the list is even, there is no middle value, and the median is the mean of the two middle values.\n\n\t- For example, for arr = [2,3,4], the median is 3.\n\n\t- For example, for arr = [2,3], the median is (2 + 3) / 2 = 2.5.\n\nImplement the MedianFinder class:\n\n\t- MedianFinder() initializes the MedianFinder object.\n\n\t- void addNum(int num) adds the integer num from the data stream to the data structure.\n\n\t- double findMedian() returns the median of all elements so far. Answers within 10-5 of the actual answer will be accepted.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["MedianFinder", "addNum", "addNum", "findMedian", "addNum", "findMedian"]\n[[], [1], [2], [], [3], []]\nOutput\n[null, null, null, 1.5, null, 2.0]\n```\n\n\u00a0\n\nConstraints:\n\n\t- -105 <= num <= 105\n\n\t- There will be at least one element in the data structure before calling findMedian.\n\n\t- At most 5 * 104 calls will be made to addNum and findMedian.',
  },
  // 79. Seat Reservation Manager
  {
    slug: "seat-reservation-manager",
    title: "Seat Reservation Manager",
    difficulty: "Medium",
    topics: ["Design", "Heap (Priority Queue)"],
    companies: ["amazon", "meta", "google"],
    freq: 81.0,
    statement:
      'Design a system that manages the reservation state of n seats that are numbered from 1 to n.\n\nImplement the SeatManager class:\n\n\t- SeatManager(int n) Initializes a SeatManager object that will manage n seats numbered from 1 to n. All seats are initially available.\n\n\t- int reserve() Fetches the smallest-numbered unreserved seat, reserves it, and returns its number.\n\n\t- void unreserve(int seatNumber) Unreserves the seat with the given seatNumber.\n\n\u00a0\n\nExample 1:\n\n```\nInput\n["SeatManager", "reserve", "reserve", "unreserve", "reserve", "reserve", "reserve", "reserve", "unreserve"]\n[[5], [], [], [2], [], [], [], [], [5]]\nOutput\n[null, 1, 2, null, 2, 3, 4, 5, null]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= n <= 105\n\n\t- 1 <= seatNumber <= n\n\n\t- For each call to reserve, it is guaranteed that there will be at least one unreserved seat.\n\n\t- For each call to unreserve, it is guaranteed that seatNumber will be reserved.\n\n\t- At most 105 calls in total will be made to reserve and unreserve.',
  },
  // 80. Single-Threaded CPU
  {
    slug: "single-threaded-cpu",
    title: "Single-Threaded CPU",
    difficulty: "Medium",
    topics: ["Array", "Sorting", "Heap (Priority Queue)"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 84.0,
    statement:
      "You are given n tasks labeled from 0 to n - 1 represented by a 2D integer array tasks, where tasks[i] = [enqueueTimei, processingTimei] means that the ith task will be available to process at enqueueTimei and will take processingTimei to finish processing.\n\nYou have a single-threaded CPU that can process at most one task at a time and will act in the following way:\n\n\t- If the CPU is idle and there are no available tasks to process, the CPU remains idle.\n\n\t- If the CPU is idle and there are available tasks, the CPU will choose the one with the shortest processing time. If multiple tasks have the same shortest processing time, it will choose the task with the smallest index i.\n\n\t- Once a task is started, the CPU will process the entire task without stopping.\n\n\t- The CPU can finish a task then immediately start a new one.\n\nReturn the order in which the CPU will process the tasks.\n\n\u00a0\n\nExample 1:\n\n```\nInput: tasks = [[1,2],[2,4],[3,2],[4,1]]\nOutput: [0,2,3,1]\n```\n\n\u00a0\n\nConstraints:\n\n\t- tasks.length == n\n\n\t- 1 <= n <= 105\n\n\t- 1 <= enqueueTimei, processingTimei <= 109",
  },
  // 81. Maximum Subsequence Score
  {
    slug: "maximum-subsequence-score",
    title: "Maximum Subsequence Score",
    difficulty: "Medium",
    topics: ["Array", "Greedy", "Sorting", "Heap (Priority Queue)"],
    companies: ["amazon", "meta", "google"],
    freq: 83.0,
    statement:
      "You are given two 0-indexed integer arrays nums1 and nums2 of equal length n and a positive integer k. You must choose a subsequence of indices from nums1 of length k.\n\nFor chosen indices nums1[i0], nums1[i1], ..., nums1[ik - 1], your score is defined as:\n\n\t- The sum of the selected elements from nums1 multiplied with the minimum of the selected elements from nums2.\n\nReturn the maximum possible score.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums1 = [1,3,3,2], nums2 = [2,1,3,4], k = 3\nOutput: 12\nExplanation: \nThe four possible subsequence scores are:\n- We choose the indices 0, 1, and 2 with score = (1+3+3) * min(2,1,3) = 7 * 1 = 7.\n- We choose the indices 0, 1, and 3 with score = (1+3+2) * min(2,1,4) = 6 * 1 = 6.\n- We choose the indices 0, 2, and 3 with score = (1+3+2) * min(2,3,4) = 6 * 2 = 12.\n- We choose the indices 1, 2, and 3 with score = (3+3+2) * min(1,3,4) = 8 * 1 = 8.\nTherefore the maximum score is 12.\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == nums1.length == nums2.length\n\n\t- 1 <= n <= 105\n\n\t- 0 <= nums1[i], nums2[i] <= 105\n\n\t- 1 <= k <= n",
  },
  // 82. IPO
  {
    slug: "ipo",
    title: "IPO",
    difficulty: "Hard",
    topics: ["Array", "Greedy", "Sorting", "Heap (Priority Queue)"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 85.0,
    statement:
      "Suppose LeetCode will start its IPO soon. In order to sell a good price of its shares to Venture Capital, LeetCode would like to work on some projects to increase its capital before the IPO. Since it has limited resources, it can only finish at most k distinct projects before the IPO. Help LeetCode design the best way to maximize its total capital after finishing at most k distinct projects.\n\nYou are given n projects where the ith project has a pure profit profits[i] and a minimum capital of capital[i] is needed to start it.\n\nInitially, you have w capital. When you finish a project, you will obtain its pure profit and the profit will be added to your total capital.\n\nPick a list of at most k distinct projects from given projects to maximize your final capital, and return the final maximized capital.\n\n\u00a0\n\nExample 1:\n\n```\nInput: k = 2, w = 0, profits = [1,2,3], capital = [0,1,1]\nOutput: 4\nExplanation: Since your initial capital is 0, you can only start the project indexed 0.\nAfter finishing it you will obtain profit 1 and your capital becomes 1.\nWith capital 1, you can either start the project indexed 1 or the project indexed 2.\nSince you can choose at most 2 projects, you need to finish the project indexed 2 to get the maximum capital.\nTherefore, output the final maximized capital, which is 0 + 1 + 3 = 4.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= k <= 105\n\n\t- 0 <= w <= 109\n\n\t- n == profits.length == capital.length\n\n\t- 1 <= n <= 105\n\n\t- 0 <= profits[i] <= 104\n\n\t- 0 <= capital[i] <= 109",
  },
  // 83. Subsets II
  {
    slug: "subsets-ii",
    title: "Subsets II",
    difficulty: "Medium",
    topics: ["Array", "Backtracking", "Bit Manipulation"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 90.0,
    statement:
      "Given an integer array nums that may contain duplicates, return all possible subsets (the power set).\n\nThe solution set must not contain duplicate subsets. Return the solution in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,2,2]\nOutput: [[],[1],[1,2],[1,2,2],[2],[2,2]]\n```\n\nExample 2:\n\n```\nInput: nums = [0]\nOutput: [[],[0]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 10\n\n\t- -10 <= nums[i] <= 10",
  },
  // 84. Combination Sum II
  {
    slug: "combination-sum-ii",
    title: "Combination Sum II",
    difficulty: "Medium",
    topics: ["Array", "Backtracking"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 91.0,
    statement:
      "Given a collection of candidate numbers (candidates) and a target number (target), find all unique combinations in candidates where the candidate numbers sum to target.\n\nEach number in candidates may only be used once in the combination.\n\nNote: The solution set must not contain duplicate combinations.\n\n\u00a0\n\nExample 1:\n\n```\nInput: candidates = [10,1,2,7,6,1,5], target = 8\nOutput: \n[\n[1,1,6],\n[1,2,5],\n[1,7],\n[2,6]\n]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= candidates.length <= 100\n\n\t- 1 <= candidates[i] <= 50\n\n\t- 1 <= target <= 30",
  },
  // 85. Combination Sum III
  {
    slug: "combination-sum-iii",
    title: "Combination Sum III",
    difficulty: "Medium",
    topics: ["Array", "Backtracking"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 84.0,
    statement:
      "Find all valid combinations of k numbers that sum up to n such that the following conditions are true:\n\n\t- Only numbers 1 through 9 are used.\n\n\t- Each number is used at most once.\n\nReturn a list of all possible valid combinations. The list must not contain the same combination twice, and the combinations may be returned in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: k = 3, n = 7\nOutput: [[1,2,4]]\nExplanation:\n1 + 2 + 4 = 7\nThere are no other valid combinations.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= k <= 9\n\n\t- 1 <= n <= 60",
  },
  // 86. Permutations II
  {
    slug: "permutations-ii",
    title: "Permutations II",
    difficulty: "Medium",
    topics: ["Array", "Backtracking", "Sorting"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 89.0,
    statement:
      "Given a collection of numbers, nums, that might contain duplicates, return all possible unique permutations in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,2]\nOutput:\n[[1,1,2],\n [1,2,1],\n [2,1,1]]\n```\n\nExample 2:\n\n```\nInput: nums = [1,2,3]\nOutput: [[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 8\n\n\t- -10 <= nums[i] <= 10",
  },
  // 87. Palindrome Partitioning
  {
    slug: "palindrome-partitioning",
    title: "Palindrome Partitioning",
    difficulty: "Medium",
    topics: ["String", "Dynamic Programming", "Backtracking"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg", "tiktok"],
    freq: 92.0,
    statement:
      'Given a string s, partition s such that every substring of the partition is a palindrome. Return all possible palindrome partitioning of s.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "aab"\nOutput: [["a","a","b"],["aa","b"]]\n```\n\nExample 2:\n\n```\nInput: s = "a"\nOutput: [["a"]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 16\n\n\t- s contains only lowercase English letters.',
  },
  // 88. Letter Combinations of a Phone Number
  {
    slug: "letter-combinations-of-a-phone-number",
    title: "Letter Combinations of a Phone Number",
    difficulty: "Medium",
    topics: ["Hash Table", "String", "Backtracking"],
    companies: ["amazon", "meta", "microsoft", "google", "apple", "bloomberg", "uber"],
    freq: 95.0,
    statement:
      'Given a string containing digits from 2-9 inclusive, return all possible letter combinations that the number could represent. Return the answer in any order.\n\nA mapping of digits to letters (just like on the telephone buttons) is given below. Note that 1 does not map to any letters.\n\n\u00a0\n\nExample 1:\n\n```\nInput: digits = "23"\nOutput: ["ad","ae","af","bd","be","bf","cd","ce","cf"]\n```\n\nExample 2:\n\n```\nInput: digits = ""\nOutput: []\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= digits.length <= 4\n\n\t- digits[i] is a digit in the range [\'2\', \'9\'].',
  },
  // 89. Restore IP Addresses
  {
    slug: "restore-ip-addresses",
    title: "Restore IP Addresses",
    difficulty: "Medium",
    topics: ["String", "Backtracking"],
    companies: ["amazon", "meta", "google", "microsoft", "tiktok"],
    freq: 85.0,
    statement:
      'A valid IP address consists of exactly four integers separated by single dots. Each integer is between 0 and 255 (inclusive) and cannot have leading zeros.\n\n\t- For example, "0.1.2.201" and "192.168.1.1" are valid IP addresses, but "0.011.255.245", "192.168.1.312" and "192.168@1.1" are invalid IP addresses.\n\nGiven a string s containing only digits, return all possible valid IP addresses that can be formed by inserting dots into s. You are not allowed to reorder or remove any digits in s. You may return the valid IP addresses in any order.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "25525511135"\nOutput: ["255.255.11.135","255.255.111.35"]\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 20\n\n\t- s consists of digits only.',
  },
  // 90. Sudoku Solver
  {
    slug: "sudoku-solver",
    title: "Sudoku Solver",
    difficulty: "Hard",
    topics: ["Array", "Hash Table", "Backtracking", "Matrix"],
    companies: ["google", "amazon", "meta", "microsoft", "uber"],
    freq: 89.0,
    statement:
      'Write a program to solve a Sudoku puzzle by filling the empty cells.\n\nA sudoku solution must satisfy all of the following rules:\n\n\t1. Each of the digits 1-9 must occur exactly once in each row.\n\n\t2. Each of the digits 1-9 must occur exactly once in each column.\n\n\t3. Each of the digits 1-9 must occur exactly once in each of the 9 3x3 sub-boxes of the grid.\n\nThe \'.\' character indicates empty cells.\n\n\u00a0\n\nExample 1:\n\n```\nInput: board = [["5","3",".",".","7",".",".",".","."],["6",".",".","1","9","5",".",".","."],[".","9","8",".",".",".",".","6","."],["8",".",".",".","6",".",".",".","3"],["4",".",".","8",".","3",".",".","1"],["7",".",".",".","2",".",".",".","6"],[".","6",".",".",".",".","2","8","."],[".",".",".","4","1","9",".",".","5"],[".",".",".",".","8",".",".","7","9"]]\nOutput: [["5","3","4","6","7","8","9","1","2"],["6","7","2","1","9","5","3","4","8"],["1","9","8","3","4","2","5","6","7"],["8","5","9","7","6","1","4","2","3"],["4","2","6","8","5","3","7","9","1"],["7","1","3","9","2","4","8","5","6"],["9","6","1","5","3","7","2","8","4"],["2","8","7","4","1","9","6","3","5"],["3","4","5","2","8","6","1","7","9"]]\n```\n\n\u00a0\n\nConstraints:\n\n\t- board.length == 9\n\n\t- board[i].length == 9\n\n\t- board[i][j] is a digit or \'.\'.\n\n\t- It is guaranteed that the input board has only one solution.',
  },
  // 91. Min Cost Climbing Stairs
  {
    slug: "min-cost-climbing-stairs",
    title: "Min Cost Climbing Stairs",
    difficulty: "Easy",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "meta", "google", "microsoft", "apple"],
    freq: 93.0,
    statement:
      "You are given an integer array cost where cost[i] is the cost of ith step on a staircase. Once you pay the cost, you can either climb one or two steps.\n\nYou can either start from the step with index 0, or the step with index 1.\n\nReturn the minimum cost to reach the top of the floor.\n\n\u00a0\n\nExample 1:\n\n```\nInput: cost = [10,15,20]\nOutput: 15\nExplanation: You will start at index 1.\n- Pay 15 and climb two steps to reach the top.\nThe total cost is 15.\n```\n\nExample 2:\n\n```\nInput: cost = [1,100,1,1,1,100,1,1,100,1]\nOutput: 6\nExplanation: You will start at index 0.\n- Pay 1 and climb two steps to reach index 2.\n- Pay 1 and climb two steps to reach index 4.\n- Pay 1 and climb two steps to reach index 6.\n- Pay 1 and climb one step to reach index 7.\n- Pay 1 and climb two steps to reach index 9.\n- Pay 1 and climb one step to reach the top.\nThe total cost is 6.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 2 <= cost.length <= 1000\n\n\t- 0 <= cost[i] <= 999",
  },
  // 92. House Robber II
  {
    slug: "house-robber-ii",
    title: "House Robber II",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 92.0,
    statement:
      "You are a professional robber planning to rob houses along a street, each house has a certain amount of money stashed. All houses at this place are arranged in a circle. That means the first house is the neighbor of the last one. Meanwhile, adjacent houses have a security system connected, and it will automatically contact the police if two adjacent houses were broken into on the same night.\n\nGiven an integer array nums representing the amount of money of each house, return the maximum amount of money you can rob tonight without alerting the police.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [2,3,2]\nOutput: 3\nExplanation: You cannot rob house 1 (money = 2) and then rob house 3 (money = 2), because they are adjacent houses.\n```\n\nExample 2:\n\n```\nInput: nums = [1,2,3,1]\nOutput: 4\nExplanation: Rob house 1 (money = 1) and then rob house 3 (money = 3).\nTotal amount you can rob = 1 + 3 = 4.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 100\n\n\t- 0 <= nums[i] <= 1000",
  },
  // 93. Palindromic Substrings
  {
    slug: "palindromic-substrings",
    title: "Palindromic Substrings",
    difficulty: "Medium",
    topics: ["Two Pointers", "String", "Dynamic Programming"],
    companies: ["meta", "amazon", "google", "microsoft", "bloomberg"],
    freq: 93.0,
    statement:
      'Given a string s, return the number of palindromic substrings in it.\n\nA string is a palindrome when it reads the same backward as forward.\n\nA substring is a contiguous sequence of characters within the string.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "abc"\nOutput: 3\nExplanation: Three palindromic strings: "a", "b", "c".\n```\n\nExample 2:\n\n```\nInput: s = "aaa"\nOutput: 6\nExplanation: Six palindromic strings: "a", "a", "a", "aa", "aa", "aaa".\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length <= 1000\n\n\t- s consists of lowercase English letters.',
  },
  // 94. Coin Change II
  {
    slug: "coin-change-ii",
    title: "Coin Change II",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 91.0,
    statement:
      "You are given an integer array coins representing coins of different denominations and an integer amount representing a total amount of money.\n\nReturn the number of combinations that make up that amount. If that amount of money cannot be made up by any combination of the coins, return 0.\n\nYou may assume that you have an infinite number of each kind of coin.\n\nThe answer is guaranteed to fit into a signed 32-bit integer.\n\n\u00a0\n\nExample 1:\n\n```\nInput: amount = 5, coins = [1,2,5]\nOutput: 4\nExplanation: there are four ways to make up the amount:\n5=5\n5=2+2+1\n5=2+1+1+1\n5=1+1+1+1+1\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= coins.length <= 300\n\n\t- 1 <= coins[i] <= 5000\n\n\t- All the values of coins are unique.\n\n\t- 0 <= amount <= 5000",
  },
  // 95. Target Sum
  {
    slug: "target-sum",
    title: "Target Sum",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Backtracking"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 90.0,
    statement:
      "You are given an integer array nums and an integer target.\n\nYou want to build an expression out of nums by adding one of the symbols '+' and '-' before each integer in nums and then concatenate all the integers.\n\n\t- For example, if nums = [2, 1], you can add a '+' before 2 and a '-' before 1 and concatenate them to build the expression \"+2-1\".\n\nReturn the number of different expressions that you can build, which evaluates to target.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [1,1,1,1,1], target = 3\nOutput: 5\nExplanation: There are 5 ways to assign symbols to make the sum of nums be target 3.\n-1 + 1 + 1 + 1 + 1 = 3\n+1 - 1 + 1 + 1 + 1 = 3\n+1 + 1 - 1 + 1 + 1 = 3\n+1 + 1 + 1 - 1 + 1 = 3\n+1 + 1 + 1 + 1 - 1 = 3\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 20\n\n\t- 0 <= nums[i] <= 1000\n\n\t- 0 <= sum(nums[i]) <= 1000\n\n\t- -1000 <= target <= 1000",
  },
  // 96. Interleaving String
  {
    slug: "interleaving-string",
    title: "Interleaving String",
    difficulty: "Medium",
    topics: ["String", "Dynamic Programming"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 88.0,
    statement:
      'Given strings s1, s2, and s3, find whether s3 is formed by an interleaving of s1 and s2.\n\nAn interleaving of two strings s and t is a configuration where s and t are divided into n and m substrings respectively, such that:\n\n\t- s = s1 + s2 + ... + sn\n\n\t- t = t1 + t2 + ... + tm\n\n\t- |n - m| <= 1\n\n\t- The interleaving is s1 + t1 + s2 + t2 + ... or t1 + s1 + t2 + s2 + ...\n\nNote: a + b is the concatenation of strings a and b.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s1 = "aabcc", s2 = "dbbca", s3 = "aadbbcbcac"\nOutput: true\nExplanation: One way to obtain s3 is:\nSplit s1 into s1 = "aa" + "bc" + "c", and s2 into s2 = "dbbc" + "a".\nInterleaving the two yields "aa" + "dbbc" + "bc" + "a" + "c" = "aadbbcbcac".\n```\n\n\u00a0\n\nConstraints:\n\n\t- 0 <= s1.length, s2.length <= 100\n\n\t- 0 <= s3.length <= 200\n\n\t- s1, s2, and s3 consist of lowercase English letters.',
  },
  // 97. Longest Increasing Path in a Matrix
  {
    slug: "longest-increasing-path-in-a-matrix",
    title: "Longest Increasing Path in a Matrix",
    difficulty: "Hard",
    topics: [
      "Array",
      "Dynamic Programming",
      "Depth-First Search",
      "Breadth-First Search",
      "Graph",
      "Topological Sort",
      "Memoization",
      "Matrix",
    ],
    companies: ["google", "meta", "amazon", "microsoft", "apple", "bloomberg"],
    freq: 92.0,
    statement:
      "Given an m x n integers matrix, return the length of the longest increasing path in matrix.\n\nFrom each cell, you can either move in four directions: left, right, up, or down. You may not move diagonally or move outside the boundary (i.e., wrap-around is not allowed).\n\n\u00a0\n\nExample 1:\n\n```\nInput: matrix = [[9,9,4],[6,6,8],[2,1,1]]\nOutput: 4\nExplanation: The longest increasing path is [1, 2, 6, 9].\n```\n\n\u00a0\n\nConstraints:\n\n\t- m == matrix.length\n\n\t- n == matrix[i].length\n\n\t- 1 <= m, n <= 200\n\n\t- 0 <= matrix[i][j] <= 231 - 1",
  },
  // 98. Distinct Subsequences
  {
    slug: "distinct-subsequences",
    title: "Distinct Subsequences",
    difficulty: "Hard",
    topics: ["String", "Dynamic Programming"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 85.0,
    statement:
      'Given two strings s and t, return the number of distinct subsequences of s which equals t.\n\nThe test cases are generated so that the answer fits on a 32-bit signed integer.\n\n\u00a0\n\nExample 1:\n\n```\nInput: s = "rabbbit", t = "rabbit"\nOutput: 3\nExplanation:\nAs shown below, there are 3 ways you can generate "rabbit" from s.\nrabbbit\nrabbbit\nrabbbit\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= s.length, t.length <= 1000\n\n\t- s and t consist of English letters.',
  },
  // 99. Burst Balloons
  {
    slug: "burst-balloons",
    title: "Burst Balloons",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming"],
    companies: ["google", "amazon", "meta", "microsoft"],
    freq: 87.0,
    statement:
      "You are given n balloons, indexed from 0 to n - 1. Each balloon is painted with a number on it represented by an array nums. You are asked to burst all the balloons.\n\nIf you burst the ith balloon, you will get nums[i - 1] * nums[i] * nums[i + 1] coins. If i - 1 or i + 1 goes out of bounds of the array, then treat it as if there is a balloon with a 1 painted on it.\n\nReturn the maximum coins you can collect by bursting the balloons wisely.\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [3,1,5,8]\nOutput: 167\nExplanation:\nnums = [3,1,5,8] --> [3,5,8] --> [3,8] --> [8] --> []\ncoins =  3*1*5    +   3*5*8   +  1*3*8  + 1*8*1 = 167\n```\n\n\u00a0\n\nConstraints:\n\n\t- n == nums.length\n\n\t- 1 <= n <= 300\n\n\t- 0 <= nums[i] <= 100",
  },
  // 100. Jump Game II
  {
    slug: "jump-game-ii",
    title: "Jump Game II",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Greedy"],
    companies: ["amazon", "meta", "google", "microsoft", "apple", "bloomberg"],
    freq: 96.0,
    statement:
      "You are given a 0-indexed array of integers nums of length n. You are initially positioned at nums[0].\n\nEach element nums[i] represents the maximum length of a forward jump from index i. In other words, if you are at nums[i], you can jump to any nums[i + j] where:\n\n\t- 0 <= j <= nums[i] and\n\n\t- i + j < n\n\nReturn the minimum number of jumps to reach nums[n - 1]. The test cases are generated such that you can reach nums[n - 1].\n\n\u00a0\n\nExample 1:\n\n```\nInput: nums = [2,3,1,1,4]\nOutput: 2\nExplanation: The minimum number of jumps to reach the last index is 2. Jump 1 step from index 0 to 1, then 3 steps to the last index.\n```\n\n\u00a0\n\nConstraints:\n\n\t- 1 <= nums.length <= 104\n\n\t- 0 <= nums[i] <= 1000\n\n\t- It's guaranteed that you can reach nums[n - 1].",
  },
];

console.log("Total candidate problems:", hundredProblems.length);

// Verify distinct slugs
const candidateSlugs = new Set();
const toAdd = [];
for (const item of hundredProblems) {
  if (existingSlugs.has(item.slug)) {
    console.warn("Already exists:", item.slug);
    continue;
  }
  if (candidateSlugs.has(item.slug)) {
    console.warn("Duplicate in candidate list:", item.slug);
    continue;
  }
  candidateSlugs.add(item.slug);
  toAdd.push(item);
}

console.log("Unique new problems to add:", toAdd.length);

if (toAdd.length === 100) {
  console.log("Exactly 100 unique problems ready for insertion!");

  // Format problems and statements
  const updatedProblems = [...existingProblems];
  const updatedStatements = { ...existingStatements };

  for (const item of toAdd) {
    const { statement, ...problemData } = item;
    updatedProblems.push(problemData);
    updatedStatements[item.slug] = statement;
  }

  console.log("New total problems:", updatedProblems.length);
  console.log("New total statements:", Object.keys(updatedStatements).length);

  fs.writeFileSync(problemsPath, JSON.stringify(updatedProblems, null, 2) + "\n", "utf-8");
  fs.writeFileSync(statementsPath, JSON.stringify(updatedStatements, null, 2) + "\n", "utf-8");
  console.log("Successfully wrote problems.json and statements.json!");
} else {
  console.error("Mismatch in count:", toAdd.length);
}
