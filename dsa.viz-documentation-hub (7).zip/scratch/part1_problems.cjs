module.exports = [
  // 1. Find the Duplicate Number
  {
    slug: "find-the-duplicate-number",
    title: "Find the Duplicate Number",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Binary Search", "Bit Manipulation"],
    companies: ["amazon", "microsoft", "google", "meta", "bloomberg"],
    freq: 95.0,
    statement: `Given an array of integers \`nums\` containing \`n + 1\` integers where each integer is in the range \`[1, n]\` inclusive.

There is only one repeated number in \`nums\`, return this repeated number.

You must solve the problem without modifying the array \`nums\` and uses only constant extra space.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,3,4,2,2]
Output: 2
\`\`\`

Example 2:

\`\`\`
Input: nums = [3,1,3,4,2]
Output: 3
\`\`\`

Example 3:

\`\`\`
Input: nums = [3,3,3,3,3]
Output: 3
\`\`\`

\u00a0

Constraints:

\t- 1 <= n <= 105
\t- nums.length == n + 1
\t- 1 <= nums[i] <= n
\t- All the integers in nums appear only once except for precisely one integer which appears two or more times.`,
  },

  // 2. Majority Element II
  {
    slug: "majority-element-ii",
    title: "Majority Element II",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Sorting", "Counting"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement: `Given an integer array of size \`n\`, find all elements that appear more than \`⌊ n/3 ⌋\` times.

\u00a0

Example 1:

\`\`\`
Input: nums = [3,2,3]
Output: [3]
\`\`\`

Example 2:

\`\`\`
Input: nums = [1]
Output: [1]
\`\`\`

Example 3:

\`\`\`
Input: nums = [1,2]
Output: [1,2]
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 5 * 104
\t- -109 <= nums[i] <= 109`,
  },

  // 3. Pascal's Triangle II
  {
    slug: "pascals-triangle-ii",
    title: "Pascal's Triangle II",
    difficulty: "Easy",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "google", "microsoft", "bloomberg"],
    freq: 82.0,
    statement: `Given an integer \`rowIndex\`, return the \`rowIndex\`th (0-indexed) row of the Pascal's triangle.

In Pascal's triangle, each number is the sum of the two numbers directly above it.

\u00a0

Example 1:

\`\`\`
Input: rowIndex = 3
Output: [1,3,3,1]
\`\`\`

Example 2:

\`\`\`
Input: rowIndex = 0
Output: [1]
\`\`\`

Example 3:

\`\`\`
Input: rowIndex = 1
Output: [1,1]
\`\`\`

\u00a0

Constraints:

\t- 0 <= rowIndex <= 33`,
  },

  // 4. Max Consecutive Ones
  {
    slug: "max-consecutive-ones",
    title: "Max Consecutive Ones",
    difficulty: "Easy",
    topics: ["Array"],
    companies: ["google", "amazon", "microsoft", "meta"],
    freq: 84.0,
    statement: `Given a binary array \`nums\`, return the maximum number of consecutive \`1\`'s in the array.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,1,0,1,1,1]
Output: 3
Explanation: The first two digits or the last three digits are consecutive 1s. The maximum number of consecutive 1s is 3.
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,0,1,1,0,1]
Output: 2
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- nums[i] is either 0 or 1.`,
  },

  // 5. Intersection of Two Arrays II
  {
    slug: "intersection-of-two-arrays-ii",
    title: "Intersection of Two Arrays II",
    difficulty: "Easy",
    topics: ["Array", "Hash Table", "Two Pointers", "Binary Search", "Sorting"],
    companies: ["amazon", "meta", "google", "apple", "microsoft"],
    freq: 86.0,
    statement: `Given two integer arrays \`nums1\` and \`nums2\`, return an array of their intersection. Each element in the result must appear as many times as it shows in both arrays and you may return the result in any order.

\u00a0

Example 1:

\`\`\`
Input: nums1 = [1,2,2,1], nums2 = [2,2]
Output: [2,2]
\`\`\`

Example 2:

\`\`\`
Input: nums1 = [4,9,5], nums2 = [9,4,9,8,4]
Output: [4,9]
Explanation: [9,4] is also accepted.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums1.length, nums2.length <= 1000
\t- 0 <= nums1[i], nums2[i] <= 1000`,
  },

  // 6. Rearrange Array Elements by Sign
  {
    slug: "rearrange-array-elements-by-sign",
    title: "Rearrange Array Elements by Sign",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Simulation"],
    companies: ["amazon", "microsoft", "google"],
    freq: 87.0,
    statement: `You are given a 0-indexed integer array \`nums\` of even length containing an equal number of positive and negative integers.

You should rearrange the elements of \`nums\` such that the modified array follows the given conditions:

\t1. Every consecutive pair of integers have opposite signs.
\t2. For all integers with the same sign, the order in which they were present in \`nums\` is preserved.
\t3. The rearranged array begins with a positive integer.

Return the modified array after rearranging the elements to satisfy the aforementioned conditions.

\u00a0

Example 1:

\`\`\`
Input: nums = [3,1,-2,-5,2,-4]
Output: [3,-2,1,-5,2,-4]
Explanation:
The positive integers in nums are [3,1,2]. The negative integers are [-2,-5,-4].
The only possible way to rearrange them such that they alternate signs is [3,-2,1,-5,2,-4].
\`\`\`

Example 2:

\`\`\`
Input: nums = [-1,1]
Output: [1,-1]
\`\`\`

\u00a0

Constraints:

\t- 2 <= nums.length <= 2 * 105
\t- nums.length is even
\t- 1 <= |nums[i]| <= 105
\t- nums consists of equal number of positive and negative integers.`,
  },

  // 7. Subarray Sum Divisible by K
  {
    slug: "subarray-sum-divisible-by-k",
    title: "Subarray Sums Divisible by K",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Prefix Sum"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 85.0,
    statement: `Given an integer array \`nums\` and an integer \`k\`, return the number of non-empty subarrays that have a sum divisible by \`k\`.

A subarray is a contiguous part of an array.

\u00a0

Example 1:

\`\`\`
Input: nums = [4,5,0,-2,-3,1], k = 5
Output: 7
Explanation: There are 7 subarrays with a sum divisible by k = 5:
[4, 5, 0, -2, -3, 1], [5], [5, 0], [5, 0, -2, -3], [0], [0, -2, -3], [-2, -3]
\`\`\`

Example 2:

\`\`\`
Input: nums = [5], k = 9
Output: 0
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 3 * 104
\t- -104 <= nums[i] <= 104
\t- 2 <= k <= 104`,
  },

  // 8. Continuous Subarray Sum
  {
    slug: "continuous-subarray-sum",
    title: "Continuous Subarray Sum",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Math", "Prefix Sum"],
    companies: ["meta", "amazon", "google", "bloomberg"],
    freq: 89.0,
    statement: `Given an integer array \`nums\` and an integer \`k\`, return \`true\` if \`nums\` has a good subarray or \`false\` otherwise.

A good subarray is a subarray where:
\t- its length is at least two, and
\t- the sum of the elements of the subarray is a multiple of \`k\`.

Note that:
\t- A subarray is a contiguous part of the array.
\t- An integer \`x\` is a multiple of \`k\` if there exists an integer \`n\` such that \`x = n * k\`. \`0\` is always a multiple of \`k\`.

\u00a0

Example 1:

\`\`\`
Input: nums = [23,2,4,6,7], k = 6
Output: true
Explanation: [2, 4] is a continuous subarray of size 2 whose elements sum up to 6.
\`\`\`

Example 2:

\`\`\`
Input: nums = [23,2,6,4,7], k = 6
Output: true
Explanation: [23, 2, 6, 4, 7] is an continuous subarray of size 5 whose elements sum up to 42. 42 is a multiple of 6 because 42 = 7 * 6 and 7 is an integer.
\`\`\`

Example 3:

\`\`\`
Input: nums = [23,2,6,4,7], k = 13
Output: false
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- 0 <= nums[i] <= 109
\t- 0 <= sum(nums[i]) <= 231 - 1
\t- 1 <= k <= 231 - 1`,
  },

  // 9. Find All Duplicates in an Array
  {
    slug: "find-all-duplicates-in-an-array",
    title: "Find All Duplicates in an Array",
    difficulty: "Medium",
    topics: ["Array", "Hash Table"],
    companies: ["amazon", "microsoft", "meta", "google", "apple"],
    freq: 85.0,
    statement: `Given an integer array \`nums\` of length \`n\` where all the integers of \`nums\` are in the range \`[1, n]\` and each integer appears once or twice, return an array of all the integers that appears twice.

You must write an algorithm that runs in \`O(n)\` time and uses only constant extra space.

\u00a0

Example 1:

\`\`\`
Input: nums = [4,3,2,7,8,2,3,1]
Output: [2,3]
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,1,2]
Output: [1]
\`\`\`

Example 3:

\`\`\`
Input: nums = [1]
Output: []
\`\`\`

\u00a0

Constraints:

\t- n == nums.length
\t- 1 <= n <= 105
\t- 1 <= nums[i] <= n
\t- Each element in nums appears once or twice.`,
  },

  // 10. Find All Numbers Disappeared in an Array
  {
    slug: "find-all-numbers-disappeared-in-an-array",
    title: "Find All Numbers Disappeared in an Array",
    difficulty: "Easy",
    topics: ["Array", "Hash Table"],
    companies: ["google", "amazon", "microsoft", "bloomberg"],
    freq: 83.0,
    statement: `Given an array \`nums\` of \`n\` integers where \`nums[i]\` is in the range \`[1, n]\`, return an array of all the integers in the range \`[1, n]\` that do not appear in \`nums\`.

\u00a0

Example 1:

\`\`\`
Input: nums = [4,3,2,7,8,2,3,1]
Output: [5,6]
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,1]
Output: [2]
\`\`\`

\u00a0

Constraints:

\t- n == nums.length
\t- 1 <= n <= 105
\t- 1 <= nums[i] <= n`,
  },

  // 11. Set Mismatch
  {
    slug: "set-mismatch",
    title: "Set Mismatch",
    difficulty: "Easy",
    topics: ["Array", "Hash Table", "Bit Manipulation", "Sorting"],
    companies: ["amazon", "apple", "google"],
    freq: 80.0,
    statement: `You have a set of integers \`s\`, which originally contains all the numbers from \`1\` to \`n\`. Unfortunately, due to some error, one of the numbers in \`s\` got duplicated to another number in the set, which results in repetition of one number and loss of another number.

You are given an integer array \`nums\` representing the data status of this set after the error.

Find the number that occurs twice and the number that is missing and return them in the form of an array \`[duplicate, missing]\`.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,2,2,4]
Output: [2,3]
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,1]
Output: [1,2]
\`\`\`

\u00a0

Constraints:

\t- 2 <= nums.length <= 104
\t- 1 <= nums[i] <= 104`,
  },

  // 12. Check if Array Is Sorted and Rotated
  {
    slug: "check-if-array-is-sorted-and-rotated",
    title: "Check if Array Is Sorted and Rotated",
    difficulty: "Easy",
    topics: ["Array"],
    companies: ["amazon", "google", "microsoft"],
    freq: 83.0,
    statement: `Given an array \`nums\`, return \`true\` if the array was originally sorted in non-decreasing order, then rotated some number of positions (including zero). Otherwise, return \`false\`.

There may be duplicates in the original array.

\u00a0

Example 1:

\`\`\`
Input: nums = [3,4,5,1,2]
Output: true
Explanation: [1,2,3,4,5] is the original sorted array.
You can rotate the array by x = 3 positions to begin on the element of value 3: [3,4,5,1,2].
\`\`\`

Example 2:

\`\`\`
Input: nums = [2,1,3,4]
Output: false
Explanation: There is no sorted array once-rotated that can make nums.
\`\`\`

Example 3:

\`\`\`
Input: nums = [1,2,3]
Output: true
Explanation: [1,2,3] is the original sorted array.
You can rotate the array by x = 0 positions (i.e. no rotation) to make nums.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 100
\t- 1 <= nums[i] <= 100`,
  },

  // 13. Boats to Save People
  {
    slug: "boats-to-save-people",
    title: "Boats to Save People",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers", "Greedy", "Sorting"],
    companies: ["google", "amazon", "salesforce", "uber"],
    freq: 85.0,
    statement: `You are given an array \`people\` where \`people[i]\` is the weight of the \`i\`th person, and an infinite number of boats where each boat can carry a maximum weight of \`limit\`. Each boat carries at most two people at the same time, provided the sum of the weight of those people is at most \`limit\`.

Return the minimum number of boats to carry every given person.

\u00a0

Example 1:

\`\`\`
Input: people = [1,2], limit = 3
Output: 1
Explanation: 1 boat (1, 2)
\`\`\`

Example 2:

\`\`\`
Input: people = [3,2,2,1], limit = 3
Output: 3
Explanation: 3 boats (1, 2), (2) and (3)
\`\`\`

Example 3:

\`\`\`
Input: people = [3,5,3,4], limit = 5
Output: 4
Explanation: 4 boats (3), (3), (4), (5)
\`\`\`

\u00a0

Constraints:

\t- 1 <= people.length <= 5 * 104
\t- 1 <= people[i] <= limit <= 3 * 104`,
  },

  // 14. Fruit Into Baskets
  {
    slug: "fruit-into-baskets",
    title: "Fruit Into Baskets",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Sliding Window"],
    companies: ["google", "amazon", "microsoft", "meta"],
    freq: 88.0,
    statement: `You are visiting a farm that has a single row of fruit trees arranged from left to right. The trees are represented by an integer array \`fruits\` where \`fruits[i]\` is the type of fruit the \`i\`th tree produces.

You want to collect as much fruit as possible. However, the owner has some strict rules that you must follow:
\t- You only have two baskets, and each basket can only hold a single type of fruit. There is no limit on the amount of fruit each basket can hold.
\t- Starting from any tree of your choice, you must pick exactly one fruit from every tree (including the start tree) while moving to the right. The picked fruits must fit in one of your baskets.
\t- Once you reach a tree with fruit that cannot fit in your baskets, you must stop.

Given the integer array \`fruits\`, return the maximum number of fruits you can pick.

\u00a0

Example 1:

\`\`\`
Input: fruits = [1,2,1]
Output: 3
Explanation: We can pick from all 3 trees.
\`\`\`

Example 2:

\`\`\`
Input: fruits = [0,1,2,2]
Output: 3
Explanation: We can pick from trees [1,2,2].
If we had started at the first tree, we would only pick from [0,1].
\`\`\`

Example 3:

\`\`\`
Input: fruits = [1,2,3,2,2]
Output: 4
Explanation: We can pick from trees [2,3,2,2].
If we had started at the first tree, we would only pick from [1,2].
\`\`\`

\u00a0

Constraints:

\t- 1 <= fruits.length <= 105
\t- 0 <= fruits[i] < fruits.length`,
  },

  // 15. Max Consecutive Ones III
  {
    slug: "max-consecutive-ones-iii",
    title: "Max Consecutive Ones III",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Sliding Window", "Prefix Sum"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 92.0,
    statement: `Given a binary array \`nums\` and an integer \`k\`, return the maximum number of consecutive \`1\`'s in the array if you can flip at most \`k\` \`0\`'s.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,1,1,0,0,0,1,1,1,1,0], k = 2
Output: 6
Explanation: [1,1,1,0,0,1,1,1,1,1,1]
Bold numbers were flipped from 0 to 1. The longest subarray is underlined.
\`\`\`

Example 2:

\`\`\`
Input: nums = [0,0,1,1,0,0,1,1,1,0,1,1,0,0,0,1,1,1,1], k = 3
Output: 10
Explanation: [0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1]
Bold numbers were flipped from 0 to 1. The longest subarray is underlined.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- nums[i] is either 0 or 1.
\t- 0 <= k <= nums.length`,
  },

  // 16. Binary Subarrays With Sum
  {
    slug: "binary-subarrays-with-sum",
    title: "Binary Subarrays With Sum",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Sliding Window", "Prefix Sum"],
    companies: ["amazon", "meta", "google"],
    freq: 86.0,
    statement: `Given a binary array \`nums\` and an integer \`goal\`, return the number of non-empty subarrays with a sum \`goal\`.

A subarray is a contiguous part of the array.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,0,1,0,1], goal = 2
Output: 4
Explanation: The 4 subarrays are bolded and underlined below:
[1,0,1]
[1,0,1,0]
[0,1,0,1]
[1,0,1]
\`\`\`

Example 2:

\`\`\`
Input: nums = [0,0,0,0,0], goal = 0
Output: 15
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 3 * 104
\t- nums[i] is either 0 or 1.
\t- 0 <= goal <= nums.length`,
  },

  // 17. Count Number of Nice Subarrays
  {
    slug: "count-number-of-nice-subarrays",
    title: "Count Number of Nice Subarrays",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Math", "Sliding Window"],
    companies: ["amazon", "google", "microsoft"],
    freq: 85.0,
    statement: `Given an array of integers \`nums\` and an integer \`k\`. A continuous subarray is called nice if there are \`k\` odd numbers on it.

Return the number of nice sub-arrays.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,1,2,1,1], k = 3
Output: 2
Explanation: The only sub-arrays with 3 odd numbers are [1,1,2,1] and [1,2,1,1].
\`\`\`

Example 2:

\`\`\`
Input: nums = [2,4,6], k = 1
Output: 0
Explanation: There are no odd numbers in the array.
\`\`\`

Example 3:

\`\`\`
Input: nums = [2,2,2,1,2,2,1,2,2,2], k = 2
Output: 16
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 50000
\t- 1 <= nums[i] <= 10^5
\t- 1 <= k <= nums.length`,
  },

  // 18. Number of Substrings Containing All Three Characters
  {
    slug: "number-of-substrings-containing-all-three-characters",
    title: "Number of Substrings Containing All Three Characters",
    difficulty: "Medium",
    topics: ["Hash Table", "String", "Sliding Window"],
    companies: ["amazon", "meta", "google"],
    freq: 84.0,
    statement: `Given a string \`s\` consisting only of characters \`a\`, \`b\` and \`c\`.

Return the number of substrings containing at least one occurrence of all these characters \`a\`, \`b\` and \`c\`.

\u00a0

Example 1:

\`\`\`
Input: s = "abcabc"
Output: 10
Explanation: The substrings containing at least one occurrence of the characters a, b and c are "abc", "abca", "abcab", "abcabc", "bca", "bcab", "bcabc", "cab", "cabc" and "abc" (again). 
\`\`\`

Example 2:

\`\`\`
Input: s = "aaacb"
Output: 3
Explanation: The substrings containing at least one occurrence of the characters a, b and c are "aaacb", "aacb" and "acb". 
\`\`\`

Example 3:

\`\`\`
Input: s = "abc"
Output: 1
\`\`\`

\u00a0

Constraints:

\t- 3 <= s.length <= 5 * 10^4
\t- s only consists of a, b or c characters.`,
  },

  // 19. Subarrays with K Different Integers
  {
    slug: "subarrays-with-k-different-integers",
    title: "Subarrays with K Different Integers",
    difficulty: "Hard",
    topics: ["Array", "Hash Table", "Sliding Window", "Counting"],
    companies: ["amazon", "google", "microsoft"],
    freq: 87.0,
    statement: `Given an integer array \`nums\` and an integer \`k\`, return the number of good subarrays of \`nums\`.

A good array is an array where the number of different integers in that array is exactly \`k\`.

For example, \`[1,2,3,1,2]\` has 3 different integers: \`1\`, \`2\`, and \`3\`.
A subarray is a contiguous part of an array.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,2,1,2,3], k = 2
Output: 7
Explanation: Subarrays formed with exactly 2 different integers: [1,2], [2,1], [1,2], [2,3], [1,2,1], [2,1,2], [1,2,1,2]
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,2,1,3,4], k = 3
Output: 3
Explanation: Subarrays formed with exactly 3 different integers: [1,2,1,3], [2,1,3], [1,3,4].
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 2 * 104
\t- 1 <= nums[i], k <= nums.length`,
  },

  // 20. Frequency of the Most Frequent Element
  {
    slug: "frequency-of-the-most-frequent-element",
    title: "Frequency of the Most Frequent Element",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Sliding Window", "Sorting", "Prefix Sum"],
    companies: ["meta", "amazon", "google"],
    freq: 88.0,
    statement: `The frequency of an element is the number of times it occurs in an array.

You are given an integer array \`nums\` and an integer \`k\`. In one operation, you can choose an index of \`nums\` and increment the element at that index by \`1\`.

Return the maximum possible frequency of an element after performing at most \`k\` operations.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,2,4], k = 5
Output: 3
Explanation: Increment the first element three times and the second element two times to make nums = [4,4,4].
4 has a frequency of 3.
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,4,8,13], k = 5
Output: 2
Explanation: There are multiple optimal solutions:
- Increment the first element three times to make nums = [4,4,8,13]. 4 has a frequency of 2.
- Increment the second element four times to make nums = [1,8,8,13]. 8 has a frequency of 2.
- Increment the third element five times to make nums = [1,4,13,13]. 13 has a frequency of 2.
\`\`\`

Example 3:

\`\`\`
Input: nums = [3,9,6], k = 2
Output: 1
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- 1 <= nums[i] <= 105
\t- 1 <= k <= 105`,
  },

  // 21. Minimum Operations to Reduce X to Zero
  {
    slug: "minimum-operations-to-reduce-x-to-zero",
    title: "Minimum Operations to Reduce X to Zero",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Binary Search", "Sliding Window", "Prefix Sum"],
    companies: ["google", "meta", "amazon"],
    freq: 86.0,
    statement: `You are given an integer array \`nums\` and an integer \`x\`. In one operation, you can either remove the leftmost or the rightmost element from the array \`nums\` and subtract its value from \`x\`. Note that this modifies the array for future operations.

Return the minimum number of operations to reduce \`x\` to exactly \`0\` if it is possible, otherwise, return \`-1\`.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,1,4,2,3], x = 5
Output: 2
Explanation: The optimal solution is to remove the last two elements, reducing x to zero.
\`\`\`

Example 2:

\`\`\`
Input: nums = [5,6,7,8,9], x = 4
Output: -1
\`\`\`

Example 3:

\`\`\`
Input: nums = [3,2,20,1,1,3], x = 10
Output: 5
Explanation: The optimal solution is to remove the last three elements and the first two elements (5 operations in total) to reduce x to zero.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- 1 <= nums[i] <= 104
\t- 1 <= x <= 109`,
  },

  // 22. Maximum Points You Can Obtain from Cards
  {
    slug: "maximum-points-you-can-obtain-from-cards",
    title: "Maximum Points You Can Obtain from Cards",
    difficulty: "Medium",
    topics: ["Array", "Sliding Window", "Prefix Sum"],
    companies: ["google", "amazon", "microsoft"],
    freq: 87.0,
    statement: `There are several cards arranged in a row, and each card has an associated number of points. The points are given in the integer array \`cardPoints\`.

In one step, you can take one card from the beginning or from the end of the row. You have to take exactly \`k\` cards.

Your score is the sum of the points of the cards you have taken.

Given the integer array \`cardPoints\` and the integer \`k\`, return the maximum score you can obtain.

\u00a0

Example 1:

\`\`\`
Input: cardPoints = [1,2,3,4,5,6,1], k = 3
Output: 12
Explanation: After the first step, your score will always be 1. However, choosing the rightmost card first will maximize your total score. The optimal strategy is to take the three cards on the right, giving a final score of 1 + 6 + 5 = 12.
\`\`\`

Example 2:

\`\`\`
Input: cardPoints = [2,2,2], k = 2
Output: 4
Explanation: Regardless of which two cards you take, your score will always be 4.
\`\`\`

Example 3:

\`\`\`
Input: cardPoints = [9,7,7,9,7,7,9], k = 7
Output: 55
Explanation: You have to take all the cards. Your score is the sum of all points.
\`\`\`

\u00a0

Constraints:

\t- 1 <= cardPoints.length <= 105
\t- 1 <= cardPoints[i] <= 104
\t- 1 <= k <= cardPoints.length`,
  },

  // 23. Replace the Substring for Balanced String
  {
    slug: "replace-the-substring-for-balanced-string",
    title: "Replace the Substring for Balanced String",
    difficulty: "Medium",
    topics: ["String", "Sliding Window"],
    companies: ["amazon", "google"],
    freq: 81.0,
    statement: `You are given a string s of length \`n\` containing only four kinds of characters: \`'Q'\`, \`'W'\`, \`'E'\`, and \`'R'\`.

A string is said to be balanced if each of its characters appears \`n / 4\` times where \`n\` is the length of the string.

Return the minimum length of the substring that can be replaced with any other string of the same length to make \`s\` balanced. If \`s\` is already balanced, return \`0\`.

\u00a0

Example 1:

\`\`\`
Input: s = "QWER"
Output: 0
Explanation: s is already balanced.
\`\`\`

Example 2:

\`\`\`
Input: s = "QQWE"
Output: 1
Explanation: We need to replace a 'Q' to 'R', so that "RQWE" (or "QRWE") is balanced.
\`\`\`

Example 3:

\`\`\`
Input: s = "QQQW"
Output: 2
Explanation: We can replace the first "QQ" to "ER". 
\`\`\`

\u00a0

Constraints:

\t- n == s.length
\t- 4 <= n <= 105
\t- n is a multiple of 4.
\t- s contains only 'Q', 'W', 'E', and 'R'.`,
  },

  // 24. Get Equal Substrings Within Budget
  {
    slug: "get-equal-substrings-within-budget",
    title: "Get Equal Substrings Within Budget",
    difficulty: "Medium",
    topics: ["String", "Binary Search", "Sliding Window", "Prefix Sum"],
    companies: ["amazon", "microsoft"],
    freq: 83.0,
    statement: `You are given two strings \`s\` and \`t\` of the same length and an integer \`maxCost\`.

You want to change \`s\` to \`t\`. Changing the \`i\`th character of \`s\` to \`i\`th character of \`t\` costs \`|s[i] - t[i]|\` (i.e., the absolute difference between the ASCII values of the characters).

Return the maximum length of a substring of \`s\` that can be changed to be the same as the corresponding substring of \`t\` with a cost less than or equal to \`maxCost\`. If there is no substring from \`s\` that can be changed to its corresponding substring from \`t\`, return \`0\`.

\u00a0

Example 1:

\`\`\`
Input: s = "abcd", t = "bcdf", maxCost = 3
Output: 3
Explanation: "abc" of s can change to "bcd". That costs 3, so the maximum length is 3.
\`\`\`

Example 2:

\`\`\`
Input: s = "abcd", t = "cdef", maxCost = 3
Output: 1
Explanation: Each character in s costs 2 to change to character in t,  so the maximum length is 1.
\`\`\`

Example 3:

\`\`\`
Input: s = "abcd", t = "acde", maxCost = 0
Output: 1
Explanation: You cannot make any change, so the maximum length is 1.
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 105
\t- t.length == s.length
\t- 0 <= maxCost <= 106
\t- s and t consist of only lowercase English letters.`,
  },

  // 25. Intersection of Two Linked Lists
  {
    slug: "intersection-of-two-linked-lists",
    title: "Intersection of Two Linked Lists",
    difficulty: "Easy",
    topics: ["Hash Table", "Linked List", "Two Pointers"],
    companies: ["amazon", "microsoft", "meta", "apple", "bloomberg", "google"],
    freq: 96.0,
    statement: `Given the heads of two singly linked-lists \`headA\` and \`headB\`, return the node at which the two lists intersect. If the two linked lists have no intersection at all, return \`null\`.

For example, the following two linked lists begin to intersect at node c1:

The test cases are generated such that there are no cycles anywhere in the entire linked structure.

Note that the linked lists must retain their original structure after the function returns.

\u00a0

Example 1:

\`\`\`
Input: intersectVal = 8, listA = [4,1,8,4,5], listB = [5,6,1,8,4,5], skipA = 2, skipB = 3
Output: Intersected at '8'
Explanation: The intersected node's value is 8 (note that this must not be 0 if the two lists intersect).
From the head of A, it reads as [4,1,8,4,5]. From the head of B, it reads as [5,6,1,8,4,5]. There are 2 nodes before the intersected node in A; There are 3 nodes before the intersected node in B.
\`\`\`

Example 2:

\`\`\`
Input: intersectVal = 2, listA = [1,9,1,2,4], listB = [3,2,4], skipA = 3, skipB = 1
Output: Intersected at '2'
Explanation: The intersected node's value is 2 (note that this must not be 0 if the two lists intersect).
From the head of A, it reads as [1,9,1,2,4]. From the head of B, it reads as [3,2,4]. There are 3 nodes before the intersected node in A; There are 1 node before the intersected node in B.
\`\`\`

Example 3:

\`\`\`
Input: intersectVal = 0, listA = [2,6,4], listB = [1,5], skipA = 3, skipB = 2
Output: No intersection
Explanation: From the head of A, it reads as [2,6,4]. From the head of B, it reads as [1,5]. Since the two lists do not intersect, intersectVal must be 0, while skipA and skipB can be arbitrary values.
Explanation: The two lists do not intersect, so return null.
\`\`\`

\u00a0

Constraints:

\t- The number of nodes of listA is in the m.
\t- The number of nodes of listB is in the n.
\t- 1 <= m, n <= 3 * 104
\t- 1 <= Node.val <= 105
\t- 0 <= skipA < m
\t- 0 <= skipB < n
\t- intersectVal is 0 if listA and listB do not intersect.
\t- intersectVal == listA[skipA] == listB[skipB] if listA and listB intersect.`,
  },
];
