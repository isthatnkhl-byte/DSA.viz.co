module.exports = [
  // 26. Sort List
  {
    slug: "sort-list",
    title: "Sort List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers", "Divide and Conquer", "Sorting", "Merge Sort"],
    companies: ["amazon", "meta", "google", "microsoft", "bloomberg"],
    freq: 92.0,
    statement: `Given the \`head\` of a linked list, return the list after sorting it in ascending order.

\u00a0

Example 1:

\`\`\`
Input: head = [4,2,1,3]
Output: [1,2,3,4]
\`\`\`

Example 2:

\`\`\`
Input: head = [-1,5,3,4,0]
Output: [-1,0,3,4,5]
\`\`\`

Example 3:

\`\`\`
Input: head = []
Output: []
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the list is in the range [0, 5 * 104].
\t- -105 <= Node.val <= 105

\u00a0

Follow up: Can you sort the linked list in O(n logn) time and O(1) memory (i.e. constant space)?`,
  },

  // 27. Split Linked List in Parts
  {
    slug: "split-linked-list-in-parts",
    title: "Split Linked List in Parts",
    difficulty: "Medium",
    topics: ["Linked List"],
    companies: ["amazon", "google", "meta"],
    freq: 82.0,
    statement: `Given the \`head\` of a singly linked list and an integer \`k\`, split the linked list into \`k\` consecutive linked list parts.

The length of each part should be as equal as possible: no two parts should have a size differing by more than one. This may lead to some parts being null.

The parts should be in the order of occurrence in the input list, and parts occurring earlier should always have a size greater than or equal to parts occurring later.

Return an array of the \`k\` parts.

\u00a0

Example 1:

\`\`\`
Input: head = [1,2,3], k = 5
Output: [[1],[2],[3],[],[]]
Explanation:
The first element output[0] has output[0].val = 1, output[0].next = null.
The last element output[4] is null, but its string representation as a ListNode is [].
\`\`\`

Example 2:

\`\`\`
Input: head = [1,2,3,4,5,6,7,8,9,10], k = 3
Output: [[1,2,3,4],[5,6,7],[8,9,10]]
Explanation:
The input has been split into consecutive parts with size difference at most 1, and earlier parts are a larger size than the later parts.
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the list is in the range [0, 1000].
\t- 0 <= Node.val <= 1000
\t- 1 <= k <= 50`,
  },

  // 28. Insert Greatest Common Divisors in Linked List
  {
    slug: "insert-greatest-common-divisors-in-linked-list",
    title: "Insert Greatest Common Divisors in Linked List",
    difficulty: "Medium",
    topics: ["Linked List", "Math", "Number Theory"],
    companies: ["google", "amazon"],
    freq: 80.0,
    statement: `Given the \`head\` of a linked list, in which each node contains an integer value.

Between every pair of adjacent nodes, insert a new node with a value equal to the greatest common divisor of them.

Return the linked list after insertion.

The greatest common divisor of two numbers is the largest positive integer that evenly divides both numbers.

\u00a0

Example 1:

\`\`\`
Input: head = [18,6,10,3]
Output: [18,6,6,2,10,1,3]
Explanation: The 1st node has value 18, 2nd 6. GCD(18,6) = 6.
The 2nd node has value 6, 3rd 10. GCD(6,10) = 2.
The 3rd node has value 10, 4th 3. GCD(10,3) = 1.
\`\`\`

Example 2:

\`\`\`
Input: head = [7]
Output: [7]
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the list is in the range [1, 5000].
\t- 1 <= Node.val <= 1000`,
  },

  // 29. Delete Nodes From Linked List Present in Array
  {
    slug: "delete-nodes-from-linked-list-present-in-array",
    title: "Delete Nodes From Linked List Present in Array",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Linked List"],
    companies: ["amazon", "microsoft"],
    freq: 81.0,
    statement: `You are given an array of integers \`nums\` and the \`head\` of a linked list. Return the \`head\` of the modified linked list after removing all nodes from the linked list that have a value that exists in \`nums\`.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,2,3], head = [1,2,3,4,5]
Output: [4,5]
Explanation: Remove the nodes with values 1, 2, and 3.
\`\`\`

Example 2:

\`\`\`
Input: nums = [1], head = [1,2,1,2,1,2]
Output: [2,2,2]
\`\`\`

Example 3:

\`\`\`
Input: nums = [5], head = [1,2,3,4]
Output: [1,2,3,4]
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- 1 <= nums[i] <= 105
\t- All elements in nums are unique.
\t- The number of nodes in the given list is in the range [1, 105].
\t- 1 <= Node.val <= 105`,
  },

  // 30. Merge In Between Linked Lists
  {
    slug: "merge-in-between-linked-lists",
    title: "Merge In Between Linked Lists",
    difficulty: "Medium",
    topics: ["Linked List"],
    companies: ["amazon", "apple"],
    freq: 79.0,
    statement: `You are given two linked lists: \`list1\` and \`list2\` of sizes \`n\` and \`m\` respectively.

Remove \`list1\`'s nodes from the \`a\`th node to the \`b\`th node, and put \`list2\` in their place.

Build the result list and return its head.

\u00a0

Example 1:

\`\`\`
Input: list1 = [10,1,13,6,9,5], a = 3, b = 4, list2 = [1000000,1000001,1000002]
Output: [10,1,13,1000000,1000001,1000002,5]
Explanation: We remove the nodes 3 and 4 and put the entire list2 in their place. The blue edges and nodes in the above figure indicate the result.
\`\`\`

Example 2:

\`\`\`
Input: list1 = [0,1,2,3,4,5,6], a = 2, b = 5, list2 = [1000000,1000001,1000002,1000003,1000004]
Output: [0,1,1000000,1000001,1000002,1000003,1000004,6]
\`\`\`

\u00a0

Constraints:

\t- 3 <= list1.length <= 104
\t- 1 <= a <= b < list1.length - 1
\t- 1 <= list2.length <= 104`,
  },

  // 31. Swapping Nodes in a Linked List
  {
    slug: "swapping-nodes-in-a-linked-list",
    title: "Swapping Nodes in a Linked List",
    difficulty: "Medium",
    topics: ["Linked List", "Two Pointers"],
    companies: ["meta", "amazon", "microsoft"],
    freq: 86.0,
    statement: `You are given the \`head\` of a linked list, and an integer \`k\`.

Return the head of the linked list after swapping the values of the \`k\`th node from the beginning and the \`k\`th node from the end (the list is 1-indexed).

\u00a0

Example 1:

\`\`\`
Input: head = [1,2,3,4,5], k = 2
Output: [1,4,3,2,5]
\`\`\`

Example 2:

\`\`\`
Input: head = [7,9,6,6,7,8,3,0,9,5], k = 5
Output: [7,9,6,6,8,7,3,0,9,5]
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the list is n.
\t- 1 <= k <= n <= 105
\t- 0 <= Node.val <= 100`,
  },

  // 32. Design Browser History
  {
    slug: "design-browser-history",
    title: "Design Browser History",
    difficulty: "Medium",
    topics: ["Array", "Linked List", "Stack", "Design", "Doubly-Linked List", "Data Stream"],
    companies: ["bloomberg", "google", "amazon", "meta"],
    freq: 91.0,
    statement: `You have a browser of one tab where you start on the \`homepage\` and you can visit another \`url\`, get back in the history number of \`steps\` or move forward in the history number of \`steps\`.

Implement the \`BrowserHistory\` class:
\t- \`BrowserHistory(string homepage)\` Initializes the object with the homepage of the browser.
\t- \`void visit(string url)\` Visits \`url\` from the current page. It clears up all the forward history.
\t- \`string back(int steps)\` Move \`steps\` back in history. If you can only return \`x\` steps in the history and \`steps > x\`, you will return only \`x\` steps. Return the current \`url\` after moving back in history at most \`steps\`.
\t- \`string forward(int steps)\` Move \`steps\` forward in history. If you can only forward \`x\` steps in the history and \`steps > x\`, you will forward only \`x\` steps. Return the current \`url\` after forwarding in history at most \`steps\`.

\u00a0

Example:

\`\`\`
Input:
["BrowserHistory","visit","visit","visit","back","back","forward","visit","forward","back","back"]
[["leetcode.com"],["google.com"],["facebook.com"],["youtube.com"],[1],[1],[1],["linkedin.com"],[2],[2],[7]]
Output:
[null,null,null,null,"facebook.com","google.com","facebook.com",null,"linkedin.com","google.com","leetcode.com"]
\`\`\`

\u00a0

Constraints:

\t- 1 <= homepage.length <= 20
\t- 1 <= url.length <= 20
\t- 1 <= steps <= 100
\t- homepage and url consist of  '.' or lower case English letters.
\t- At most 5000 calls will be made to visit, back, and forward.`,
  },

  // 33. Find Minimum in Rotated Sorted Array II
  {
    slug: "find-minimum-in-rotated-sorted-array-ii",
    title: "Find Minimum in Rotated Sorted Array II",
    difficulty: "Hard",
    topics: ["Array", "Binary Search"],
    companies: ["amazon", "meta", "microsoft", "google"],
    freq: 85.0,
    statement: `Suppose an array of length \`n\` sorted in ascending order is rotated between \`1\` and \`n\` times. For example, the array \`nums = [0,1,4,4,5,6,7]\` might become:
\t- \`[4,5,6,7,0,1,4]\` if it was rotated 4 times.
\t- \`[0,1,4,4,5,6,7]\` if it was rotated 7 times.

Notice that rotating an array \`[a[0], a[1], a[2], ..., a[n-1]]\` 1 time results in the array \`[a[n-1], a[0], a[1], a[2], ..., a[n-2]]\`.

Given the sorted rotated array \`nums\` that may contain duplicates, return the minimum element of this array.

You must decrease the overall operation steps as much as possible.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,3,5]
Output: 1
\`\`\`

Example 2:

\`\`\`
Input: nums = [2,2,2,0,1]
Output: 0
\`\`\`

\u00a0

Constraints:

\t- n == nums.length
\t- 1 <= n <= 5000
\t- -5000 <= nums[i] <= 5000
\t- nums is sorted and rotated between 1 and n times.`,
  },

  // 34. Minimum Number of Days to Make m Bouquets
  {
    slug: "minimum-number-of-days-to-make-m-bouquets",
    title: "Minimum Number of Days to Make m Bouquets",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["amazon", "google", "bloomberg"],
    freq: 88.0,
    statement: `You are given an integer array \`bloomDay\`, an integer \`m\` and an integer \`k\`.

You want to make \`m\` bouquets. To make a bouquet, you need to use \`k\` adjacent flowers from the garden.

The garden consists of \`n\` flowers, the \`i\`th flower will bloom in the \`bloomDay[i]\` and then can be used in exactly one bouquet.

Return the minimum number of days you need to wait to be able to make \`m\` bouquets from the garden. If it is impossible to make \`m\` bouquets return \`-1\`.

\u00a0

Example 1:

\`\`\`
Input: bloomDay = [1,10,3,10,2], m = 3, k = 1
Output: 3
Explanation: Let us see what happened in the first three days:
Day 1: [x, _, _, _, _]   // we can only make 1 bouquet.
Day 2: [x, _, _, _, x]   // we can only make 2 bouquets.
Day 3: [x, _, x, _, x]   // now we can make 3 bouquets. The answer is 3.
\`\`\`

Example 2:

\`\`\`
Input: bloomDay = [1,10,3,10,2], m = 3, k = 2
Output: -1
Explanation: We need 3 bouquets each should have 2 flowers. That means we need 6 flowers. We only have 5 flowers so it is impossible to get the needed bouquets and we return -1.
\`\`\`

Example 3:

\`\`\`
Input: bloomDay = [7,7,7,7,12,7,7], m = 2, k = 3
Output: 12
Explanation: We need 2 bouquets each should have 3 flowers.
Here is the garden after the 7 and 12 days:
After day 7: [x, x, x, x, _, x, x]
We can make one bouquet of the first three flowers that bloomed. We cannot make another bouquet from the last three (which would require all of them to bloom).
After day 12: [x, x, x, x, x, x, x]
It is obvious that we can make two bouquets in different ways.
\`\`\`

\u00a0

Constraints:

\t- bloomDay.length == n
\t- 1 <= n <= 105
\t- 1 <= bloomDay[i] <= 109
\t- 1 <= m <= 106
\t- 1 <= k <= n`,
  },

  // 35. Kth Missing Positive Number
  {
    slug: "kth-missing-positive-number",
    title: "Kth Missing Positive Number",
    difficulty: "Easy",
    topics: ["Array", "Binary Search"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 85.0,
    statement: `Given an array \`arr\` of positive integers sorted in a strictly increasing order, and an integer \`k\`.

Return the \`k\`th positive integer that is missing from this array.

\u00a0

Example 1:

\`\`\`
Input: arr = [2,3,4,7,11], k = 5
Output: 9
Explanation: The missing positive integers are [1,5,6,8,9,10,12,...]. The 5th missing positive integer is 9.
\`\`\`

Example 2:

\`\`\`
Input: arr = [1,2,3,4], k = 2
Output: 6
Explanation: The missing positive integers are [5,6,7,...]. The 2nd missing positive integer is 6.
\`\`\`

\u00a0

Constraints:

\t- 1 <= arr.length <= 1000
\t- 1 <= arr[i] <= 1000
\t- 1 <= k <= 1000
\t- arr[i] < arr[j] for 1 <= i < j <= arr.length`,
  },

  // 36. Find Peak Element II
  {
    slug: "find-peak-element-ii",
    title: "Find a Peak Element II",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Matrix"],
    companies: ["amazon", "google", "meta"],
    freq: 83.0,
    statement: `A peak element in a 2D grid is an element that is strictly greater than all of its adjacent neighbors to the left, right, top, and bottom.

Given a 0-indexed \`m x n\` matrix \`mat\` where no two adjacent cells are equal, find any peak element \`mat[i][j]\` and return the length 2 array \`[i, j]\`.

You may assume that the entire matrix is surrounded by an outer perimeter with the value \`-1\` in each cell.

You must write an algorithm that runs in \`O(m log(n))\` or \`O(n log(m))\` time.

\u00a0

Example 1:

\`\`\`
Input: mat = [[1,4],[3,2]]
Output: [0,1]
Explanation: Both 3 and 4 are peak elements. So [1,0] and [0,1] are both acceptable answers.
\`\`\`

Example 2:

\`\`\`
Input: mat = [[10,20,15],[21,30,14],[7,16,32]]
Output: [1,1]
Explanation: Both 30 and 32 are peak elements. So [1,1] and [2,2] are both acceptable answers.
\`\`\`

\u00a0

Constraints:

\t- m == mat.length
\t- n == mat[i].length
\t- 1 <= m, n <= 500
\t- 1 <= mat[i][j] <= 105
\t- No two adjacent cells are equal.`,
  },

  // 37. Count Negative Numbers in a Sorted Matrix
  {
    slug: "count-negative-numbers-in-a-sorted-matrix",
    title: "Count Negative Numbers in a Sorted Matrix",
    difficulty: "Easy",
    topics: ["Array", "Binary Search", "Matrix"],
    companies: ["amazon", "microsoft", "apple"],
    freq: 78.0,
    statement: `Given a \`m x n\` matrix \`grid\` which is sorted in non-increasing order both row-wise and column-wise, return the number of negative numbers in \`grid\`.

\u00a0

Example 1:

\`\`\`
Input: grid = [[4,3,2,-1],[3,2,1,-1],[1,1,-1,-2],[-1,-1,-2,-3]]
Output: 8
Explanation: There are 8 negatives number in the matrix.
\`\`\`

Example 2:

\`\`\`
Input: grid = [[3,2],[1,0]]
Output: 0
\`\`\`

\u00a0

Constraints:

\t- m == grid.length
\t- n == grid[i].length
\t- 1 <= m, n <= 100
\t- -100 <= grid[i][j] <= 100`,
  },

  // 38. Arranging Coins
  {
    slug: "arranging-coins",
    title: "Arranging Coins",
    difficulty: "Easy",
    topics: ["Math", "Binary Search"],
    companies: ["bloomberg", "google"],
    freq: 77.0,
    statement: `You have \`n\` coins and you want to build a staircase with these coins. The staircase consists of \`k\` rows where the \`i\`th row has exactly \`i\` coins. The last row of the staircase may be incomplete.

Given the integer \`n\`, return the number of complete rows of the staircase you will build.

\u00a0

Example 1:

\`\`\`
Input: n = 5
Output: 2
Explanation: Because the 3rd row is incomplete, we return 2.
\`\`\`

Example 2:

\`\`\`
Input: n = 8
Output: 3
Explanation: Because the 4th row is incomplete, we return 3.
\`\`\`

\u00a0

Constraints:

\t- 1 <= n <= 231 - 1`,
  },

  // 39. Valid Perfect Square
  {
    slug: "valid-perfect-square",
    title: "Valid Perfect Square",
    difficulty: "Easy",
    topics: ["Math", "Binary Search"],
    companies: ["linkedin", "meta", "google"],
    freq: 79.0,
    statement: `Given a positive integer \`num\`, return \`true\` if \`num\` is a perfect square or \`false\` otherwise.

A perfect square is an integer that is the square of an integer. In other words, it is the product of some integer with itself.

You must not use any built-in library function, such as \`sqrt\`.

\u00a0

Example 1:

\`\`\`
Input: num = 16
Output: true
Explanation: We return true because 4 * 4 = 16 and 4 is an integer.
\`\`\`

Example 2:

\`\`\`
Input: num = 14
Output: false
Explanation: We return false because 3.742 * 3.742 = 14 and 3.742 is not an integer.
\`\`\`

\u00a0

Constraints:

\t- 1 <= num <= 231 - 1`,
  },

  // 40. Minimum Limit of Balls in a Bag
  {
    slug: "minimum-limit-of-balls-in-a-bag",
    title: "Minimum Limit of Balls in a Bag",
    difficulty: "Medium",
    topics: ["Array", "Binary Search"],
    companies: ["amazon", "google"],
    freq: 80.0,
    statement: `You are given an integer array \`nums\` where the \`i\`th bag contains \`nums[i]\` balls. You are also given an integer \`maxOperations\`.

You can perform the following operation at most \`maxOperations\` times:
\t- Take any bag of balls and divide it into two new bags with a positive number of balls.
\t- For example, a bag of 5 balls can become two new bags of 1 and 4 balls, or two new bags of 2 and 3 balls.

Your penalty is the maximum number of balls in a bag. You want to minimize your penalty after the operations.

Return the minimum possible penalty after performing the operations.

\u00a0

Example 1:

\`\`\`
Input: nums = [9], maxOperations = 2
Output: 3
Explanation: 
- Divide the bag with 9 balls into two bags of sizes 6 and 3. [9] -> [6,3].
- Divide the bag with 6 balls into two bags of sizes 3 and 3. [6,3] -> [3,3,3].
The bag with the most number of balls has 3 balls, so your penalty is 3 and you should return 3.
\`\`\`

Example 2:

\`\`\`
Input: nums = [2,4,8,2], maxOperations = 4
Output: 2
Explanation:
- Divide the bag with 8 balls into two bags of sizes 4 and 4. [2,4,8,2] -> [2,4,4,4,2].
- Divide the bag with 4 balls into two bags of sizes 2 and 2. [2,4,4,4,2] -> [2,2,2,4,4,2].
- Divide the bag with 4 balls into two bags of sizes 2 and 2. [2,2,2,4,4,2] -> [2,2,2,2,2,4,2].
- Divide the bag with 4 balls into two bags of sizes 2 and 2. [2,2,2,2,2,4,2] -> [2,2,2,2,2,2,2,2].
The bag with the most number of balls has 2 balls, so your penalty is 2 and you should return 2.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- 1 <= maxOperations, nums[i] <= 109`,
  },

  // 41. Special Array II
  {
    slug: "special-array-ii",
    title: "Special Array II",
    difficulty: "Medium",
    topics: ["Array", "Binary Search", "Prefix Sum"],
    companies: ["google", "amazon"],
    freq: 79.0,
    statement: `An array is considered special if every pair of its adjacent elements contains two numbers with different parity.

You are given an array of integer \`nums\` and a 2D integer matrix \`queries\` where for \`queries[i] = [fromi, toi]\` you want to check that subarray \`nums[fromi..toi]\` is special or not.

Return an array of booleans \`answer\` such that \`answer[i]\` is \`true\` if \`nums[fromi..toi]\` is special.

\u00a0

Example 1:

\`\`\`
Input: nums = [3,4,1,2,6], queries = [[0,4]]
Output: [false]
Explanation: The subarray is [3,4,1,2,6]. 2 and 6 are both even.
\`\`\`

Example 2:

\`\`\`
Input: nums = [4,3,1,6], queries = [[0,2],[2,3]]
Output: [false,true]
Explanation:
- The subarray is [4,3,1]. 3 and 1 are both odd. So the answer to this query is false.
- The subarray is [1,6]. There is only one pair: (1,6) and it contains numbers with different parity. So the answer to this query is true.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 105
\t- 1 <= nums[i] <= 105
\t- 1 <= queries.length <= 105
\t- queries[i].length == 2
\t- 0 <= queries[i][0] <= queries[i][1] <= nums.length - 1`,
  },

  // 42. Sum of Subarray Ranges
  {
    slug: "sum-of-subarray-ranges",
    title: "Sum of Subarray Ranges",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Monotonic Stack"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 88.0,
    statement: `You are given an integer array \`nums\`. The range of a subarray of \`nums\` is the difference between the largest and smallest element in the subarray.

Return the sum of all subarray ranges of \`nums\`.

A subarray is a contiguous non-empty sequence of elements within an array.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,2,3]
Output: 4
Explanation: The 6 subarrays of nums are the following:
[1], range = largest - smallest = 1 - 1 = 0 
[2], range = 2 - 2 = 0
[3], range = 3 - 3 = 0
[1,2], range = 2 - 1 = 1
[2,3], range = 3 - 2 = 1
[1,2,3], range = 3 - 1 = 2
So the sum of all ranges is 0 + 0 + 0 + 1 + 1 + 2 = 4.
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,3,3]
Output: 4
Explanation: The 6 subarrays of nums are the following:
[1], range = largest - smallest = 1 - 1 = 0
[3], range = 3 - 3 = 0
[3], range = 3 - 3 = 0
[1,3], range = 3 - 1 = 2
[3,3], range = 3 - 3 = 0
[1,3,3], range = 3 - 1 = 2
So the sum of all ranges is 0 + 0 + 0 + 2 + 0 + 2 = 4.
\`\`\`

Example 3:

\`\`\`
Input: nums = [4,-2,-3,4,1]
Output: 59
Explanation: The sum of all subarray ranges of nums is 59.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 1000
\t- -109 <= nums[i] <= 109

\u00a0

Follow-up: Could you find a solution with O(n) time complexity?`,
  },

  // 43. Next Greater Node In Linked List
  {
    slug: "next-greater-node-in-linked-list",
    title: "Next Greater Node In Linked List",
    difficulty: "Medium",
    topics: ["Array", "Linked List", "Stack", "Monotonic Stack"],
    companies: ["amazon", "microsoft"],
    freq: 83.0,
    statement: `You are given the \`head\` of a linked list with \`n\` nodes.

For each node in the list, find the value of the next greater node. That is, for each node, find the value of the first node that is next to it and has a strictly larger value than it.

Return an integer array \`answer\` where \`answer[i]\` is the value of the next greater node of the \`i\`th node (1-indexed). If the \`i\`th node does not have a next greater node, set \`answer[i] = 0\`.

\u00a0

Example 1:

\`\`\`
Input: head = [2,1,5]
Output: [5,5,0]
\`\`\`

Example 2:

\`\`\`
Input: head = [2,7,4,3,5]
Output: [7,0,5,5,0]
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the list is n.
\t- 1 <= n <= 104
\t- 1 <= Node.val <= 109`,
  },

  // 44. Minimum Remove to Make Valid Parentheses
  {
    slug: "minimum-remove-to-make-valid-parentheses",
    title: "Minimum Remove to Make Valid Parentheses",
    difficulty: "Medium",
    topics: ["String", "Stack"],
    companies: ["meta", "amazon", "bloomberg", "google", "microsoft"],
    freq: 94.0,
    statement: `Given a string s of \`'('\` , \`')'\` and lowercase English characters.

Your task is to remove the minimum number of parentheses ( \`'('\` or \`')'\`, in any positions ) so that the resulting parentheses string is valid and return any valid string.

Formally, a parentheses string is valid if and only if:
\t- It is the empty string, contains only lowercase characters, or
\t- It can be written as \`AB\` (\`A\` concatenated with \`B\`), where \`A\` and \`B\` are valid strings, or
\t- It can be written as \`(A)\`, where \`A\` is a valid string.

\u00a0

Example 1:

\`\`\`
Input: s = "lee(t(c)o)de)"
Output: "lee(t(c)o)de"
Explanation: "lee(t(co)de)" , "lee(t(c)ode)" would also be accepted.
\`\`\`

Example 2:

\`\`\`
Input: s = "a)b(c)d"
Output: "ab(c)d"
\`\`\`

Example 3:

\`\`\`
Input: s = "))(("
Output: ""
Explanation: An empty string is also valid.
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 105
\t- s[i] is either '(' , ')', or lowercase English letter.`,
  },

  // 45. Remove All Adjacent Duplicates In String
  {
    slug: "remove-all-adjacent-duplicates-in-string",
    title: "Remove All Adjacent Duplicates In String",
    difficulty: "Easy",
    topics: ["String", "Stack"],
    companies: ["meta", "bloomberg", "amazon"],
    freq: 87.0,
    statement: `You are given a string \`s\` consisting of lowercase English letters. A duplicate removal consists of choosing two adjacent and equal letters and removing them.

We repeatedly make duplicate removals on \`s\` until we no longer can.

Return the final string after all such duplicate removals have been made. It can be proven that the answer is unique.

\u00a0

Example 1:

\`\`\`
Input: s = "abbaca"
Output: "ca"
Explanation: 
For example, in "abbaca" we could remove "bb" since the letters are adjacent and equal, and this is the only possible move.  The result of this move is "aaca", of which only "aa" is possible, so the final string is "ca".
\`\`\`

Example 2:

\`\`\`
Input: s = "azxxzy"
Output: "ay"
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 105
\t- s consists of lowercase English letters.`,
  },

  // 46. Score of Parentheses
  {
    slug: "score-of-parentheses",
    title: "Score of Parentheses",
    difficulty: "Medium",
    topics: ["String", "Stack"],
    companies: ["meta", "amazon", "microsoft"],
    freq: 85.0,
    statement: `Given a balanced parentheses string \`s\`, return the score of the string.

The score of a balanced parentheses string is based on the following rule:
\t- \`"()"\` has score 1.
\t- \`AB\` has score \`A + B\`, where A and B are balanced parentheses strings.
\t- \`(A)\` has score \`2 * A\`, where A is a balanced parentheses string.

\u00a0

Example 1:

\`\`\`
Input: s = "()"
Output: 1
\`\`\`

Example 2:

\`\`\`
Input: s = "(())"
Output: 2
\`\`\`

Example 3:

\`\`\`
Input: s = "()()"
Output: 2
\`\`\`

\u00a0

Constraints:

\t- 2 <= s.length <= 50
\t- s consists of only '(' and ')'.
\t- s is a balanced parentheses string.`,
  },

  // 47. Design Circular Deque
  {
    slug: "design-circular-deque",
    title: "Design Circular Deque",
    difficulty: "Medium",
    topics: ["Array", "Linked List", "Design", "Queue"],
    companies: ["meta", "google", "amazon"],
    freq: 82.0,
    statement: `Design your implementation of the circular double-ended queue (deque).

Implement the \`MyCircularDeque\` class:
\t- \`MyCircularDeque(int k)\` Initializes the deque with a maximum size of \`k\`.
\t- \`boolean insertFront()\` Adds an item at the front of Deque. Indicates \`true\` if the operation is successful, or \`false\` otherwise.
\t- \`boolean insertLast()\` Adds an item at the rear of Deque. Indicates \`true\` if the operation is successful, or \`false\` otherwise.
\t- \`boolean deleteFront()\` Deletes an item from the front of Deque. Indicates \`true\` if the operation is successful, or \`false\` otherwise.
\t- \`boolean deleteLast()\` Deletes an item from the rear of Deque. Indicates \`true\` if the operation is successful, or \`false\` otherwise.
\t- \`int getFront()\` Returns the front item from the Deque. If the deque is empty, return \`-1\`.
\t- \`int getRear()\` Returns the last item from Deque. If the deque is empty, return \`-1\`.
\t- \`boolean isEmpty()\` Returns \`true\` if the deque is empty, or \`false\` otherwise.
\t- \`boolean isFull()\` Returns \`true\` if the deque is full, or \`false\` otherwise.

\u00a0

Example 1:

\`\`\`
Input
["MyCircularDeque", "insertLast", "insertLast", "insertFront", "insertFront", "getRear", "isFull", "deleteLast", "insertFront", "getFront"]
[[3], [1], [2], [3], [4], [], [], [], [4], []]
Output
[null, true, true, true, false, 2, true, true, true, 4]
\`\`\`

\u00a0

Constraints:

\t- 1 <= k <= 1000
\t- 0 <= value <= 1000
\t- At most 2000 calls will be made to insertFront, insertLast, deleteFront, deleteLast, getFront, getRear, isEmpty, isFull.`,
  },

  // 48. Minimum Add to Make Parentheses Valid
  {
    slug: "minimum-add-to-make-parentheses-valid",
    title: "Minimum Add to Make Parentheses Valid",
    difficulty: "Medium",
    topics: ["String", "Stack", "Greedy"],
    companies: ["meta", "amazon", "bloomberg"],
    freq: 89.0,
    statement: `A parentheses string is valid if and only if:
\t- It is the empty string,
\t- It can be written as \`AB\` (\`A\` concatenated with \`B\`), where \`A\` and \`B\` are valid strings, or
\t- It can be written as \`(A)\`, where \`A\` is a valid string.

You are given a parentheses string \`s\`. In one move, you can insert a parenthesis at any position of the string.

Return the minimum number of moves required to make \`s\` valid.

\u00a0

Example 1:

\`\`\`
Input: s = "())"
Output: 1
\`\`\`

Example 2:

\`\`\`
Input: s = "((("
Output: 3
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 1000
\t- s[i] is either '(' or ')'.`,
  },

  // 49. Max Chunks To Make Sorted
  {
    slug: "max-chunks-to-make-sorted",
    title: "Max Chunks To Make Sorted",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Greedy", "Sorting", "Monotonic Stack"],
    companies: ["google", "amazon"],
    freq: 84.0,
    statement: `You are given an integer array \`nums\` of length \`n\` that represents a permutation of the integers in the range \`[0, n - 1]\`.

We split \`nums\` into some number of chunks (i.e., partitions), and individually sort each chunk. After concatenating them, the result should equal the sorted array.

Return the largest number of chunks we can make to sort the array.

\u00a0

Example 1:

\`\`\`
Input: nums = [4,3,2,1,0]
Output: 1
Explanation:
Splitting into two or more chunks will not return the required result.
For example, splitting into [4, 3], [2, 1, 0] will result in [3, 4, 0, 1, 2], which isn't sorted.
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,0,2,3,4]
Output: 4
Explanation:
We can split them into two chunks, such as [1, 0], [2, 3, 4].
However, splitting into [1, 0], [2], [3], [4] is the highest number of chunks possible.
\`\`\`

\u00a0

Constraints:

\t- n == nums.length
\t- 1 <= n <= 10
\t- 0 <= nums[i] < n
\t- All the elements of nums are unique.`,
  },

  // 50. Max Chunks To Make Sorted II
  {
    slug: "max-chunks-to-make-sorted-ii",
    title: "Max Chunks To Make Sorted II",
    difficulty: "Hard",
    topics: ["Array", "Stack", "Greedy", "Sorting", "Monotonic Stack"],
    companies: ["google", "amazon"],
    freq: 85.0,
    statement: `You are given an integer array \`nums\`.

We split \`nums\` into some number of chunks (i.e., partitions), and individually sort each chunk. After concatenating them, the result should equal the sorted array.

Return the largest number of chunks we can make to sort the array.

\u00a0

Example 1:

\`\`\`
Input: nums = [5,4,3,2,1]
Output: 1
Explanation:
Splitting into two or more chunks will not return the required result.
For example, splitting into [5, 4], [3, 2, 1] will result in [4, 5, 1, 2, 3], which isn't sorted.
\`\`\`

Example 2:

\`\`\`
Input: nums = [2,1,3,4,4]
Output: 4
Explanation:
We can split them into two chunks, such as [2, 1], [3, 4, 4].
However, splitting into [2, 1], [3], [4], [4] is the highest number of chunks possible.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 2000
\t- 0 <= nums[i] <= 108`,
  },
];
