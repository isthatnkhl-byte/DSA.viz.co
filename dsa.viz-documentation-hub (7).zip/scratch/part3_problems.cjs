module.exports = [
  // 51. Search in a Binary Search Tree
  {
    slug: "search-in-a-binary-search-tree",
    title: "Search in a Binary Search Tree",
    difficulty: "Easy",
    topics: ["Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 85.0,
    statement: `You are given the \`root\` of a binary search tree (BST) and an integer \`val\`.

Find the node in the BST that the node's value equals \`val\` and return the subtree rooted with that node. If such a node does not exist, return \`null\`.

\u00a0

Example 1:

\`\`\`
Input: root = [4,2,7,1,3], val = 2
Output: [2,1,3]
\`\`\`

Example 2:

\`\`\`
Input: root = [4,2,7,1,3], val = 5
Output: []
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [1, 5000].
\t- 1 <= Node.val <= 107
\t- root is a binary search tree.
\t- 1 <= val <= 107`,
  },

  // 52. Insert into a Binary Search Tree
  {
    slug: "insert-into-a-binary-search-tree",
    title: "Insert into a Binary Search Tree",
    difficulty: "Medium",
    topics: ["Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "google", "microsoft", "meta"],
    freq: 87.0,
    statement: `You are given the \`root\` node of a binary search tree (BST) and a \`val\` to insert into the tree. Return the root node of the BST after the insertion. It is guaranteed that the new value does not exist in the original BST.

Notice that there may exist multiple valid ways for the insertion, as long as the tree remains a BST after insertion. You can return any of them.

\u00a0

Example 1:

\`\`\`
Input: root = [4,2,7,1,3], val = 5
Output: [4,2,7,1,3,5]
\`\`\`

Example 2:

\`\`\`
Input: root = [40,20,60,10,30,50,70], val = 25
Output: [40,20,60,10,30,50,70,null,null,25]
\`\`\`

Example 3:

\`\`\`
Input: root = [4,2,7,1,3,null,null,null,null,null,null], val = 5
Output: [4,2,7,1,3,5]
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree will be in the range [0, 104].
\t- -108 <= Node.val <= 108
\t- All the values Node.val are unique.
\t- -108 <= val <= 108
\t- It's guaranteed that val does not exist in the original BST.`,
  },

  // 53. Two Sum IV - Input is a BST
  {
    slug: "two-sum-iv-input-is-a-bst",
    title: "Two Sum IV - Input is a BST",
    difficulty: "Easy",
    topics: ["Hash Table", "Two Pointers", "Tree", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "meta", "microsoft"],
    freq: 83.0,
    statement: `Given the \`root\` of a binary search tree and an integer \`k\`, return \`true\` if there exist two elements in the BST such that their sum is equal to \`k\`, or \`false\` otherwise.

\u00a0

Example 1:

\`\`\`
Input: root = [5,3,6,2,4,null,7], k = 9
Output: true
\`\`\`

Example 2:

\`\`\`
Input: root = [5,3,6,2,4,null,7], k = 28
Output: false
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [1, 104].
\t- -104 <= Node.val <= 104
\t- root is guaranteed to be a valid binary search tree.
\t- -105 <= k <= 105`,
  },

  // 54. Recover Binary Search Tree
  {
    slug: "recover-binary-search-tree",
    title: "Recover Binary Search Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Binary Search Tree", "Binary Tree"],
    companies: ["amazon", "microsoft", "google", "meta"],
    freq: 88.0,
    statement: `You are given the \`root\` of a binary search tree (BST), where the values of exactly two nodes of the tree were swapped by mistake. Recover the tree without changing its structure.

\u00a0

Example 1:

\`\`\`
Input: root = [1,3,null,null,2]
Output: [3,1,null,null,2]
Explanation: 3 cannot be a left child of 1 because 3 > 1. Swapping 1 and 3 makes the BST valid.
\`\`\`

Example 2:

\`\`\`
Input: root = [3,1,4,null,null,2]
Output: [2,1,4,null,null,3]
Explanation: 2 cannot be in the right subtree for 3 because 2 < 3. Swapping 2 and 3 makes the BST valid.
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [2, 1000].
\t- -231 <= Node.val <= 231 - 1

\u00a0

Follow up: A solution using O(n) space is pretty straight-forward. Could you devise a constant O(1) space solution?`,
  },

  // 55. Construct Binary Search Tree from Preorder Traversal
  {
    slug: "construct-binary-search-tree-from-preorder-traversal",
    title: "Construct Binary Search Tree from Preorder Traversal",
    difficulty: "Medium",
    topics: ["Array", "Stack", "Tree", "Binary Search Tree", "Monotonic Stack", "Binary Tree"],
    companies: ["meta", "amazon", "microsoft"],
    freq: 86.0,
    statement: `Given an array of integers preorder, which represents the preorder traversal of a BST (i.e., binary search tree), construct the tree and return its root.

It is guaranteed that there is always possible to find a binary search tree with the given requirements for the given test cases.

A binary search tree is a binary tree where for every node, any descendant of \`Node.left\` has a value strictly less than \`Node.val\`, and any descendant of \`Node.right\` has a value strictly greater than \`Node.val\`.

A preorder traversal of a binary tree displays the value of the node first, then traverses \`Node.left\`, then traverses \`Node.right\`.

\u00a0

Example 1:

\`\`\`
Input: preorder = [8,5,1,7,10,12]
Output: [8,5,10,1,7,null,12]
\`\`\`

Example 2:

\`\`\`
Input: preorder = [1,3]
Output: [1,null,3]
\`\`\`

\u00a0

Constraints:

\t- 1 <= preorder.length <= 100
\t- 1 <= preorder[i] <= 1000
\t- All the values of preorder are unique.`,
  },

  // 56. Count Complete Tree Nodes
  {
    slug: "count-complete-tree-nodes",
    title: "Count Complete Tree Nodes",
    difficulty: "Easy",
    topics: ["Binary Search", "Tree", "Depth-First Search", "Binary Tree"],
    companies: ["google", "amazon", "meta"],
    freq: 85.0,
    statement: `Given the \`root\` of a complete binary tree, return the number of the nodes in the tree.

According to Wikipedia, every level, except possibly the last, is completely filled in a complete binary tree, and all nodes in the last level are as far left as possible. It can have between 1 and 2h nodes inclusive at the last level h.

Design an algorithm that runs in less than \`O(n)\` time complexity.

\u00a0

Example 1:

\`\`\`
Input: root = [1,2,3,4,5,6]
Output: 6
\`\`\`

Example 2:

\`\`\`
Input: root = []
Output: 0
\`\`\`

Example 3:

\`\`\`
Input: root = [1]
Output: 1
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [0, 5 * 104].
\t- 0 <= Node.val <= 5 * 104
\t- The tree is guaranteed to be complete.`,
  },

  // 57. Cousins in Binary Tree
  {
    slug: "cousins-in-binary-tree",
    title: "Cousins in Binary Tree",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["amazon", "microsoft", "google"],
    freq: 80.0,
    statement: `Given the \`root\` of a binary tree with unique values and the values of two different nodes of the tree \`x\` and \`y\`, return \`true\` if the nodes corresponding to the values \`x\` and \`y\` in the tree are cousins, or \`false\` otherwise.

Two nodes of a binary tree are cousins if they have the same depth with different parents.

Note that in a tree, the root node is at the depth 0, and children of each 0-indexed node are at the depth d + 1.

\u00a0

Example 1:

\`\`\`
Input: root = [1,2,3,4], x = 4, y = 3
Output: false
\`\`\`

Example 2:

\`\`\`
Input: root = [1,2,3,null,4,null,5], x = 5, y = 4
Output: true
\`\`\`

Example 3:

\`\`\`
Input: root = [1,2,3,null,4], x = 2, y = 3
Output: false
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [2, 100].
\t- 1 <= Node.val <= 100
\t- Each node has a unique value.
\t- x != y
\t- x and y are exist in the tree.`,
  },

  // 58. Increasing Order Search Tree
  {
    slug: "increasing-order-search-tree",
    title: "Increasing Order Search Tree",
    difficulty: "Easy",
    topics: ["Stack", "Tree", "Depth-First Search", "Binary Search Tree", "Binary Tree"],
    companies: ["meta", "amazon"],
    freq: 78.0,
    statement: `Given the \`root\` of a binary search tree, rearrange the tree in in-order so that the leftmost node in the tree is now the root of the tree, and every node has no left child and only one right child.

\u00a0

Example 1:

\`\`\`
Input: root = [5,3,6,2,4,null,8,1,null,null,null,7,9]
Output: [1,null,2,null,3,null,4,null,5,null,6,null,7,null,8,null,9]
\`\`\`

Example 2:

\`\`\`
Input: root = [5,1,7]
Output: [1,null,5,null,7]
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the given tree will be in the range [1, 100].
\t- 0 <= Node.val <= 1000`,
  },

  // 59. Maximum Level Sum of a Binary Tree
  {
    slug: "maximum-level-sum-of-a-binary-tree",
    title: "Maximum Level Sum of a Binary Tree",
    difficulty: "Medium",
    topics: ["Tree", "Depth-First Search", "Breadth-First Search", "Binary Tree"],
    companies: ["meta", "amazon", "google"],
    freq: 83.0,
    statement: `Given the \`root\` of a binary tree, the level of its root is \`1\`, the level of its children is \`2\`, and so on.

Return the smallest level \`x\` such that the sum of all the values of nodes at level \`x\` is maximal.

\u00a0

Example 1:

\`\`\`
Input: root = [1,7,0,7,-8,null,null]
Output: 2
Explanation: 
Level 1 sum = 1.
Level 2 sum = 7 + 0 = 7.
Level 3 sum = 7 + -8 = -1.
So we return the level with the maximum sum which is level 2.
\`\`\`

Example 2:

\`\`\`
Input: root = [989,null,10250,98603,-89308,null,null,null,-32127]
Output: 2
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [1, 104].
\t- -105 <= Node.val <= 105`,
  },

  // 60. Leaf-Similar Trees
  {
    slug: "leaf-similar-trees",
    title: "Leaf-Similar Trees",
    difficulty: "Easy",
    topics: ["Tree", "Depth-First Search", "Binary Tree"],
    companies: ["meta", "google", "amazon"],
    freq: 82.0,
    statement: `Consider all the leaves of a binary tree, from left to right order, the values of those leaves form a leaf value sequence.

For example, in the given tree above, the leaf value sequence is \`(6, 7, 4, 9, 8)\`.

Two binary trees are considered leaf-similar if their leaf value sequence is the same.

Return \`true\` if and only if the two given trees with head nodes \`root1\` and \`root2\` are leaf-similar.

\u00a0

Example 1:

\`\`\`
Input: root1 = [3,5,1,6,2,9,8,null,null,7,4], root2 = [3,5,1,6,7,4,2,null,null,null,null,null,null,9,8]
Output: true
\`\`\`

Example 2:

\`\`\`
Input: root1 = [1,2,3], root2 = [1,3,2]
Output: false
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in each tree will be in the range [1, 200].
\t- Both of the given trees will have values in the range [0, 200].`,
  },

  // 61. Pseudo-Palindromic Paths in a Binary Tree
  {
    slug: "pseudo-palindromic-paths-in-a-binary-tree",
    title: "Pseudo-Palindromic Paths in a Binary Tree",
    difficulty: "Medium",
    topics: [
      "Bit Manipulation",
      "Tree",
      "Depth-First Search",
      "Breadth-First Search",
      "Binary Tree",
    ],
    companies: ["amazon", "microsoft"],
    freq: 84.0,
    statement: `Given a binary tree where node values are digits from 1 to 9. A path in the binary tree is said to be pseudo-palindromic if at least one permutation of the node values in the path is a palindrome.

Return the number of pseudo-palindromic paths starting from the root node to leaf nodes.

\u00a0

Example 1:

\`\`\`
Input: root = [2,3,1,3,1,null,1]
Output: 2 
Explanation: There are three paths from root to leaf: [2,3,3], [2,1,1], and [2,3,1]. Among these paths only the first two paths are pseudo-palindromic because [2,3,3] can be arranged in [3,2,3] (palindrome) and [2,1,1] can be arranged in [1,2,1] (palindrome).
\`\`\`

Example 2:

\`\`\`
Input: root = [2,1,1,1,3,null,null,null,null,null,1]
Output: 1 
Explanation: There are three paths from root to leaf: [2,1,1], [2,1,3,1], and [2,1]. Among these paths only [2,1,1] is pseudo-palindromic since [2,1,1] can be arranged in [1,2,1] (palindrome).
\`\`\`

Example 3:

\`\`\`
Input: root = [9]
Output: 1
\`\`\`

\u00a0

Constraints:

\t- The number of nodes in the tree is in the range [1, 105].
\t- 1 <= Node.val <= 9`,
  },

  // 62. Hand of Straights
  {
    slug: "hand-of-straights",
    title: "Hand of Straights",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "Greedy", "Sorting"],
    companies: ["google", "amazon"],
    freq: 87.0,
    statement: `Alice has some number of cards and she wants to rearrange the cards into groups so that each group is of size \`groupSize\`, and consists of \`groupSize\` consecutive cards.

Given an integer array \`hand\` where \`hand[i]\` is the value written on the \`i\`th card and an integer \`groupSize\`, return \`true\` if she can rearrange the cards, or \`false\` otherwise.

\u00a0

Example 1:

\`\`\`
Input: hand = [1,2,3,6,2,3,4,7,8], groupSize = 3
Output: true
Explanation: Alice's hand can be rearranged as [1,2,3],[2,3,4],[6,7,8]
\`\`\`

Example 2:

\`\`\`
Input: hand = [1,2,3,4,5], groupSize = 4
Output: false
Explanation: Alice's hand can not be rearranged into groups of 4.
\`\`\`

\u00a0

Constraints:

\t- 1 <= hand.length <= 104
\t- 0 <= hand[i] <= 109
\t- 1 <= groupSize <= hand.length`,
  },

  // 63. Lemonade Change
  {
    slug: "lemonade-change",
    title: "Lemonade Change",
    difficulty: "Easy",
    topics: ["Array", "Greedy"],
    companies: ["amazon", "meta"],
    freq: 85.0,
    statement: `At a lemonade stand, each lemonade costs \`$5\`. Customers are standing in a queue to buy from you and order one at a time (in the order specified by \`bills\`). Each customer will only buy one lemonade and pay with either a \`$5\`, \`$10\`, or \`$20\` bill. You must provide the correct change to each customer so that the net transaction is that the customer pays \`$5\`.

Note that you do not have any change in hand at first.

Given an integer array \`bills\` where \`bills[i]\` is the bill the \`i\`th customer pays, return \`true\` if you can provide every customer with the correct change, or \`false\` otherwise.

\u00a0

Example 1:

\`\`\`
Input: bills = [5,5,5,10,20]
Output: true
Explanation: 
From the first 3 customers, we collect three $5 bills in order.
From the fourth customer, we collect a $10 bill and give back a $5.
From the fifth customer, we give a $10 bill and a $5 bill.
Since all customers got correct change, we output true.
\`\`\`

Example 2:

\`\`\`
Input: bills = [5,5,10,10,20]
Output: false
Explanation: 
From the first two customers in order, we collect two $5 bills.
For the next two customers in order, we collect a $10 bill and give back a $5 bill.
For the last customer, we can not give the change of $15 back because we only have two $10 bills.
Since not every customer received the correct change, the answer is false.
\`\`\`

\u00a0

Constraints:

\t- 1 <= bills.length <= 105
\t- bills[i] is either 5, 10, or 20.`,
  },

  // 64. Minimum Number of Arrows to Burst Balloons
  {
    slug: "minimum-number-of-arrows-to-burst-balloons",
    title: "Minimum Number of Arrows to Burst Balloons",
    difficulty: "Medium",
    topics: ["Array", "Greedy", "Sorting"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 89.0,
    statement: `There are some spherical balloons taped onto a flat wall that represents the XY-plane. The balloons are represented as a 2D integer array \`points\` where \`points[i] = [xstart, xend]\` denotes a balloon whose horizontal diameter stretches between \`xstart\` and \`xend\`. You do not know the exact y-coordinates of the balloons.

Arrows can be shot up directly vertically (in the positive y-direction) from different points along the x-axis. A balloon with \`xstart\` and \`xend\` is burst by an arrow shot at \`x\` if \`xstart <= x <= xend\`. There is no limit to the number of arrows that can be shot. A shot arrow keeps traveling up infinitely, bursting any balloons in its path.

Given the array \`points\`, return the minimum number of arrows that must be shot to burst all balloons.

\u00a0

Example 1:

\`\`\`
Input: points = [[10,16],[2,8],[1,6],[7,12]]
Output: 2
Explanation: The balloons can be burst by 2 arrows:
- Shoot an arrow at x = 6, bursting the balloons [2,8] and [1,6].
- Shoot an arrow at x = 11, bursting the balloons [10,16] and [7,12].
\`\`\`

Example 2:

\`\`\`
Input: points = [[1,2],[3,4],[5,6],[7,8]]
Output: 4
Explanation: One arrow needs to be shot for each balloon for a total of 4 arrows.
\`\`\`

Example 3:

\`\`\`
Input: points = [[1,2],[2,3],[3,4],[4,5]]
Output: 2
Explanation: The balloons can be burst by 2 arrows:
- Shoot an arrow at x = 2, bursting the balloons [1,2] and [2,3].
- Shoot an arrow at x = 4, bursting the balloons [3,4] and [4,5].
\`\`\`

\u00a0

Constraints:

\t- 1 <= points.length <= 105
\t- points[i].length == 2
\t- -231 <= xstart < xend <= 231 - 1`,
  },

  // 65. Interval List Intersections
  {
    slug: "interval-list-intersections",
    title: "Interval List Intersections",
    difficulty: "Medium",
    topics: ["Array", "Two Pointers"],
    companies: ["meta", "uber", "amazon", "google"],
    freq: 88.0,
    statement: `You are given two lists of closed intervals, \`firstList\` and \`secondList\`, where \`firstList[i] = [starti, endi]\` and \`secondList[j] = [startj, endj]\`. Each list of intervals is pairwise disjoint and in sorted order.

Return the intersection of these two interval lists.

A closed interval \`[a, b]\` (with \`a <= b\`) denotes the set of real numbers \`x\` with \`a <= x <= b\`.

The intersection of two closed intervals is a set of real numbers that are either empty or represented as a closed interval. For example, the intersection of \`[1, 3]\` and \`[2, 4]\` is \`[2, 3]\`.

\u00a0

Example 1:

\`\`\`
Input: firstList = [[0,2],[5,10],[13,23],[24,25]], secondList = [[1,5],[8,12],[15,24],[25,26]]
Output: [[1,2],[5,5],[8,10],[15,23],[24,24],[25,25]]
\`\`\`

Example 2:

\`\`\`
Input: firstList = [[1,3],[5,9]], secondList = []
Output: []
\`\`\`

\u00a0

Constraints:

\t- 0 <= firstList.length, secondList.length <= 1000
\t- firstList.length + secondList.length >= 1
\t- 0 <= starti < endi <= 109
\t- endi < starti+1
\t- 0 <= startj < endj <= 109
\t- endj < startj+1`,
  },

  // 66. Car Pooling
  {
    slug: "car-pooling",
    title: "Car Pooling",
    difficulty: "Medium",
    topics: ["Array", "Sorting", "Heap (Priority Queue)", "Simulation", "Prefix Sum"],
    companies: ["amazon", "google", "meta"],
    freq: 85.0,
    statement: `There is a car with \`capacity\` empty seats. The vehicle only drives east (i.e. it cannot turn around and drive west).

You are given the integer \`capacity\` and an array \`trips\` where \`trips[i] = [numPassengersi, fromi, toi]\` indicates that the \`i\`th trip has \`numPassengersi\` passengers and the locations to pick them up and drop them off are \`fromi\` and \`toi\` respectively. The locations are given as the number of kilometers due east from the car's initial location.

Return \`true\` if it is possible to pick up and drop off all passengers for all the given trips, or \`false\` otherwise.

\u00a0

Example 1:

\`\`\`
Input: trips = [[2,1,5],[3,3,7]], capacity = 4
Output: false
\`\`\`

Example 2:

\`\`\`
Input: trips = [[2,1,5],[3,3,7]], capacity = 5
Output: true
\`\`\`

\u00a0

Constraints:

\t- 1 <= trips.length <= 1000
\t- trips[i].length == 3
\t- 1 <= numPassengersi <= 100
\t- 0 <= fromi < toi <= 1000
\t- 1 <= capacity <= 105`,
  },

  // 67. Maximum Average Pass Ratio
  {
    slug: "maximum-average-pass-ratio",
    title: "Maximum Average Pass Ratio",
    difficulty: "Medium",
    topics: ["Array", "Greedy", "Heap (Priority Queue)"],
    companies: ["amazon", "bloomberg"],
    freq: 81.0,
    statement: `There is a school that has classes of students and each class will be having a final exam. You are given a 2D integer array \`classes\`, where \`classes[i] = [passi, totali]\`. You know beforehand that in the \`i\`th class, there are \`totali\` total students, but only \`passi\` number of students will pass the exam.

You are also given an integer \`extraStudents\`. You have another \`extraStudents\` brilliant students that are guaranteed to pass the exam of any class they are assigned to. You want to assign each of the \`extraStudents\` students to a class in a way that maximizes the average pass ratio across all the classes.

The pass ratio of a class is equal to the number of students of the class that will pass the exam divided by the total number of students of the class. The average pass ratio is the sum of pass ratios of all the classes divided by the number of the classes.

Return the maximum possible average pass ratio after assigning the \`extraStudents\` students. Answers within \`10^-5\` of the actual answer will be accepted.

\u00a0

Example 1:

\`\`\`
Input: classes = [[1,2],[3,5],[2,2]], extraStudents = 2
Output: 0.78333
Explanation: You can assign the two extra students to the first class. The average pass ratio will be equal to (3/4 + 3/5 + 2/2) / 3 = 0.78333.
\`\`\`

Example 2:

\`\`\`
Input: classes = [[2,4],[3,9],[4,5],[2,10]], extraStudents = 4
Output: 0.53485
\`\`\`

\u00a0

Constraints:

\t- 1 <= classes.length <= 105
\t- classes[i].length == 2
\t- 1 <= passi <= totali <= 105
\t- 1 <= extraStudents <= 105`,
  },

  // 68. Matchsticks to Square
  {
    slug: "matchsticks-to-square",
    title: "Matchsticks to Square",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Backtracking", "Bitmask"],
    companies: ["amazon", "google"],
    freq: 82.0,
    statement: `You are given an integer array \`matchsticks\` where \`matchsticks[i]\` is the length of the \`i\`th matchstick. You want to use all the matchsticks to make one square. You should not break any stick, but you can link them up, and each matchstick must be used exactly one time.

Return \`true\` if you can make this square and \`false\` otherwise.

\u00a0

Example 1:

\`\`\`
Input: matchsticks = [1,1,2,2,2]
Output: true
Explanation: You can form a square with length 2, one side of the square came two sticks with length 1.
\`\`\`

Example 2:

\`\`\`
Input: matchsticks = [3,3,3,3,4]
Output: false
Explanation: You cannot find a way to form a square with all the matchsticks.
\`\`\`

\u00a0

Constraints:

\t- 1 <= matchsticks.length <= 15
\t- 1 <= matchsticks[i] <= 108`,
  },

  // 69. Maximum Score Words Formed by Letters
  {
    slug: "maximum-score-words-formed-by-letters",
    title: "Maximum Score Words Formed by Letters",
    difficulty: "Hard",
    topics: ["Array", "String", "Dynamic Programming", "Backtracking", "Bitmask"],
    companies: ["google", "amazon"],
    freq: 81.0,
    statement: `Given a list of \`words\`, list of  single \`letters\` (might be repeating) and \`score\` of every character.

Return the maximum score of any valid set of words formed by using the given letters (\`words[i]\` cannot be used two or more times).

It is not necessary to use all characters in \`letters\` and each letter can only be used once. Score of letters \`'a'\`, \`'b'\`, \`'c'\`, ... ,\`'z'\` is given by \`score[0]\`, \`score[1]\`, ... , \`score[25]\` respectively.

\u00a0

Example 1:

\`\`\`
Input: words = ["dog","cat","dad","good"], letters = ["a","a","c","d","d","d","g","o","o"], score = [1,0,9,5,0,0,3,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0]
Output: 23
Explanation:
Score  a=1, c=9, d=5, g=3, o=2
Given letters, we can form the words "dad" (5+1+5) and "good" (3+2+2+5) with a score of 23.
Words "dad" and "dog" only get a score of 21.
\`\`\`

Example 2:

\`\`\`
Input: words = ["xxxz","ax","bx","cx"], letters = ["z","a","b","c","x","x","x"], score = [4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,10]
Output: 27
Explanation:
Score  a=4, b=4, c=4, x=5, z=10
Given letters, we can form the words "ax" (4+5), "bx" (4+5) and "cx" (4+5) with a score of 27.
Word "xxxz" only get a score of 25.
\`\`\`

Example 3:

\`\`\`
Input: words = ["leetcode"], letters = ["l","e","t","c","o","d"], score = [0,0,1,1,1,0,0,0,0,0,0,1,0,0,1,0,0,0,0,1,0,0,0,0,0,0]
Output: 0
Explanation:
Letter "e" can only be used once.
\`\`\`

\u00a0

Constraints:

\t- 1 <= words.length <= 14
\t- 1 <= words[i].length <= 15
\t- 1 <= letters.length <= 100
\t- letters[i].length == 1
\t- score.length == 26
\t- 0 <= score[i] <= 10
\t- words[i], letters[i] contains only lower case English letters.`,
  },

  // 70. Path with Minimum Effort
  {
    slug: "path-with-minimum-effort",
    title: "Path With Minimum Effort",
    difficulty: "Medium",
    topics: [
      "Array",
      "Binary Search",
      "Depth-First Search",
      "Breadth-First Search",
      "Union Find",
      "Heap (Priority Queue)",
      "Matrix",
    ],
    companies: ["google", "amazon", "microsoft"],
    freq: 90.0,
    statement: `You are a hiker preparing for an upcoming hike. You are given \`heights\`, a 2D array of size \`rows x columns\`, where \`heights[row][col]\` represents the height of cell \`(row, col)\`. You are situated in the top-left cell, \`(0, 0)\`, and you hope to travel to the bottom-right cell, \`(rows-1, columns-1)\` (i.e., 0-indexed). You can move up, down, left, or right, and you wish to find a route that requires the minimum effort.

A route's effort is the maximum absolute difference in heights between two consecutive cells of the route.

Return the minimum effort required to travel from the top-left cell to the bottom-right cell.

\u00a0

Example 1:

\`\`\`
Input: heights = [[1,2,2],[3,8,2],[5,3,5]]
Output: 2
Explanation: The route of [1,3,5,3,5] has a maximum absolute difference of 2 in consecutive cells.
This is better than the route of [1,2,2,2,5], which has a maximum absolute difference of 3.
\`\`\`

Example 2:

\`\`\`
Input: heights = [[1,2,3],[3,8,4],[5,3,5]]
Output: 1
Explanation: The route of [1,2,3,4,5] has a maximum absolute difference of 1 in consecutive cells, which is better than route [1,3,5,3,5].
\`\`\`

Example 3:

\`\`\`
Input: heights = [[1,2,1,1,1],[1,2,1,2,1],[1,2,1,2,1],[1,2,1,2,1],[1,1,1,2,1]]
Output: 0
Explanation: This route does not require any effort.
\`\`\`

\u00a0

Constraints:

\t- rows == heights.length
\t- columns == heights[i].length
\t- 1 <= rows, columns <= 100
\t- 1 <= heights[i][j] <= 106`,
  },

  // 71. Find Eventual Safe States
  {
    slug: "find-eventual-safe-states",
    title: "Find Eventual Safe States",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Graph", "Topological Sort"],
    companies: ["amazon", "google"],
    freq: 85.0,
    statement: `There is a directed graph of \`n\` nodes with each node labeled from \`0\` to \`n - 1\`. The graph is represented by a 0-indexed 2D integer array \`graph\` where \`graph[i]\` is an integer array of nodes adjacent to node \`i\`, meaning there is an edge from node \`i\` to each node in \`graph[i]\`.

A node is a terminal node if there are no outgoing edges. A node is a safe node if every possible path starting from that node leads to a terminal node (or another safe node).

Return an array containing all the safe nodes of the graph. The answer should be sorted in ascending order.

\u00a0

Example 1:

\`\`\`
Input: graph = [[1,2],[2,3],[5],[0],[5],[],[]]
Output: [2,4,5,6]
Explanation: The given graph is shown above.
Nodes 5 and 6 are terminal nodes as there are no outgoing edges from either of them.
Every path starting at nodes 2, 4, 5, and 6 all lead to either node 5 or 6.
\`\`\`

Example 2:

\`\`\`
Input: graph = [[1,2,3,4],[1,2],[3,4],[0,4],[]]
Output: [4]
Explanation:
Only node 4 is a terminal node, and every path starting at node 4 leads to node 4.
\`\`\`

\u00a0

Constraints:

\t- n == graph.length
\t- 1 <= n <= 104
\t- 0 <= graph[i].length <= n
\t- 0 <= graph[i][j] <= n - 1
\t- graph[i] is sorted in a strictly increasing order.
\t- The graph may contain self-loops.
\t- The number of edges in the graph will be in the range [1, 4 * 104].`,
  },

  // 72. Number of Ways to Arrive at Destination
  {
    slug: "number-of-ways-to-arrive-at-destination",
    title: "Number of Ways to Arrive at Destination",
    difficulty: "Medium",
    topics: ["Dynamic Programming", "Graph", "Topological Sort", "Shortest Path"],
    companies: ["amazon", "google"],
    freq: 86.0,
    statement: `You are in a city that consists of \`n\` intersections numbered from \`0\` to \`n - 1\` with bi-directional roads between some intersections. The inputs are generated such that you can reach any intersection from any other intersection and that there is at most one road between any two intersections.

You are given an integer \`n\` and a 2D integer array \`roads\` where \`roads[i] = [ui, vi, timei]\` means that there is a road between intersections \`ui\` and \`vi\` that takes \`timei\` minutes to travel. You want to know in how many ways you can travel from intersection \`0\` to intersection \`n - 1\` in the shortest amount of time.

Return the number of ways you can arrive at your destination in the shortest amount of time. Since the answer may be large, return it modulo \`109 + 7\`.

\u00a0

Example 1:

\`\`\`
Input: n = 7, roads = [[0,6,7],[0,1,2],[1,2,3],[1,3,3],[6,3,3],[3,5,1],[6,5,1],[2,5,1],[0,4,5],[4,6,2]]
Output: 4
Explanation: The shortest amount of time it takes to go from intersection 0 to intersection 6 is 7 minutes.
The four ways to get there in 7 minutes are:
- 0 -> 6
- 0 -> 4 -> 6
- 0 -> 1 -> 2 -> 5 -> 6
- 0 -> 1 -> 3 -> 5 -> 6
\`\`\`

Example 2:

\`\`\`
Input: n = 2, roads = [[1,0,10]]
Output: 1
Explanation: There is only one way to go from intersection 0 to intersection 1, and it takes 10 minutes.
\`\`\`

\u00a0

Constraints:

\t- 1 <= n <= 200
\t- n - 1 <= roads.length <= n * (n - 1) / 2
\t- roads[i].length == 3
\t- 0 <= ui, vi <= n - 1
\t- 1 <= timei <= 109
\t- ui != vi
\t- There is at most one road connecting any two intersections.
\t- You can reach any intersection from any other intersection.`,
  },

  // 73. Number of Operations to Make Network Connected
  {
    slug: "number-of-operations-to-make-network-connected",
    title: "Number of Operations to Make Network Connected",
    difficulty: "Medium",
    topics: ["Depth-First Search", "Breadth-First Search", "Union Find", "Graph"],
    companies: ["amazon", "google", "microsoft"],
    freq: 85.0,
    statement: `There are \`n\` computers numbered from \`0\` to \`n - 1\` connected by ethernet cables \`connections\` forming a network where \`connections[i] = [ai, bi]\` represents a connection between computers \`ai\` and \`bi\`. Any computer can reach any other computer directly or indirectly through the network.

You are given an initial computer network connections. You can extract certain cables between two directly connected computers, and place them between any pair of disconnected computers to make them directly connected.

Return the minimum number of times you need to do this in order to make all the computers connected. If it is not possible, return \`-1\`.

\u00a0

Example 1:

\`\`\`
Input: n = 4, connections = [[0,1],[0,2],[1,2]]
Output: 1
Explanation: Remove cable between computer 1 and 2 and place between computers 1 and 3.
\`\`\`

Example 2:

\`\`\`
Input: n = 6, connections = [[0,1],[0,2],[0,3],[1,2],[1,3]]
Output: 2
\`\`\`

Example 3:

\`\`\`
Input: n = 6, connections = [[0,1],[0,2],[0,3],[1,2]]
Output: -1
Explanation: There are not enough cables.
\`\`\`

\u00a0

Constraints:

\t- 1 <= n <= 105
\t- 1 <= connections.length <= min(n * (n - 1) / 2, 105)
\t- connections[i].length == 2
\t- 0 <= ai, bi < n
\t- ai != bi
\t- There are no repeated connections.
\t- No two computers are connected by more than one cable.`,
  },

  // 74. Critical Connections in a Network
  {
    slug: "critical-connections-in-a-network",
    title: "Critical Connections in a Network",
    difficulty: "Hard",
    topics: ["Depth-First Search", "Graph", "Biconnected Component"],
    companies: ["amazon", "meta", "google"],
    freq: 91.0,
    statement: `There are \`n\` servers numbered from \`0\` to \`n - 1\` connected by undirected server-to-server \`connections\` forming a network where \`connections[i] = [ai, bi]\` represents a connection between servers \`ai\` and \`bi\`. Any server can reach other servers directly or indirectly through the network.

A critical connection is a connection that, if removed, will make some servers unable to reach some other server.

Return all critical connections in the network in any order.

\u00a0

Example 1:

\`\`\`
Input: n = 4, connections = [[0,1],[1,2],[2,0],[1,3]]
Output: [[1,3]]
Explanation: [[3,1]] is also accepted.
\`\`\`

Example 2:

\`\`\`
Input: n = 2, connections = [[0,1]]
Output: [[0,1]]
\`\`\`

\u00a0

Constraints:

\t- 2 <= n <= 105
\t- n - 1 <= connections.length <= 105
\t- 0 <= ai, bi <= n - 1
\t- ai != bi
\t- There are no repeated connections.`,
  },

  // 75. Number of Enclaves
  {
    slug: "number-of-enclaves",
    title: "Number of Enclaves",
    difficulty: "Medium",
    topics: ["Array", "Depth-First Search", "Breadth-First Search", "Union Find", "Matrix"],
    companies: ["google", "amazon"],
    freq: 86.0,
    statement: `You are given an \`m x n\` binary matrix \`grid\`, where \`0\` represents a sea cell and \`1\` represents a land cell.

A move consists of walking from one land cell to another adjacent (4-directionally) land cell or walking off the boundary of the \`grid\`.

Return the number of land cells in \`grid\` for which we cannot walk off the boundary of the grid in any number of moves.

\u00a0

Example 1:

\`\`\`
Input: grid = [[0,0,0,0],[1,0,1,0],[0,1,1,0],[0,0,0,0]]
Output: 3
Explanation: There are three 1s that are enclosed by 0s, and one 1 that is on the boundary and can walk off the grid.
\`\`\`

Example 2:

\`\`\`
Input: grid = [[0,1,1,0],[0,0,1,0],[0,0,1,0],[0,0,0,0]]
Output: 0
Explanation: All 1s are either on the boundary or can reach the boundary.
\`\`\`

\u00a0

Constraints:

\t- m == grid.length
\t- n == grid[i].length
\t- 1 <= m, n <= 500
\t- grid[i][j] is either 0 or 1.`,
  },
];
