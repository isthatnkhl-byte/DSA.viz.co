module.exports = [
  // 76. Find the City With the Smallest Number of Neighbors at a Threshold Distance
  {
    slug: "find-the-city-with-the-smallest-number-of-neighbors-at-a-threshold-distance",
    title: "Find the City With the Smallest Number of Neighbors at a Threshold Distance",
    difficulty: "Medium",
    topics: ["Dynamic Programming", "Graph", "Shortest Path"],
    companies: ["amazon", "google"],
    freq: 85.0,
    statement: `There are \`n\` cities numbered from \`0\` to \`n-1\`. Given the array \`edges\` where \`edges[i] = [fromi, toi, weighti]\` represents a bidirectional and weighted edge between cities \`fromi\` and \`toi\`, and given the integer \`distanceThreshold\`.

Return the city with the smallest number of cities that are reachable through some path and whose distance is at most \`distanceThreshold\`, If there are multiple such cities, return the city with the greatest number.

Notice that the distance of a path connecting cities \`i\` and \`j\` is equal to the sum of the edges' weights along that path.

\u00a0

Example 1:

\`\`\`
Input: n = 4, edges = [[0,1,3],[1,2,1],[1,3,4],[2,3,1]], distanceThreshold = 4
Output: 3
Explanation: The neighboring cities at a distanceThreshold = 4 for each city are:
City 0 -> [City 1, City 2] 
City 1 -> [City 0, City 2, City 3] 
City 2 -> [City 0, City 1, City 3] 
City 3 -> [City 1, City 2] 
Cities 0 and 3 have 2 neighboring cities at a distanceThreshold = 4, but we have to return city 3 since it has the greatest number.
\`\`\`

Example 2:

\`\`\`
Input: n = 5, edges = [[0,1,2],[0,4,8],[1,2,3],[1,4,2],[2,3,1],[3,4,1]], distanceThreshold = 2
Output: 0
\`\`\`

\u00a0

Constraints:

\t- 2 <= n <= 100
\t- 1 <= edges.length <= n * (n - 1) / 2
\t- edges[i].length == 3
\t- 0 <= fromi < toi < n
\t- 1 <= weighti, distanceThreshold <= 10^4
\t- All pairs (fromi, toi) are distinct.`,
  },

  // 77. Find All Groups of Farmland
  {
    slug: "find-all-groups-of-farmland",
    title: "Find All Groups of Farmland",
    difficulty: "Medium",
    topics: ["Array", "Depth-First Search", "Breadth-First Search", "Matrix"],
    companies: ["amazon", "microsoft"],
    freq: 80.0,
    statement: `You are given a 0-indexed \`m x n\` binary matrix \`land\` where a \`0\` represents a hectare of forested land and a \`1\` represents a hectare of farmland.

To keep the land organized, there are designated rectangular areas of hectares that consist entirely of farmland. These farmland areas are called groups. No two groups are adjacent, meaning farmland in one group is not four-directionally adjacent to another farmland in a different group.

\`land\` can be represented by a coordinate system where the top left corner of \`land\` is \`(0, 0)\` and the bottom right corner of \`land\` is \`(m-1, n-1)\`. Find the coordinates of the top left and bottom right corner of each group of farmland. A group of farmland with a top left corner at \`(r1, c1)\` and a bottom right corner at \`(r2, c2)\` is represented by the 4-length array \`[r1, c1, r2, c2]\`.

Return a 2D array containing the 4-length arrays described above for each group of farmland in \`land\`. You may return the answer in any order.

\u00a0

Example 1:

\`\`\`
Input: land = [[1,0,0],[0,1,1],[0,1,1]]
Output: [[0,0,0,0],[1,1,2,2]]
Explanation:
The first group has a top left corner at land[0][0] and a bottom right corner at land[0][0].
The second group has a top left corner at land[1][1] and a bottom right corner at land[2][2].
\`\`\`

Example 2:

\`\`\`
Input: land = [[1,1],[1,1]]
Output: [[0,0,1,1]]
\`\`\`

Example 3:

\`\`\`
Input: land = [[0]]
Output: []
\`\`\`

\u00a0

Constraints:

\t- m == land.length
\t- n == land[i].length
\t- 1 <= m, n <= 300
\t- land consists of only 0's and 1's.
\t- Groups of farmland are rectangular in shape.`,
  },

  // 78. Count Sub Islands
  {
    slug: "count-sub-islands",
    title: "Count Sub Islands",
    difficulty: "Medium",
    topics: ["Array", "Depth-First Search", "Breadth-First Search", "Union Find", "Matrix"],
    companies: ["amazon", "google"],
    freq: 84.0,
    statement: `You are given two \`m x n\` binary matrices \`grid1\` and \`grid2\` containing only \`0\`s (representing water) and \`1\`s (representing land). An island is a group of \`1\`s connected 4-directionally (horizontal or vertical). Any cells outside of the grid are considered water cells.

An island in \`grid2\` is considered a sub-island if there is an island in \`grid1\` that contains all the cells that make up this island in \`grid2\`.

Return the number of islands in \`grid2\` that are considered sub-islands.

\u00a0

Example 1:

\`\`\`
Input: grid1 = [[1,1,1,0,0],[0,1,1,1,1],[0,0,0,0,0],[1,0,0,0,0],[1,1,0,1,1]], grid2 = [[1,1,1,0,0],[0,0,1,1,1],[0,1,0,0,0],[1,0,1,1,0],[0,1,0,1,0]]
Output: 3
Explanation: The 1s in grid2 that form sub-islands are contained within the islands of grid1.
\`\`\`

Example 2:

\`\`\`
Input: grid1 = [[1,0,1,0,1],[1,1,1,1,1],[0,0,0,0,0],[1,1,1,1,1],[1,0,1,0,1]], grid2 = [[0,0,0,0,0],[1,1,1,1,1],[0,1,0,1,0],[0,1,0,1,0],[1,0,0,0,1]]
Output: 2
\`\`\`

\u00a0

Constraints:

\t- m == grid1.length == grid2.length
\t- n == grid1[i].length == grid2[i].length
\t- 1 <= m, n <= 500
\t- grid1[i][j] and grid2[i][j] are either 0 or 1.`,
  },

  // 79. Triangle
  {
    slug: "triangle",
    title: "Triangle",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "bloomberg", "google", "apple"],
    freq: 87.0,
    statement: `Given a \`triangle\` array, return the minimum path sum from top to bottom.

For each step, you may move to an adjacent number of the row below. More formally, if you are on index \`i\` on the current row, you may move to either index \`i\` or index \`i + 1\` on the next row.

\u00a0

Example 1:

\`\`\`
Input: triangle = [[2],[3,4],[6,5,7],[4,1,8,3]]
Output: 11
Explanation: The triangle looks like:
   2
  3 4
 6 5 7
4 1 8 3
The minimum path sum from top to bottom is 2 + 3 + 5 + 1 = 11 (underlined above).
\`\`\`

Example 2:

\`\`\`
Input: triangle = [[-10]]
Output: -10
\`\`\`

\u00a0

Constraints:

\t- 1 <= triangle.length <= 200
\t- triangle[0].length == 1
\t- triangle[i].length == triangle[i - 1].length + 1
\t- -104 <= triangle[i][j] <= 104

\u00a0

Follow up: Could you do this using only O(n) extra space, where n is the total number of rows in the triangle?`,
  },

  // 80. Cherry Pickup II
  {
    slug: "cherry-pickup-ii",
    title: "Cherry Pickup II",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming", "Matrix"],
    companies: ["google", "amazon"],
    freq: 85.0,
    statement: `You are given a \`rows x cols\` matrix \`grid\` representing a field of cherries where \`grid[i][j]\` represents the number of cherries that you can collect from the \`(i, j)\` cell.

You have two robots that can collect cherries for you:
\t- Robot #1 is located at the top-left corner \`(0, 0)\`, and
\t- Robot #2 is located at the top-right corner \`(0, cols - 1)\`.

Return the maximum number of cherries collection using both robots by following the rules below:
\t- From a cell \`(i, j)\`, robots can move to cell \`(i + 1, j - 1)\`, \`(i + 1, j)\`, or \`(i + 1, j + 1)\`.
\t- When any robot passes through a cell, It picks up all cherries, and the cell becomes an empty cell \`0\`.
\t- When both robots stay in the same cell in the same step, only one takes the cherries.
\t- Both robots cannot move outside of the grid at any moment.
\t- Both robots should reach the bottom row in \`grid\`.

\u00a0

Example 1:

\`\`\`
Input: grid = [[3,1,1],[2,5,1],[1,5,5],[2,1,1]]
Output: 24
Explanation: Path of robot #1 and #2 are described in color green and blue respectively.
Cherries taken by Robot #1, (3 + 2 + 5 + 2) = 12.
Cherries taken by Robot #2, (1 + 5 + 5 + 1) = 12.
Total of cherries: 12 + 12 = 24.
\`\`\`

Example 2:

\`\`\`
Input: grid = [[1,0,0,0,0,0,1],[2,0,0,0,0,3,0],[2,0,9,0,0,0,0],[0,3,0,5,4,0,0],[1,0,2,3,0,0,6]]
Output: 28
\`\`\`

\u00a0

Constraints:

\t- rows == grid.length
\t- cols == grid[i].length
\t- 2 <= rows, cols <= 70
\t- 0 <= grid[i][j] <= 100`,
  },

  // 81. Longest Palindromic Subsequence
  {
    slug: "longest-palindromic-subsequence",
    title: "Longest Palindromic Subsequence",
    difficulty: "Medium",
    topics: ["String", "Dynamic Programming"],
    companies: ["amazon", "meta", "google", "microsoft"],
    freq: 90.0,
    statement: `Given a string \`s\`, find the longest palindromic subsequence's length in \`s\`.

A subsequence is a sequence that can be derived from another sequence by deleting some or no elements without changing the order of the remaining elements.

\u00a0

Example 1:

\`\`\`
Input: s = "bbbab"
Output: 4
Explanation: One possible longest palindromic subsequence is "bbbb".
\`\`\`

Example 2:

\`\`\`
Input: s = "cbbd"
Output: 2
Explanation: One possible longest palindromic subsequence is "bb".
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 1000
\t- s consists only of lowercase English letters.`,
  },

  // 82. Minimum Insertions to Make String Palindrome
  {
    slug: "minimum-insertions-to-make-string-palindrome",
    title: "Minimum Insertion Steps to Make a String Palindrome",
    difficulty: "Hard",
    topics: ["String", "Dynamic Programming"],
    companies: ["amazon", "google", "meta"],
    freq: 86.0,
    statement: `Given a string \`s\`. In one step you can insert any character at any index of the string.

Return the minimum number of steps to make \`s\` palindrome.

A Palindrome String is one that reads the same backward as well as forward.

\u00a0

Example 1:

\`\`\`
Input: s = "zzazz"
Output: 0
Explanation: The string "zzazz" is already palindrome we do not need any insertions.
\`\`\`

Example 2:

\`\`\`
Input: s = "mbadm"
Output: 2
Explanation: String can be "mbdadbm" or "mdbabdm".
\`\`\`

Example 3:

\`\`\`
Input: s = "leetcode"
Output: 5
Explanation: Inserting 5 characters the string becomes "leetcodocteel".
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 500
\t- s consists of lowercase English letters.`,
  },

  // 83. Delete Operation for Two Strings
  {
    slug: "delete-operation-for-two-strings",
    title: "Delete Operation for Two Strings",
    difficulty: "Medium",
    topics: ["String", "Dynamic Programming"],
    companies: ["amazon", "google", "microsoft"],
    freq: 83.0,
    statement: `Given two strings \`word1\` and \`word2\`, return the minimum number of steps required to make \`word1\` and \`word2\` the same.

In one step, you can delete exactly one character in either string.

\u00a0

Example 1:

\`\`\`
Input: word1 = "sea", word2 = "eat"
Output: 2
Explanation: You need one step to make "sea" to "ea" and another step to make "eat" to "ea".
\`\`\`

Example 2:

\`\`\`
Input: word1 = "leetcode", word2 = "etco"
Output: 4
\`\`\`

\u00a0

Constraints:

\t- 1 <= word1.length, word2.length <= 500
\t- word1 and word2 consist of only lowercase English letters.`,
  },

  // 84. Shortest Common Supersequence
  {
    slug: "shortest-common-supersequence",
    title: "Shortest Common Supersequence",
    difficulty: "Hard",
    topics: ["String", "Dynamic Programming"],
    companies: ["google", "microsoft", "amazon"],
    freq: 85.0,
    statement: `Given two strings \`str1\` and \`str2\`, return the shortest string that has both \`str1\` and \`str2\` as subsequences. If there are multiple valid strings, return any of them.

A string \`s\` is a subsequence of string \`t\` if deleting some number of characters from \`t\` (possibly 0) results in the string \`s\`.

\u00a0

Example 1:

\`\`\`
Input: str1 = "abac", str2 = "cab"
Output: "cabac"
Explanation: 
str1 = "abac" is a subsequence of "cabac" because we can delete the first "c".
str2 = "cab" is a subsequence of "cabac" because we can delete the last "ac".
The answer provided is the shortest such string that satisfies the properties.
\`\`\`

Example 2:

\`\`\`
Input: str1 = "aaaaaaaa", str2 = "aaaaaaaa"
Output: "aaaaaaaa"
\`\`\`

\u00a0

Constraints:

\t- 1 <= str1.length, str2.length <= 1000
\t- str1 and str2 consist of lowercase English letters.`,
  },

  // 85. Best Time to Buy and Sell Stock with Transaction Fee
  {
    slug: "best-time-to-buy-and-sell-stock-with-transaction-fee",
    title: "Best Time to Buy and Sell Stock with Transaction Fee",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Greedy"],
    companies: ["meta", "amazon", "google", "bloomberg"],
    freq: 88.0,
    statement: `You are given an array \`prices\` where \`prices[i]\` is the price of a given stock on the \`i\`th day, and an integer \`fee\` representing a transaction fee.

Find the maximum profit you can achieve. You may complete as many transactions as you like, but you need to pay the transaction fee for each transaction.

Note:
\t- You may not engage in multiple transactions simultaneously (i.e., you must sell the stock before you buy again).
\t- The transaction fee is only charged once for each stock purchase and sale.

\u00a0

Example 1:

\`\`\`
Input: prices = [1,3,2,8,4,9], fee = 2
Output: 8
Explanation: The maximum profit can be achieved by:
- Buying at prices[0] = 1
- Selling at prices[3] = 8
- Buying at prices[4] = 4
- Selling at prices[5] = 9
The total profit is ((8 - 1) - 2) + ((9 - 4) - 2) = 8.
\`\`\`

Example 2:

\`\`\`
Input: prices = [1,3,7,5,10,3], fee = 3
Output: 6
\`\`\`

\u00a0

Constraints:

\t- 1 <= prices.length <= 5 * 104
\t- 1 <= prices[i] < 5 * 104
\t- 0 <= fee < 5 * 104`,
  },

  // 86. Largest Divisible Subset
  {
    slug: "largest-divisible-subset",
    title: "Largest Divisible Subset",
    difficulty: "Medium",
    topics: ["Array", "Math", "Dynamic Programming", "Sorting"],
    companies: ["google", "amazon"],
    freq: 85.0,
    statement: `Given a set of distinct positive integers \`nums\`, return the largest subset \`answer\` such that every pair \`(answer[i], answer[j])\` of elements in this subset satisfies:
\t- \`answer[i] % answer[j] == 0\`, or
\t- \`answer[j] % answer[i] == 0\`

If there are multiple solutions, return any of them.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,2,3]
Output: [1,2]
Explanation: [1,3] is also accepted.
\`\`\`

Example 2:

\`\`\`
Input: nums = [1,2,4,8]
Output: [1,2,4,8]
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 1000
\t- 1 <= nums[i] <= 2 * 109
\t- All the integers in nums are unique.`,
  },

  // 87. Number of Longest Increasing Subsequence
  {
    slug: "number-of-longest-increasing-subsequence",
    title: "Number of Longest Increasing Subsequence",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Binary Indexed Tree", "Segment Tree"],
    companies: ["meta", "amazon", "google"],
    freq: 86.0,
    statement: `Given an integer array \`nums\`, return the number of longest increasing subsequences.

Notice that the sequence has to be strictly increasing.

\u00a0

Example 1:

\`\`\`
Input: nums = [1,3,5,4,7]
Output: 2
Explanation: The two longest increasing subsequences are [1, 3, 4, 7] and [1, 3, 5, 7].
\`\`\`

Example 2:

\`\`\`
Input: nums = [2,2,2,2,2]
Output: 5
Explanation: The length of the longest increasing subsequence is 1, and there are 5 subsequences of length 1, so output 5.
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length <= 2000
\t- -106 <= nums[i] <= 106`,
  },

  // 88. Partition Array for Maximum Sum
  {
    slug: "partition-array-for-maximum-sum",
    title: "Partition Array for Maximum Sum",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "google"],
    freq: 84.0,
    statement: `Given an integer array \`arr\`, partition the array into (contiguous) subarrays of length at most \`k\`. After partitioning, each subarray has their values changed to become the maximum value of that subarray.

Return the largest sum of the given array after partitioning. Test cases are generated so that the answer fits in a 32-bit signed integer.

\u00a0

Example 1:

\`\`\`
Input: arr = [1,15,7,9,2,5,10], k = 3
Output: 84
Explanation: arr becomes [15,15,15,9,10,10,10]
\`\`\`

Example 2:

\`\`\`
Input: arr = [1,4,1,5,7,3,6,1,9,9,3], k = 4
Output: 83
\`\`\`

Example 3:

\`\`\`
Input: arr = [1], k = 1
Output: 1
\`\`\`

\u00a0

Constraints:

\t- 1 <= arr.length <= 500
\t- 0 <= arr[i] <= 109
\t- 1 <= k <= arr.length`,
  },

  // 89. Maximum XOR With an Element From Array
  {
    slug: "maximum-xor-with-an-element-from-array",
    title: "Maximum XOR With an Element From Array",
    difficulty: "Hard",
    topics: ["Array", "Bit Manipulation", "Trie"],
    companies: ["google", "amazon"],
    freq: 83.0,
    statement: `You are given an array \`nums\` consisting of non-negative integers. You are also given a \`queries\` array, where \`queries[i] = [xi, mi]\`.

The answer to the \`i\`th query is the maximum bitwise \`XOR\` value of \`xi\` and any \`nums[j]\` such that \`nums[j] <= mi\`. In other words, the answer is \`max(nums[j] XOR xi)\` for all \`j\` such that \`nums[j] <= mi\`. If all elements in \`nums\` are larger than \`mi\`, then the answer is \`-1\`.

Return an integer array \`answer\` where \`answer[i]\` is the answer to the \`i\`th query.

\u00a0

Example 1:

\`\`\`
Input: nums = [0,1,2,3,4], queries = [[3,1],[1,3],[5,6]]
Output: [3,3,7]
Explanation:
1) 0 and 1 are the only two integers, so 0 XOR 3 = 3.
2) 1 XOR 2 = 3.
3) 5 XOR 2 = 7.
\`\`\`

Example 2:

\`\`\`
Input: nums = [5,2,4,6,6,3], queries = [[12,4],[8,1],[6,3]]
Output: [15,-1,5]
\`\`\`

\u00a0

Constraints:

\t- 1 <= nums.length, queries.length <= 105
\t- queries[i].length == 2
\t- 0 <= nums[j], xi, mi <= 109`,
  },

  // 90. Replace Words
  {
    slug: "replace-words",
    title: "Replace Words",
    difficulty: "Medium",
    topics: ["Array", "Hash Table", "String", "Trie"],
    companies: ["uber", "google", "amazon"],
    freq: 85.0,
    statement: `In English, we have a concept called root, which can be followed by some other word to form another longer word - let's call this word derivative. For example, when the root \`"help"\` is followed by the derivative \`"ful"\`, we can form the word \`"helpful"\`.

Given a dictionary consisting of many roots and a sentence consisting of words separated by spaces, replace all the derivatives in the sentence with the root forming it. If a derivative can be replaced by more than one root, replace it with the root that has the shortest length.

Return the sentence after the replacement.

\u00a0

Example 1:

\`\`\`
Input: dictionary = ["cat","bat","rat"], sentence = "the cattle was rattled by the battery"
Output: "the cat was rat by the bat"
\`\`\`

Example 2:

\`\`\`
Input: dictionary = ["a","b","c"], sentence = "aadsfasf absbs bbab cadsfafs"
Output: "a a b c"
\`\`\`

\u00a0

Constraints:

\t- 1 <= dictionary.length <= 1000
\t- 1 <= dictionary[i].length <= 100
\t- dictionary[i] consists of only lower-case letters.
\t- 1 <= sentence.length <= 106
\t- sentence consists of only lower-case letters and spaces.
\t- The number of words in sentence is in the range [1, 1000]
\t- The length of each word in sentence is in the range [1, 1000]
\t- Every two consecutive words in sentence will be separated by exactly one space.`,
  },

  // 91. Repeated String Match
  {
    slug: "repeated-string-match",
    title: "Repeated String Match",
    difficulty: "Medium",
    topics: ["String", "String Matching"],
    companies: ["google", "amazon", "microsoft"],
    freq: 84.0,
    statement: `Given two strings \`a\` and \`b\`, return the minimum number of times you should repeat string \`a\` so that string \`b\` is a substring of it. If it is impossible for \`b\` to be a substring of \`a\` after repeating it, return \`-1\`.

Notice: string \`"abc"\` repeated 0 times is \`""\`, repeated 1 time is \`"abc"\` and repeated 2 times is \`"abcabc"\`.

\u00a0

Example 1:

\`\`\`
Input: a = "abcd", b = "cdabcdab"
Output: 3
Explanation: We return 3 because by repeating a three times "abcdabcdabcd", b is a substring of it.
\`\`\`

Example 2:

\`\`\`
Input: a = "a", b = "aa"
Output: 2
\`\`\`

\u00a0

Constraints:

\t- 1 <= a.length, b.length <= 104
\t- a and b consist of lowercase English letters.`,
  },

  // 92. Count Square Submatrices with All Ones
  {
    slug: "count-square-submatrices-with-all-ones",
    title: "Count Square Submatrices with All Ones",
    difficulty: "Medium",
    topics: ["Array", "Dynamic Programming", "Matrix"],
    companies: ["google", "amazon"],
    freq: 85.0,
    statement: `Given a \`m * n\` matrix of ones and zeros, return how many square submatrices have all ones.

\u00a0

Example 1:

\`\`\`
Input: matrix =
[
  [0,1,1,1],
  [1,1,1,1],
  [0,1,1,1]
]
Output: 15
Explanation: 
There are 10 squares of side 1.
There are 4 squares of side 2.
There is  1 square of side 3.
Total number of squares = 10 + 4 + 1 = 15.
\`\`\`

Example 2:

\`\`\`
Input: matrix = 
[
  [1,0,1],
  [1,1,0],
  [1,1,0]
]
Output: 7
Explanation: 
There are 6 squares of side 1.  
There is 1 square of side 2. 
Total number of squares = 6 + 1 = 7.
\`\`\`

\u00a0

Constraints:

\t- 1 <= arr.length <= 300
\t- 1 <= arr[0].length <= 300
\t- 0 <= arr[i][j] <= 1`,
  },

  // 93. Minimum Cost to Cut a Stick
  {
    slug: "minimum-cost-to-cut-a-stick",
    title: "Minimum Cost to Cut a Stick",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming", "Sorting"],
    companies: ["google", "amazon"],
    freq: 88.0,
    statement: `Given a wooden stick of length \`n\` units. The stick is labelled from \`0\` to \`n\`. For example, a stick of length 6 is labelled as follows:

Given an integer array \`cuts\` where \`cuts[i]\` denotes a position you should perform a cut at.

You should perform the cuts in order, you can change the order of the cuts as you wish.

The cost of one cut is the length of the stick to be cut, the total cost is the sum of costs of all cuts. When you cut a stick, it will be split into two smaller sticks (i.e. the sum of their lengths is the length of the stick before the cut). Please refer to the first example for a better explanation.

Return the minimum total cost of the cuts.

\u00a0

Example 1:

\`\`\`
Input: n = 7, cuts = [1,3,4,5]
Output: 16
Explanation: Using cuts order = [1, 3, 4, 5] as in the input leads to cost = 7 + 6 + 4 + 3 = 20.
Rearranging the cuts to [3, 5, 1, 4] gives cost = 7 + 4 + 3 + 2 = 16 which is the minimum possible.
\`\`\`

Example 2:

\`\`\`
Input: n = 9, cuts = [5,6,1,4,2]
Output: 22
Explanation: If you try the given cuts ordering the cost will be 25.
There are much better orderings to achieve minimum cost, e.g. [4, 6, 5, 2, 1] has cost = 22 which is the minimum possible.
\`\`\`

\u00a0

Constraints:

\t- 2 <= n <= 106
\t- 1 <= cuts.length <= min(n - 1, 100)
\t- 1 <= cuts[i] <= n - 1
\t- All the integers in cuts array are distinct.`,
  },

  // 94. Palindrome Partitioning II
  {
    slug: "palindrome-partitioning-ii",
    title: "Palindrome Partitioning II",
    difficulty: "Hard",
    topics: ["String", "Dynamic Programming"],
    companies: ["amazon", "meta", "google"],
    freq: 87.0,
    statement: `Given a string \`s\`, partition \`s\` such that every substring of the partition is a palindrome.

Return the minimum cuts needed for a palindrome partitioning of \`s\`.

\u00a0

Example 1:

\`\`\`
Input: s = "aab"
Output: 1
Explanation: The palindrome partitioning ["aa","b"] could be produced using 1 cut.
\`\`\`

Example 2:

\`\`\`
Input: s = "a"
Output: 0
\`\`\`

Example 3:

\`\`\`
Input: s = "ab"
Output: 1
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 2000
\t- s consists of lowercase English letters only.`,
  },

  // 95. Dungeon Game
  {
    slug: "dungeon-game",
    title: "Dungeon Game",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming", "Matrix"],
    companies: ["microsoft", "google", "amazon"],
    freq: 86.0,
    statement: `The demons had captured the princess and imprisoned her in the bottom-right corner of a \`dungeon\`. The \`dungeon\` consists of \`m x n\` rooms laid out in a 2D grid. Our valiant knight was initially positioned in the top-left room and must fight his way through \`dungeon\` to rescue the princess.

The knight has an initial health point represented by a positive integer. If at any point his health point drops to 0 or below, he dies immediately.

Some of the rooms are guarded by demons (represented by negative integers), so the knight loses health upon entering these rooms; other rooms are either empty (represented as 0) or contain magic orbs that increase the knight's health (represented by positive integers).

To reach the princess as quickly as possible, the knight decides to move only rightward or downward in each step.

Return the knight's minimum initial health so that he is able to rescue the princess.

Note that any room can contain threats or benefits, even the first room the knight enters and the bottom-right room where the princess is imprisoned.

\u00a0

Example 1:

\`\`\`
Input: dungeon = [[-2,-3,3],[-5,-10,1],[10,30,-5]]
Output: 7
Explanation: The initial health of the knight must be at least 7 if he follows the optimal path: RIGHT-> RIGHT -> DOWN -> DOWN.
\`\`\`

Example 2:

\`\`\`
Input: dungeon = [[0]]
Output: 1
\`\`\`

\u00a0

Constraints:

\t- m == dungeon.length
\t- n == dungeon[i].length
\t- 1 <= m, n <= 200
\t- -1000 <= dungeon[i][j] <= 1000`,
  },

  // 96. Minimum Difficulty of a Job Schedule
  {
    slug: "minimum-difficulty-of-a-job-schedule",
    title: "Minimum Difficulty of a Job Schedule",
    difficulty: "Hard",
    topics: ["Array", "Dynamic Programming"],
    companies: ["amazon", "meta"],
    freq: 85.0,
    statement: `You want to schedule a list of jobs in \`d\` days. Jobs are dependent (i.e To work on the \`i\`th job, you have to finish all the jobs \`j\` where \`0 <= j < i\`).

You have to finish at least one task every day. The difficulty of a job schedule is the sum of difficulties of each day of the \`d\` days. The difficulty of a day is the maximum difficulty of a job done on that day.

You are given an integer array \`jobDifficulty\` and an integer \`d\`. The difficulty of the \`i\`th job is \`jobDifficulty[i]\`.

Return the minimum difficulty of a job schedule. If you cannot find a schedule for the jobs return \`-1\`.

\u00a0

Example 1:

\`\`\`
Input: jobDifficulty = [6,5,4,3,2,1], d = 2
Output: 7
Explanation: First day you can finish the first 5 jobs, total difficulty = 6.
Second day you can finish the last job, total difficulty = 1.
The difficulty of the schedule = 6 + 1 = 7 
\`\`\`

Example 2:

\`\`\`
Input: jobDifficulty = [9,9,9], d = 4
Output: -1
Explanation: If you finish a job per day you will still have 3 days for 3 jobs. You cannot find a schedule for the given jobs.
\`\`\`

Example 3:

\`\`\`
Input: jobDifficulty = [1,1,1], d = 3
Output: 3
Explanation: The best schedule is to finish one job per day. The difficulty is 1 + 1 + 1 = 3.
\`\`\`

\u00a0

Constraints:

\t- 1 <= jobDifficulty.length <= 300
\t- 0 <= jobDifficulty[i] <= 1000
\t- 1 <= d <= 10`,
  },

  // 97. Sum of Two Integers
  {
    slug: "sum-of-two-integers",
    title: "Sum of Two Integers",
    difficulty: "Medium",
    topics: ["Math", "Bit Manipulation"],
    companies: ["meta", "amazon", "google", "microsoft"],
    freq: 86.0,
    statement: `Given two integers \`a\` and \`b\`, return the sum of the two integers without using the operators \`+\` and \`-\`.

\u00a0

Example 1:

\`\`\`
Input: a = 1, b = 2
Output: 3
\`\`\`

Example 2:

\`\`\`
Input: a = 2, b = 3
Output: 5
\`\`\`

\u00a0

Constraints:

\t- -1000 <= a, b <= 1000`,
  },

  // 98. Counting Bits
  {
    slug: "counting-bits",
    title: "Counting Bits",
    difficulty: "Easy",
    topics: ["Dynamic Programming", "Bit Manipulation"],
    companies: ["amazon", "meta", "google", "apple"],
    freq: 91.0,
    statement: `Given an integer \`n\`, return an array \`ans\` of length \`n + 1\` such that for each \`i\` (\`0 <= i <= n\`), \`ans[i]\` is the number of \`1\`'s in the binary representation of \`i\`.

\u00a0

Example 1:

\`\`\`
Input: n = 2
Output: [0,1,1]
Explanation:
0 --> 0
1 --> 1
2 --> 10
\`\`\`

Example 2:

\`\`\`
Input: n = 5
Output: [0,1,1,2,1,2]
Explanation:
0 --> 0
1 --> 1
2 --> 10
3 --> 11
4 --> 100
5 --> 101
\`\`\`

\u00a0

Constraints:

\t- 0 <= n <= 105

\u00a0

Follow up:
\t- It is very easy to come up with a solution with a run-time of O(n log n). Can you do it in linear time O(n) and possibly in a single pass?
\t- Can you do it without using any built-in function (i.e., like __builtin_popcount in C++)?`,
  },

  // 99. Greatest Common Divisor of Strings
  {
    slug: "greatest-common-divisor-of-strings",
    title: "Greatest Common Divisor of Strings",
    difficulty: "Easy",
    topics: ["Math", "String"],
    companies: ["amazon", "google"],
    freq: 85.0,
    statement: `For two strings \`s\` and \`t\`, we say "\`t\` divides \`s\`" if and only if \`s = t + t + t + ... + t + t\` (i.e., \`t\` is concatenated with itself one or more times).

Given two strings \`str1\` and \`str2\`, return the largest string \`x\` such that \`x\` divides both \`str1\` and \`str2\`.

\u00a0

Example 1:

\`\`\`
Input: str1 = "ABCABC", str2 = "ABC"
Output: "ABC"
\`\`\`

Example 2:

\`\`\`
Input: str1 = "ABABAB", str2 = "ABAB"
Output: "AB"
\`\`\`

Example 3:

\`\`\`
Input: str1 = "LEET", str2 = "CODE"
Output: ""
\`\`\`

\u00a0

Constraints:

\t- 1 <= str1.length, str2.length <= 1000
\t- str1 and str2 consist of English uppercase letters.`,
  },

  // 100. Reverse Vowels of a String
  {
    slug: "reverse-vowels-of-a-string",
    title: "Reverse Vowels of a String",
    difficulty: "Easy",
    topics: ["Two Pointers", "String"],
    companies: ["google", "apple", "amazon"],
    freq: 84.0,
    statement: `Given a string \`s\`, reverse only all the vowels in the string and return it.

The vowels are \`'a'\`, \`'e'\`, \`'i'\`, \`'o'\`, and \`'u'\`, and they can appear in both lower and upper cases, more than once.

\u00a0

Example 1:

\`\`\`
Input: s = "IceCreAm"
Output: "AceCreIm"
Explanation: The vowels in s are ['I', 'e', 'e', 'A']. On reversing the vowels, s becomes "AceCreIm".
\`\`\`

Example 2:

\`\`\`
Input: s = "leetcode"
Output: "leotcede"
\`\`\`

\u00a0

Constraints:

\t- 1 <= s.length <= 3 * 105
\t- s consist of printable ASCII characters.`,
  },
];
