const fs = require("fs");
const path = require("path");
const assert = require("assert");

const problems = JSON.parse(
  fs.readFileSync(path.join(__dirname, "../src/data/problems.json"), "utf-8"),
);
const statements = JSON.parse(
  fs.readFileSync(path.join(__dirname, "../src/data/statements.json"), "utf-8"),
);

console.log("=== DATASET INTEGRITY VERIFICATION ===");
console.log("Total problems count:", problems.length);
console.log("Total statements count:", Object.keys(statements).length);

const seenSlugs = new Set();
let validCount = 0;
let validDifficulties = new Set(["Easy", "Medium", "Hard"]);

for (let i = 0; i < problems.length; i++) {
  const p = problems[i];
  assert.ok(typeof p.slug === "string" && p.slug.length > 0, `Problem at index ${i} missing slug`);
  assert.ok(!seenSlugs.has(p.slug), `Duplicate slug found: ${p.slug} at index ${i}`);
  seenSlugs.add(p.slug);

  assert.ok(typeof p.title === "string" && p.title.length > 0, `Problem ${p.slug} missing title`);
  assert.ok(
    validDifficulties.has(p.difficulty),
    `Problem ${p.slug} invalid difficulty: ${p.difficulty}`,
  );
  assert.ok(Array.isArray(p.topics) && p.topics.length > 0, `Problem ${p.slug} missing topics`);
  assert.ok(Array.isArray(p.companies), `Problem ${p.slug} invalid companies array`);
  assert.ok(
    typeof p.freq === "number" && !isNaN(p.freq),
    `Problem ${p.slug} invalid freq: ${p.freq}`,
  );

  validCount++;
}

console.log(`[PASS] Verified ${validCount} problems adhere strictly to the Problem schema.`);

// Check statements coverage
let missingStatements = 0;
for (const p of problems) {
  if (
    !statements[p.slug] ||
    typeof statements[p.slug] !== "string" ||
    statements[p.slug].trim().length === 0
  ) {
    missingStatements++;
    console.warn(`[WARN] Missing statement for slug: ${p.slug}`);
  }
}

console.log(
  `Statements status: ${problems.length - missingStatements} / ${problems.length} have full statements.`,
);
assert.equal(missingStatements <= 2, true, "All newly added problems must have full statements");

console.log("=== ALL CHECKS PASSED PERFECTLY ===");
