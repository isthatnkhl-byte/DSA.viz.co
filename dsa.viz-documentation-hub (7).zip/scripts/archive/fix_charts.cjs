const fs = require('fs');
let str = fs.readFileSync('src/components/dashboard/AnalyticsCharts.tsx', 'utf8');

str = str.replace(/const d1 = new Date\(sortedDays\[i - 1\]\);/g, "const d1 = new Date(sortedDays[i - 1] as string);");
str = str.replace(/const d2 = new Date\(sortedDays\[i\]\);/g, "const d2 = new Date(sortedDays[i] as string);");
str = str.replace(/const todayStr = new Date\(\)\.toISOString\(\)\.split\("T"\)\[0\];/g, "const todayStr = new Date().toISOString().split(\"T\")[0] as string;");
str = str.replace(/const yesterdayStr = yesterdayDate\.toISOString\(\)\.split\("T"\)\[0\];/g, "const yesterdayStr = yesterdayDate.toISOString().split(\"T\")[0] as string;");
str = str.replace(/const dateStr = new Date\(s\.created_at\)\.toISOString\(\)\.split\("T"\)\[0\];/g, "const dateStr = new Date(s.created_at).toISOString().split(\"T\")[0] as string;");
str = str.replace(/currDate\.toISOString\(\)\.split\("T"\)\[0\]/g, "(currDate.toISOString().split(\"T\")[0] as string)");
str = str.replace(/const dateStr = heatmapDate\.toISOString\(\)\.split\("T"\)\[0\];/g, "const dateStr = heatmapDate.toISOString().split(\"T\")[0] as string;");
str = str.replace(/new Date\(s\.created_at\)\.toISOString\(\)\.split\("T"\)\[0\] === dateStr/g, "(new Date(s.created_at).toISOString().split(\"T\")[0] as string) === dateStr");

fs.writeFileSync('src/components/dashboard/AnalyticsCharts.tsx', str);
