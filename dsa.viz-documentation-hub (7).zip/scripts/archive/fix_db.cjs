const { Pool } = require('pg');
require('dotenv').config();

async function run() {
  try {
    const cleanUsername = 'nikhil_it_is';
    const [userRes, profileRes, calRes, subRes] = await Promise.all([
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}`),
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}/profile`),
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}/calendar`),
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}/submission?limit=12`),
    ]);
    
    const userJson = userRes.ok ? await userRes.json() : null;
    const profileJson = profileRes.ok ? await profileRes.json() : null;
    const calJson = calRes.ok ? await calRes.json() : null;
    const subJson = subRes.ok ? await subRes.json() : null;

    const rawCal = calJson?.submissionCalendar;
    const parsedCalendar = {};
    if (typeof rawCal === "string") {
      try { Object.assign(parsedCalendar, JSON.parse(rawCal)); } catch {}
    } else if (rawCal && typeof rawCal === "object") {
      Object.assign(parsedCalendar, rawCal);
    }
    
    if (Object.keys(parsedCalendar).length === 0 && profileJson?.submissionCalendar) {
      if (typeof profileJson.submissionCalendar === "string") {
        try { Object.assign(parsedCalendar, JSON.parse(profileJson.submissionCalendar)); } catch {}
      } else {
        Object.assign(parsedCalendar, profileJson.submissionCalendar);
      }
    }

    const stats = {
      username: cleanUsername,
      name: userJson?.name || cleanUsername,
      avatar: userJson?.avatar || "https://leetcode.com/static/images/LeetCode_logo.png",
      ranking: userJson?.ranking || profileJson?.ranking || 0,
      reputation: userJson?.reputation || profileJson?.reputation || 0,
      totalSolved: Number(profileJson?.totalSolved) || 0,
      totalQuestions: profileJson?.totalQuestions || 3300,
      easySolved: Number(profileJson?.easySolved) || 0,
      totalEasy: profileJson?.totalEasy || 850,
      mediumSolved: Number(profileJson?.mediumSolved) || 0,
      totalMedium: profileJson?.totalMedium || 1750,
      hardSolved: Number(profileJson?.hardSolved) || 0,
      totalHard: profileJson?.totalHard || 750,
      acceptanceRate: profileJson?.acceptanceRate || 0,
      submissionCalendar: Object.keys(parsedCalendar).length > 0 ? parsedCalendar : {},
      totalActiveDays: calJson?.totalActiveDays || Math.max(0, Object.keys(parsedCalendar).length),
      streak: calJson?.streak || 0,
      recentSubmissions: Array.isArray(subJson?.submission) && subJson.submission.length > 0
        ? subJson.submission.slice(0, 10).map((s) => ({
            title: s.title,
            titleSlug: s.titleSlug,
            statusDisplay: s.statusDisplay,
            lang: s.lang,
            timestamp: s.timestamp,
          }))
        : (profileJson?.recentSubmissions || []).slice(0, 10).map((s) => ({
             title: s.title,
             titleSlug: s.titleSlug,
             statusDisplay: s.statusDisplay,
             lang: s.lang,
             timestamp: s.timestamp,
          })),
      lastSyncedAt: new Date().toISOString(),
    };

    const pool = new Pool({
      host: process.env.SQL_HOST,
      user: process.env.SQL_USER,
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME
    });

    await pool.query("UPDATE profiles SET leetcode_stats = $1 WHERE leetcode_username = $2", [stats, cleanUsername]);
    console.log("DB updated!");
    process.exit(0);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
}
run();
