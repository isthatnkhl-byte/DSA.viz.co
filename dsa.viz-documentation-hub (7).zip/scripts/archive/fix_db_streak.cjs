const { Pool } = require('pg');
require('dotenv').config();

async function run() {
  try {
    const cleanUsername = 'nikhil_it_is';
    const pool = new Pool({
      host: process.env.SQL_HOST,
      user: process.env.SQL_USER,
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME
    });

    const res = await pool.query("SELECT * FROM profiles WHERE leetcode_username = $1", [cleanUsername]);
    
    if (res.rows.length > 0) {
      const stats = res.rows[0].leetcode_stats;
      const calendar = stats.submissionCalendar;
      
      let computedStreak = 0;
      if (calendar && Object.keys(calendar).length > 0) {
        const ONE_DAY = 86400; // seconds
        const timestamps = Object.keys(calendar).map(Number).sort((a, b) => b - a);
        const nowTs = Math.floor(Date.now() / 1000);
        
        const todayStart = Math.floor(nowTs / ONE_DAY) * ONE_DAY;
        
        if (timestamps[0] >= todayStart - ONE_DAY) {
          let currentExpected = timestamps[0]; 
          
          if (timestamps[0] === todayStart || timestamps[0] === todayStart - ONE_DAY) {
            for (const t of timestamps) {
              if (t === currentExpected) {
                computedStreak++;
                currentExpected -= ONE_DAY;
              } else if (t < currentExpected) {
                break;
              }
            }
          }
        }
      }
      
      stats.streak = computedStreak;
      
      await pool.query("UPDATE profiles SET leetcode_stats = $1 WHERE leetcode_username = $2", [stats, cleanUsername]);
      console.log("DB updated! Computed Streak:", computedStreak);
    } else {
      console.log("User not found in DB.");
    }
    
    process.exit(0);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
}
run();
