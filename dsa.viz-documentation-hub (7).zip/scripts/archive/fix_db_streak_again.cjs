const { Pool } = require('pg');
require('dotenv').config();

async function run() {
  try {
    const cleanUsername = 'nikhil_it_is';
    const pool = new Pool({
      host: process.env.SQL_HOST,
      user: process.env.SQL_USER,
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME
    });

    const res = await pool.query("SELECT * FROM profiles WHERE leetcode_username = $1", [cleanUsername]);
    
    if (res.rows.length > 0) {
      const stats = res.rows[0].leetcode_stats;
      stats.streak = 0;
      stats.totalActiveDays = 9; // User mentioned "total active days 9 keep it as it was"
      
      await pool.query("UPDATE profiles SET leetcode_stats = $1 WHERE leetcode_username = $2", [stats, cleanUsername]);
      console.log("DB updated! Streak:", stats.streak);
    } else {
      console.log("User not found in DB.");
    }
    
    process.exit(0);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
}
run();
