const fs = require('fs');
let code = fs.readFileSync('src/lib/submissions.functions.ts', 'utf8');
code = code.replace(
  'leetcode_stats: null,',
  'leetcode_stats: null,\n        githubToken: null as string | null,'
);
fs.writeFileSync('src/lib/submissions.functions.ts', code);
