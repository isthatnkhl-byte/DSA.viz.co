const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

// Replace the params in /api/github/url
code = code.replace(/const params = new URLSearchParams\(\{\n\s*client_id: clientId,\n\s*redirect_uri: redirectUri,\n\s*response_type: 'code',\n\s*scope: 'repo',\s*\/\/[^\n]*\n\s*state: state,\n\s*\}\);/g, `const params = new URLSearchParams({
    client_id: clientId,
    response_type: 'code',
    scope: 'repo',
    state: state,
  });`);

// Replace the fetch in /api/github/callback
code = code.replace(/body: JSON\.stringify\(\{\n\s*client_id: process\.env\.GITHUB_CLIENT_ID,\n\s*client_secret: process\.env\.GITHUB_CLIENT_SECRET,\n\s*code,\n\s*redirect_uri: redirectUri,\n\s*\}\)/g, `body: JSON.stringify({
        client_id: process.env.GITHUB_CLIENT_ID,
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code,
      })`);

fs.writeFileSync('server.ts', code);
console.log("Successfully removed explicit redirect_uri to prevent mismatches");
