const fs = require('fs');
let c = fs.readFileSync('src/components/SiteHeader.tsx', 'utf8');
c = c.replace(/to="\/sheets"/g, 'to={"/sheets" as any}');
fs.writeFileSync('src/components/SiteHeader.tsx', c);
