const fs = require('fs');
let profileCode = fs.readFileSync('src/routes/_authenticated/profile.tsx', 'utf8');
if (!profileCode.includes('getAuth')) {
  profileCode = profileCode.replace('import { useAuth } from "@/hooks/useAuth";', 'import { useAuth } from "@/hooks/useAuth";\nimport { getAuth } from "firebase/auth";');
}
profileCode = profileCode.replace('const handleMessage = (event) => {', 'const handleMessage = (event: MessageEvent) => {');
fs.writeFileSync('src/routes/_authenticated/profile.tsx', profileCode);

let problemCode = fs.readFileSync('src/routes/problem.$slug.tsx', 'utf8');
if (!problemCode.includes('getProfileStats')) {
  problemCode = problemCode.replace('import { saveSubmission } from "@/lib/submissions.functions";', 'import { saveSubmission, getProfileStats } from "@/lib/submissions.functions";');
}
fs.writeFileSync('src/routes/problem.$slug.tsx', problemCode);
