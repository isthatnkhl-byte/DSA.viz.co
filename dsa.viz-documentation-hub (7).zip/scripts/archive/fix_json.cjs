const fs = require('fs');
const b = fs.readFileSync('src/data/statements.json');
let str = b.toString('utf8');

// Find the last valid key-value pair
const lastComma = str.lastIndexOf('",\n  "');
if (lastComma !== -1) {
    str = str.substring(0, lastComma + 1) + '\n}';
    try {
        const obj = JSON.parse(str);
        fs.writeFileSync('src/data/statements.json', JSON.stringify(obj, null, 2), 'utf8');
        console.log("Fixed successfully!");
    } catch (e) {
        console.error("Still invalid: ", e.message);
    }
}
