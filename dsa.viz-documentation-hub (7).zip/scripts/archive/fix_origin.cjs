const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');
code = code.replace(
  'const origin = req.headers.origin || `https://${req.headers.host}`;',
  'const proto = req.headers["x-forwarded-proto"] || "https";\n  const host = req.headers["x-forwarded-host"] || req.headers.host;\n  const origin = req.headers.origin || `${proto}://${host}`;'
);
fs.writeFileSync('server.ts', code);
