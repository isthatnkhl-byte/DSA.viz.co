const fs = require('fs');
let code = fs.readFileSync('src/routes/problem.$slug.tsx', 'utf8');
code = code.replace(/import \{ saveSubmission \} from "@\/lib\/submissions\.functions";/, 'import { saveSubmission, getProfileStats } from "@/lib/submissions.functions";');
fs.writeFileSync('src/routes/problem.$slug.tsx', code);
