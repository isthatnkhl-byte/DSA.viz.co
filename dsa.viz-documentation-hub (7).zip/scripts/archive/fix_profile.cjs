const fs = require('fs');
let code = fs.readFileSync('src/routes/_authenticated/profile.tsx', 'utf8');
if (!code.includes('import { getAuth }')) {
  code = code.replace('import { useAuth } from "@/hooks/useAuth";', 'import { useAuth } from "@/hooks/useAuth";\nimport { getAuth } from "firebase/auth";');
}
fs.writeFileSync('src/routes/_authenticated/profile.tsx', code);
