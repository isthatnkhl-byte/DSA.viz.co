const fs = require('fs');
let code = fs.readFileSync('src/components/compiler/CppCodeEditor.tsx', 'utf8');
code = code.replace(
  'onExportSnapshot,\n  loading = false,\n  disabled = false,\n}: CppCodeEditorProps) {',
  'onExportSnapshot,\n  onPushToGithub,\n  githubLoading,\n  loading = false,\n  disabled = false,\n}: CppCodeEditorProps) {'
);
fs.writeFileSync('src/components/compiler/CppCodeEditor.tsx', code);
