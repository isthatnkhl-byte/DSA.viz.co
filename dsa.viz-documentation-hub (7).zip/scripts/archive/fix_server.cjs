const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const target1 = `  } catch (error) {
    console.error("Failed to sync LeetCode profile:", error);
    res.status(500).json({ error: "Failed to sync" });
  }
});`;

const trailing = `  } catch (error) {
    res.status(500).json({ error: "Failed to sync" });
  }
});`;

const idx1 = code.indexOf(target1);
if (idx1 !== -1) {
  const endIdx = idx1 + target1.length;
  // If the next chars are the trailing block, remove them
  const after = code.substring(endIdx);
  if (after.startsWith(trailing) || after.trim().startsWith(trailing.trim())) {
     code = code.substring(0, endIdx) + after.replace(trailing, '');
  }
  
  // also check if there's any stray \n  } catch (error) { around
}

fs.writeFileSync('server.ts', code);
