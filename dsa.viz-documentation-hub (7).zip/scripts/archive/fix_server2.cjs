const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(/    res\.json\(\{ success: true \}\);\n  \} catch \(error\) \{\n    res\.status\(500\)\.json\(\{ error: "Failed to sync" \}\);\n  \}\n\}\);/g, '');

fs.writeFileSync('server.ts', code);
