const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');
code = code.replace(/streak: calJson\?\.streak \|\| 0,/, 'streak: computedStreak,');
fs.writeFileSync('server.ts', code);
