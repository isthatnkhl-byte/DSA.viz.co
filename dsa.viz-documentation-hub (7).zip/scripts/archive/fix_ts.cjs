const fs = require('fs');

let cppCode = fs.readFileSync('src/components/compiler/CppCodeEditor.tsx', 'utf8');
cppCode = cppCode.replace(/onPushToGithub\(localCode\)/g, 'onPushToGithub(code)');
cppCode = cppCode.replace(/onExportSnapshot,\n  loading,\n  disabled,\n\}: CppCodeEditorProps\) \{/g, 'onExportSnapshot,\n  onPushToGithub,\n  githubLoading,\n  loading,\n  disabled,\n}: CppCodeEditorProps) {');
fs.writeFileSync('src/components/compiler/CppCodeEditor.tsx', cppCode);

let compilerCode = fs.readFileSync('src/routes/compiler.tsx', 'utf8');
compilerCode = compilerCode.replace(/const titleSlug = activeTemplate\?\.id \|\| "cpp-sandbox";/g, 'const titleSlug = "cpp-sandbox";');
fs.writeFileSync('src/routes/compiler.tsx', compilerCode);
