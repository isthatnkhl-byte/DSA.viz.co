const fs = require('fs');
let code = fs.readFileSync('src/routes/problem.$slug.tsx', 'utf8');
code = code.replace(/profileStats\?\.profile\?\.githubToken/g, '(profileStats?.profile as any)?.githubToken');
fs.writeFileSync('src/routes/problem.$slug.tsx', code);
