const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const githubRoutes = `

// GitHub OAuth
app.get("/api/github/url", requireAuth, (req, res) => {
  const uid = req.user.uid;
  const clientId = process.env.GITHUB_CLIENT_ID;
  if (!clientId) {
    return res.status(500).json({ error: "GITHUB_CLIENT_ID is not configured" });
  }

  // Use the origin from the request to construct the redirect URI
  const origin = req.headers.origin || \`https://\${req.headers.host}\`;
  const redirectUri = \`\${origin}/api/github/callback\`;
  
  // Create state combining uid and redirectUri
  const state = Buffer.from(JSON.stringify({ uid, redirectUri })).toString('base64');

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'repo', // Needs repo scope to push code
    state: state,
  });

  const authUrl = \`https://github.com/login/oauth/authorize?\${params}\`;
  res.json({ url: authUrl });
});

app.get("/api/github/callback", async (req, res) => {
  const { code, state } = req.query;
  if (!code || !state) {
    return res.status(400).send("Missing code or state");
  }

  let uid, redirectUri;
  try {
    const decoded = JSON.parse(Buffer.from(state, 'base64').toString('utf8'));
    uid = decoded.uid;
    redirectUri = decoded.redirectUri;
  } catch (e) {
    return res.status(400).send("Invalid state");
  }

  try {
    const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        client_id: process.env.GITHUB_CLIENT_ID,
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code,
        redirect_uri: redirectUri,
      })
    });
    
    const tokenData = await tokenRes.json();
    if (tokenData.error) {
      console.error("GitHub token error:", tokenData);
      return res.status(400).send(\`Error: \${tokenData.error_description}\`);
    }

    const accessToken = tokenData.access_token;
    
    // Save to DB
    await updateProfile(uid, { githubToken: accessToken });

    res.send(\`
      <html>
        <body>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'GITHUB_AUTH_SUCCESS' }, '*');
              window.close();
            } else {
              window.location.href = '/';
            }
          </script>
          <p>GitHub connected successfully. This window should close automatically.</p>
        </body>
      </html>
    \`);
  } catch (error) {
    console.error("Failed to connect GitHub:", error);
    res.status(500).send("Failed to connect GitHub");
  }
});

app.post("/api/github/push", requireAuth, async (req, res) => {
  try {
    const { code, titleSlug, lang } = req.body;
    const uid = req.user.uid;
    
    const profile = await getProfile(uid);
    const githubToken = profile?.githubToken;
    
    if (!githubToken) {
      return res.status(401).json({ error: "GitHub account not connected" });
    }

    const extMap = {
      "cpp": "cpp",
      "java": "java",
      "python": "py",
      "python3": "py",
      "javascript": "js",
      "typescript": "ts"
    };
    const ext = extMap[lang] || "txt";
    const repoName = "LeetCode-Solutions";
    const path = \`\${titleSlug}/\${titleSlug}.\${ext}\`;
    const message = \`Add solution for \${titleSlug}\`;

    // 1. Get GitHub Username
    const userRes = await fetch("https://api.github.com/user", {
      headers: { "Authorization": \`Bearer \${githubToken}\` }
    });
    const userData = await userRes.json();
    if (!userRes.ok) return res.status(400).json({ error: "Invalid GitHub token" });
    const owner = userData.login;

    // 2. Check if repo exists, create if not
    let repoRes = await fetch(\`https://api.github.com/repos/\${owner}/\${repoName}\`, {
      headers: { "Authorization": \`Bearer \${githubToken}\` }
    });
    if (repoRes.status === 404) {
      repoRes = await fetch("https://api.github.com/user/repos", {
        method: "POST",
        headers: { "Authorization": \`Bearer \${githubToken}\`, "Content-Type": "application/json" },
        body: JSON.stringify({
          name: repoName,
          description: "My LeetCode solutions synced automatically",
          private: false,
          auto_init: true
        })
      });
      if (!repoRes.ok) {
        return res.status(500).json({ error: "Failed to create repository" });
      }
      // wait a bit for initialization
      await new Promise(r => setTimeout(r, 2000));
    }

    // 3. Check if file exists to get SHA (for updates)
    let sha = undefined;
    const fileRes = await fetch(\`https://api.github.com/repos/\${owner}/\${repoName}/contents/\${path}\`, {
      headers: { "Authorization": \`Bearer \${githubToken}\` }
    });
    if (fileRes.ok) {
      const fileData = await fileRes.json();
      sha = fileData.sha;
    }

    // 4. Create/Update file
    const content = Buffer.from(code).toString("base64");
    const pushRes = await fetch(\`https://api.github.com/repos/\${owner}/\${repoName}/contents/\${path}\`, {
      method: "PUT",
      headers: { "Authorization": \`Bearer \${githubToken}\`, "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        content,
        sha
      })
    });

    if (!pushRes.ok) {
      const err = await pushRes.json();
      return res.status(500).json({ error: "Failed to push code: " + err.message });
    }

    res.json({ success: true, url: \`https://github.com/\${owner}/\${repoName}/blob/main/\${path}\` });

  } catch (error) {
    console.error("GitHub push error:", error);
    res.status(500).json({ error: "Failed to push to GitHub" });
  }
});
`;

if (!code.includes('/api/github/url')) {
  code = code.replace(/app\.listen\(PORT,/, githubRoutes + '\napp.listen(PORT,');
  fs.writeFileSync('server.ts', code);
  console.log("GitHub routes injected");
} else {
  console.log("GitHub routes already exist");
}
