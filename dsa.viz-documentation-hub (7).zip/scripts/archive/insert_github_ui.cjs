const fs = require('fs');

const GITHUB_UI_CODE = `
            {/* ------------------------------------------------------------------ */}
            {/* CONNECT WITH GITHUB MODULE                                         */}
            {/* ------------------------------------------------------------------ */}
            <div className="flex flex-col gap-5 rounded-2xl border border-border/80 bg-card/75 p-6 shadow-sm backdrop-blur-sm">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="flex size-9 items-center justify-center rounded-xl bg-foreground/5 border border-foreground/10 text-foreground">
                    <Github className="size-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground flex items-center gap-2">
                      <span>GitHub Integration</span>
                      {(profile as any)?.githubToken && (
                        <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 font-mono text-[10px] font-bold text-emerald-400 border border-emerald-500/30">
                          CONNECTED
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      Connect your GitHub account to enable one-click pushing of your sandbox and problem solutions directly to your repositories.
                    </p>
                  </div>
                </div>

                {!(profile as any)?.githubToken ? (
                  <Button
                    onClick={handleConnectGithub}
                    className="h-8 gap-1.5 font-mono text-xs bg-[#24292e] text-white hover:bg-[#24292e]/80"
                  >
                    <Github className="size-3.5" />
                    <span>Connect GitHub</span>
                  </Button>
                ) : (
                  <Button
                    onClick={handleConnectGithub}
                    variant="outline"
                    className="h-8 gap-1.5 font-mono text-xs"
                  >
                    <RefreshCw className="size-3.5" />
                    <span>Reconnect</span>
                  </Button>
                )}
              </div>
            </div>
`;

let code = fs.readFileSync('src/routes/_authenticated/profile.tsx', 'utf8');

if (!code.includes('CONNECT WITH GITHUB MODULE')) {
  // Find the end of the LeetCode connection module or the beginning of the Dashboard view
  // Let's insert it right above "{/* Connected LeetCode Dashboard View */}"
  code = code.replace(
    /\{\/\* Connected LeetCode Dashboard View \*\/\}/,
    GITHUB_UI_CODE + '\n\n              {/* Connected LeetCode Dashboard View */}'
  );
  fs.writeFileSync('src/routes/_authenticated/profile.tsx', code);
  console.log("Successfully injected GitHub UI module.");
} else {
  console.log("GitHub UI module already exists.");
}
