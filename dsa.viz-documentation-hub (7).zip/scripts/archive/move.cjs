const fs = require('fs');
const lines = fs.readFileSync('server.ts', 'utf8').split('\n');

let githubStart = -1;
let githubEnd = -1;

for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('// GitHub OAuth')) githubStart = i;
  if (lines[i].includes('app.listen(PORT, "0.0.0.0"')) githubEnd = i;
}

if (githubStart !== -1 && githubEnd !== -1) {
  const githubLines = lines.splice(githubStart, githubEnd - githubStart);
  
  let targetIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('async function startServer() {')) {
      targetIdx = i;
      break;
    }
  }
  
  if (targetIdx !== -1) {
    lines.splice(targetIdx, 0, ...githubLines);
    fs.writeFileSync('server.ts', lines.join('\n'));
    console.log("Moved routes successfully");
  } else {
    console.log("Target not found");
  }
} else {
  console.log("GitHub block not found", githubStart, githubEnd);
}
