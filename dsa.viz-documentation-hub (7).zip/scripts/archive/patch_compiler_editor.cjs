const fs = require('fs');
let code = fs.readFileSync('src/components/compiler/CppCodeEditor.tsx', 'utf8');

// Add Github icon
code = code.replace(/import \{([\s\S]*?)Camera,/g, 'import {$1Camera, Github,');

// Add props
code = code.replace(/onExportSnapshot\?: \(\) => void;/g, 'onExportSnapshot?: () => void;\n  onPushToGithub?: (code: string) => void;\n  githubLoading?: boolean;');

// Update destructuring
code = code.replace(/onExportSnapshot,\n  loading,\n  disabled,\n\}: CppCodeEditorProps\) \{/g, 'onExportSnapshot,\n  onPushToGithub,\n  githubLoading,\n  loading,\n  disabled,\n}: CppCodeEditorProps) {');

// Add button
const githubButton = `
            {onPushToGithub && (
              <Button
                onClick={() => onPushToGithub(localCode)}
                disabled={githubLoading || disabled}
                variant="outline"
                size="sm"
                className="h-9 gap-1.5 rounded-xl px-3 font-mono text-[11px] font-bold transition-all duration-300 hover:scale-105 active:scale-95 border-[#24292e]/40 bg-[#24292e]/10 text-foreground hover:bg-[#24292e]/20 hover:border-[#24292e]/60 shadow-sm"
                title="Push to GitHub"
              >
                {githubLoading ? (
                  <Zap className="size-4 animate-spin" />
                ) : (
                  <Github className="size-4" />
                )}
                <span className="hidden sm:inline-block tracking-wide">PUSH TO GITHUB</span>
              </Button>
            )}
`;

code = code.replace(/(\{\/\* Quick Run Action Button right beside main\.cpp \*\/\}\s*<div className="flex items-center gap-2">)/, '$1' + githubButton);

fs.writeFileSync('src/components/compiler/CppCodeEditor.tsx', code);
console.log("Patched CppCodeEditor");
