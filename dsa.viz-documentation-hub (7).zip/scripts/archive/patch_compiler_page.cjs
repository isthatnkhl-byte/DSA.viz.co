const fs = require('fs');
let code = fs.readFileSync('src/routes/compiler.tsx', 'utf8');

// 1. Add imports if missing
if (!code.includes('useQuery')) {
  code = code.replace(/import \{ useServerFn \} from "@tanstack\/react-start";/g, 'import { useServerFn } from "@tanstack/react-start";\nimport { useQuery } from "@tanstack/react-query";');
}
if (!code.includes('getProfileStats')) {
  code = code.replace(/import \{ toast \} from "sonner";/g, 'import { toast } from "sonner";\nimport { getProfileStats } from "@/lib/submissions.functions";\nimport { useAuth } from "@/hooks/useAuth";\nimport { getAuth } from "firebase/auth";');
}

// 2. Add handle logic
const profileFetch = `
  const { user } = useAuth();
  const fetchStats = useServerFn(getProfileStats);
  const { data: profileStats } = useQuery({
    queryKey: ["profile-stats"],
    queryFn: () => fetchStats(),
    enabled: !!user,
  });

  const [githubLoading, setGithubLoading] = useState(false);
  const handlePushToGithub = async (codeStr: string) => {
    if (!profileStats?.profile) {
       toast.error("Please log in to push to GitHub.");
       return;
    }
    const token = (profileStats.profile as any).githubToken;
    if (!token) {
      toast.error("Please connect your GitHub account in your Profile first.");
      return;
    }
    
    setGithubLoading(true);
    try {
      const auth = getAuth();
      const authToken = await auth.currentUser?.getIdToken();
      
      // We will try to name the file based on the active template if one exists, otherwise 'sandbox'
      const titleSlug = activeTemplate?.id || "cpp-sandbox";
      
      const res = await fetch("/api/github/push", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": \`Bearer \${authToken}\`
        },
        body: JSON.stringify({
          code: codeStr,
          titleSlug: titleSlug,
          lang: "cpp"
        })
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Failed to push to GitHub");
      } else {
        toast.success("Successfully pushed C++ code to GitHub!", {
          action: {
            label: "View",
            onClick: () => window.open(data.url, "_blank")
          }
        });
      }
    } catch (e) {
      toast.error("An error occurred while pushing to GitHub");
    } finally {
      setGithubLoading(false);
    }
  };
`;

if (!code.includes('handlePushToGithub')) {
  code = code.replace(/const runCodeFn = useServerFn\(executeCppCode\);/, 'const runCodeFn = useServerFn(executeCppCode);\n' + profileFetch);
}

// 3. Add props to CppCodeEditor
code = code.replace(/<CppCodeEditor\s*code=\{activeCode\}\s*onChange=\{setActiveCode\}\s*onRun=\{handleExecute\}\s*onExportSnapshot=\{handleExportSnapshot\}\s*loading=\{loading\}/, '<CppCodeEditor\n                code={activeCode}\n                onChange={setActiveCode}\n                onRun={handleExecute}\n                onExportSnapshot={handleExportSnapshot}\n                onPushToGithub={handlePushToGithub}\n                githubLoading={githubLoading}\n                loading={loading}');

fs.writeFileSync('src/routes/compiler.tsx', code);
console.log("Patched compiler.tsx");
