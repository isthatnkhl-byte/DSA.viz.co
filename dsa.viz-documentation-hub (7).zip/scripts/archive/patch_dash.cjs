const fs = require('fs');
let content = fs.readFileSync('src/routes/_authenticated/dashboard.tsx', 'utf8');

const target = `          </Link>
        </div>`;
const replacement = `          </Link>
        </div>

        {rows.length > 0 && <AnalyticsCharts submissions={rows} />}
`;

content = content.replace(target, replacement);
fs.writeFileSync('src/routes/_authenticated/dashboard.tsx', content);
