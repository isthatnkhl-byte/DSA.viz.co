const fs = require('fs');

let func = fs.readFileSync('src/routes/_authenticated/dashboard.tsx', 'utf8');

func = func.replace('onClick={() => setOpenId(isOpen ? null : s.id)}', 'onClick={() => setOpenId(isOpen ? null : String(s.id))}');
func = func.replace('const open = rows.find((r) => r.id === openId) ?? null;', 'const open = rows.find((r) => String(r.id) === String(openId)) ?? null;');
func = func.replace('mutationFn: (id: string) => remove({ data: { id } }),', 'mutationFn: (id: string) => remove({ data: { id: id.toString() } }),');
func = func.replace('const isOpen = open?.id === s.id;', 'const isOpen = String(open?.id) === String(s.id);');
func = func.replace('{s.title}', '{s.title || s.slug}');

func = func.replace('{s.created_at', '{s.createdAt || s.created_at');
func = func.replace('{open.time_complexity}', '{open.timeComplexity || open.time_complexity}');
func = func.replace('{open.space_complexity}', '{open.spaceComplexity || open.space_complexity}');

func = func.replace('open.pseudocode', '(open.pseudocode || open.code)');
func = func.replace('{open.praise}', '{open.praise || "Great job!"}');
func = func.replace('{open.nudge}', '{open.nudge || ""}');
func = func.replace('{open.review}', '{open.review || open.classification}');
func = func.replace('open.viz_steps', 'open.viz_steps');
func = func.replace('open.test_case', 'open.test_case');
func = func.replace('open.code_lines', 'open.code_lines');

fs.writeFileSync('src/routes/_authenticated/dashboard.tsx', func);
