const fs = require('fs');

let func = fs.readFileSync('src/routes/_authenticated/dashboard.tsx', 'utf8');

func = func.replace('onClick={() => setOpenId(isOpen ? null : s.id)}', 'onClick={() => setOpenId(isOpen ? null : String(s.id))}');
func = func.replace('del.mutate(s.id)', 'del.mutate(String(s.id))');
func = func.replace('new Date(s.createdAt', 'new Date(s.createdAt || s.created_at || ""');
func = func.replace('del.mutate(open.id)', 'del.mutate(String(open.id))');

fs.writeFileSync('src/routes/_authenticated/dashboard.tsx', func);

let charts = fs.readFileSync('src/components/dashboard/AnalyticsCharts.tsx', 'utf8');
charts = charts.replace(/new Date\(s\.createdAt/g, 'new Date(s.createdAt || s.created_at || ""');
charts = charts.replace(/new Date\(s\.created_at/g, 'new Date(s.createdAt || s.created_at || ""');
fs.writeFileSync('src/components/dashboard/AnalyticsCharts.tsx', charts);

