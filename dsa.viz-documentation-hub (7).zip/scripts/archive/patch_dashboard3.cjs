const fs = require('fs');

let func = fs.readFileSync('src/routes/_authenticated/dashboard.tsx', 'utf8');

func = func.replace('new Date(s.created_at)', 'new Date(s.createdAt || s.created_at || "")');

fs.writeFileSync('src/routes/_authenticated/dashboard.tsx', func);

