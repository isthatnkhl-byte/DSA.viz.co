const fs = require('fs');

let func = fs.readFileSync('src/routes/_authenticated/dashboard.tsx', 'utf8');

func = func.replace('import { listSubmissions, deleteSubmission, type Submission } from "@/lib/submissions.functions";',
`import { listSubmissions, deleteSubmission, getProfileStats, type Submission } from "@/lib/submissions.functions";
import { Target } from "lucide-react";`);

func = func.replace('const [openId, setOpenId] = useState<string | null>(null);',
`const [openId, setOpenId] = useState<string | null>(null);
  const fetchStats = useServerFn(getProfileStats);
  const { data: statsData } = useQuery({
    queryKey: ["profileStats"],
    queryFn: () => fetchStats(),
  });
  const leetcodeStats = statsData?.profile?.leetcode_stats;
`);

const leetcodeSnippet = `
        {leetcodeStats && (
          <div className="mb-8 grid grid-cols-2 md:grid-cols-4 gap-4">
             <div className="rounded-2xl border border-border/80 bg-card/60 p-4 shadow-sm">
                <p className="text-xs text-muted-foreground font-mono uppercase tracking-wider">Total Solved</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-foreground">{leetcodeStats.totalSolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalQuestions}</span>
                </div>
             </div>
             <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-4 shadow-sm">
                <p className="text-xs text-emerald-500 font-mono uppercase tracking-wider font-bold">Easy</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-emerald-400">{leetcodeStats.easySolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalEasy}</span>
                </div>
             </div>
             <div className="rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 shadow-sm">
                <p className="text-xs text-amber-500 font-mono uppercase tracking-wider font-bold">Medium</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-amber-400">{leetcodeStats.mediumSolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalMedium}</span>
                </div>
             </div>
             <div className="rounded-2xl border border-rose-500/30 bg-rose-500/5 p-4 shadow-sm">
                <p className="text-xs text-rose-500 font-mono uppercase tracking-wider font-bold">Hard</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-rose-400">{leetcodeStats.hardSolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalHard}</span>
                </div>
             </div>
          </div>
        )}
        {!leetcodeStats && (
          <div className="mb-8 flex items-center justify-between rounded-2xl border border-dashed border-orange-500/40 bg-orange-500/5 p-4 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="flex size-10 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
                <Target className="size-5" />
              </div>
              <div>
                <h4 className="font-bold text-foreground">Connect LeetCode Account</h4>
                <p className="text-xs text-muted-foreground">Sync your LeetCode progress to see it here on your dashboard.</p>
              </div>
            </div>
            <Link to="/profile">
              <Button size="sm" className="font-bold bg-orange-500 hover:bg-orange-600 text-white shadow-md">Connect Profile</Button>
            </Link>
          </div>
        )}
`;

func = func.replace('{rows.length > 0 && <AnalyticsCharts submissions={rows} />}', leetcodeSnippet + '\n        {rows.length > 0 && <AnalyticsCharts submissions={rows} />}');

fs.writeFileSync('src/routes/_authenticated/dashboard.tsx', func);
