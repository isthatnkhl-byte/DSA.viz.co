const fs = require('fs');

let func = fs.readFileSync('src/routes/_authenticated/dashboard.tsx', 'utf8');

func = func.replace('import { Target } from "lucide-react";',
`import { Target } from "lucide-react";
import { LeetCodeHeatmap } from "@/components/dashboard/LeetCodeHeatmap";`);

func = func.replace('{leetcodeStats && (',
`{leetcodeStats && (
          <div className="mb-8">
            <div className="mb-4 grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="rounded-2xl border border-border/80 bg-card/60 p-4 shadow-sm">
                <p className="text-xs text-muted-foreground font-mono uppercase tracking-wider">Total Solved</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-foreground">{leetcodeStats.totalSolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalQuestions}</span>
                </div>
              </div>
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-4 shadow-sm">
                <p className="text-xs text-emerald-500 font-mono uppercase tracking-wider font-bold">Easy</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-emerald-400">{leetcodeStats.easySolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalEasy}</span>
                </div>
              </div>
              <div className="rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 shadow-sm">
                <p className="text-xs text-amber-500 font-mono uppercase tracking-wider font-bold">Medium</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-amber-400">{leetcodeStats.mediumSolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalMedium}</span>
                </div>
              </div>
              <div className="rounded-2xl border border-rose-500/30 bg-rose-500/5 p-4 shadow-sm">
                <p className="text-xs text-rose-500 font-mono uppercase tracking-wider font-bold">Hard</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-3xl font-black text-rose-400">{leetcodeStats.hardSolved}</span>
                  <span className="text-xs text-muted-foreground">/ {leetcodeStats.totalHard}</span>
                </div>
              </div>
            </div>
            <LeetCodeHeatmap
              calendar={leetcodeStats.submissionCalendar || {}}
              streak={leetcodeStats.streak}
              totalActiveDays={leetcodeStats.totalActiveDays}
            />
          </div>
        )}
        {/*
`);

// The previous block I added had a different structure. Let's just fix it neatly using string matching.

