const fs = require('fs');
let func = fs.readFileSync('src/routes/_authenticated/dashboard.tsx', 'utf8');
func = func.replace('import { Target } from "lucide-react";\nimport { LeetCodeHeatmap } from "@/components/dashboard/LeetCodeHeatmap";', 'import { LeetCodeHeatmap } from "@/components/dashboard/LeetCodeHeatmap";');
fs.writeFileSync('src/routes/_authenticated/dashboard.tsx', func);
