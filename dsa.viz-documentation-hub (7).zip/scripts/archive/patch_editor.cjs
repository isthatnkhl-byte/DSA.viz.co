const fs = require('fs');
let code = fs.readFileSync('src/components/problem/PseudocodeEditor.tsx', 'utf8');

if (!code.includes('onPushToGithub')) {
  // Add imports
  code = code.replace(/import \{ Sparkles, Brain, Code2, RotateCcw \} from "lucide-react";/, 'import { Sparkles, Brain, Code2, RotateCcw, Github } from "lucide-react";');

  // Add props
  code = code.replace(/onInsertStarter: \(\) => void;\n\}/, 'onInsertStarter: () => void;\n  onPushToGithub?: (code: string) => void;\n  githubLoading?: boolean;\n}');

  // Add prop destructure
  code = code.replace(/onInsertStarter,\n\}: PseudocodeEditorProps\) \{/, 'onInsertStarter,\n  onPushToGithub,\n  githubLoading,\n}: PseudocodeEditorProps) {');

  // Add button
  const githubButton = `
        {onPushToGithub && (
          <Button
            type="button"
            onClick={() => { flushChanges(); onPushToGithub(localCode); }}
            disabled={githubLoading || !localCode.trim()}
            variant="outline"
            className="gap-2 font-mono text-xs font-bold shadow-md hover:bg-[#24292e]/10 border-border"
          >
            {githubLoading ? (
              <Brain className="size-3.5 animate-spin" />
            ) : (
              <Github className="size-3.5" />
            )}
            Push to GitHub
          </Button>
        )}
  `;

  code = code.replace(/(<Button\n\s*type="button"\n\s*onClick=\{handleSubmit\})/, githubButton + '\n        $1');
  
  fs.writeFileSync('src/components/problem/PseudocodeEditor.tsx', code);
  console.log("Patched PseudocodeEditor");
}
