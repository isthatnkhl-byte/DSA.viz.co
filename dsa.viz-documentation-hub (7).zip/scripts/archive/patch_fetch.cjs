const fs = require('fs');
let code = fs.readFileSync('src/lib/submissions.functions.ts', 'utf8');

code = code.replace(/fetch\("\/api/g, 'fetch("http://127.0.0.1:3000/api');
code = code.replace(/fetch\(\`\/api/g, 'fetch(`http://127.0.0.1:3000/api');

fs.writeFileSync('src/lib/submissions.functions.ts', code);
