const fs = require('fs');
let code = fs.readFileSync('src/lib/submissions.functions.ts', 'utf8');

code = code.replace(/http:\/\/127\.0\.0\.1:3000\/api/g, '/api');

fs.writeFileSync('src/lib/submissions.functions.ts', code);
