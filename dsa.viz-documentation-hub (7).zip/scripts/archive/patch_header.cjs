const fs = require('fs');
let content = fs.readFileSync('src/components/SiteHeader.tsx', 'utf8');
content = content.replace(/<Link to="\/sheets"/g, '<Link to="/sheets" as any');
fs.writeFileSync('src/components/SiteHeader.tsx', content);
