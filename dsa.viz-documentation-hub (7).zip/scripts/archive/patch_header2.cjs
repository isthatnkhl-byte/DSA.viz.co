const fs = require('fs');
let code = fs.readFileSync('src/components/SiteHeader.tsx', 'utf8');
code = code.replace('import { supabase } from "@/integrations/supabase/client";', '');
code = code.replace(/async function signOut\(\) \{[\s\S]*?\}\n/g, '');
code = code.replace('const { user, loading } = useAuth();', 'const { user, loading, signOut } = useAuth();');
fs.writeFileSync('src/components/SiteHeader.tsx', code);
