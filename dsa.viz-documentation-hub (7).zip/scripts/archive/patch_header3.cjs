const fs = require('fs');
let code = fs.readFileSync('src/components/SiteHeader.tsx', 'utf8');

code = code.replace(/router\.invalidate\(\);\n    router\.navigate\(\{\s*to:\s*"\/",\s*replace:\s*true\s*\}\);\n  \}/g, '');

fs.writeFileSync('src/components/SiteHeader.tsx', code);
