const fs = require('fs');

let code = fs.readFileSync('src/components/dashboard/LeetCodeHeatmap.tsx', 'utf8');

code = code.replace('const dateStr = d.toISOString().split("T")[0];', 'const dateStr = d.toISOString().split("T")[0] as string;');
code = code.replace('useState<{ date: string; count: number } | null>', 'useState<any | null>');

fs.writeFileSync('src/components/dashboard/LeetCodeHeatmap.tsx', code);
