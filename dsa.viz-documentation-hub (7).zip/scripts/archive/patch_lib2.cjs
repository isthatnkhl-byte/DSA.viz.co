const fs = require('fs');

let code = fs.readFileSync('src/lib/submissions.functions.ts', 'utf8');

const syncIdx = code.indexOf('export const syncLeetCodeData');
if (syncIdx !== -1) {
  code = code.substring(0, syncIdx);
}

code += `export const syncLeetCodeData = createServerFn({ method: "POST" })
  .validator((input: unknown) => z.object({ username: z.string().min(1) }).parse(input))
  .handler(async ({ data }) => {
    const token = await getToken();
    if (!token) return { ok: false, error: "Not authenticated" };

    try {
      const res = await fetch("/api/sync-leetcode", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": \`Bearer \${token}\`,
        },
        body: JSON.stringify({ username: data.username }),
      });
      
      const resData = await res.json();
      
      if (!res.ok) {
        return { ok: false, error: resData?.error || "Failed to sync LeetCode profile" };
      }

      return { ok: true, stats: resData.stats };
    } catch (err: any) {
      return { ok: false, error: err?.message || "Failed to fetch LeetCode profile" };
    }
  });
`;

fs.writeFileSync('src/lib/submissions.functions.ts', code);
