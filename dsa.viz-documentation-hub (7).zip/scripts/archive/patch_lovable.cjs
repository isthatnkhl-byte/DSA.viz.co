const fs = require('fs');
fs.writeFileSync('src/integrations/lovable/index.ts', 'export const lovable = { auth: {} };');
