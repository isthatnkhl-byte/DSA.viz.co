const fs = require('fs');
let code = fs.readFileSync('src/routes/problem.$slug.tsx', 'utf8');

// 1. Import getProfileStats
if (!code.includes('getProfileStats')) {
  code = code.replace(/import \{ reviewPseudocode/g, 'import { getProfileStats, reviewPseudocode');
}

// 2. Fetch profile inside ProblemPage
const profileFetch = `
  const fetchStats = useServerFn(getProfileStats);
  const { data: profileStats } = useQuery({
    queryKey: ["profile-stats"],
    queryFn: () => fetchStats(),
    enabled: !!user,
  });
  
  const [githubLoading, setGithubLoading] = useState(false);
  const handlePushToGithub = async (codeStr: string) => {
    if (!profileStats?.profile?.githubToken) {
      toast.error("Please connect your GitHub account in your Profile first.");
      return;
    }
    
    setGithubLoading(true);
    try {
      const auth = getAuth();
      const token = await auth.currentUser?.getIdToken();
      const res = await fetch("/api/github/push", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": \`Bearer \${token}\`
        },
        body: JSON.stringify({
          code: codeStr,
          titleSlug: problem?.slug,
          lang: "cpp" // Default to C++ as requested
        })
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Failed to push to GitHub");
      } else {
        toast.success("Successfully pushed to GitHub!", {
          action: {
            label: "View",
            onClick: () => window.open(data.url, "_blank")
          }
        });
      }
    } catch (e) {
      toast.error("An error occurred while pushing to GitHub");
    } finally {
      setGithubLoading(false);
    }
  };
`;

if (!code.includes('handlePushToGithub')) {
  // Add React Query useQuery
  if (!code.includes('useQuery')) {
    code = code.replace(/import \{ useServerFn \} from "@tanstack\/react-start";/, 'import { useServerFn } from "@tanstack/react-start";\nimport { useQuery } from "@tanstack/react-query";');
  }
  
  // Add getAuth
  if (!code.includes('getAuth')) {
    code = code.replace(/import \{ useAuth \} from "@\/hooks\/useAuth";/, 'import { useAuth } from "@/hooks/useAuth";\nimport { getAuth } from "firebase/auth";');
  }
  
  code = code.replace(/const runReview = useServerFn\(reviewPseudocode\);/, profileFetch + '\n  const runReview = useServerFn(reviewPseudocode);');

  // Add props to PseudocodeEditor
  code = code.replace(/<PseudocodeEditor\s+pseudocode=\{pseudocode\}\s+onChange=\{\(code\) => setPseudocode\(code\)\}\s+onSubmit=\{\(\) => void onSubmit\(\)\}\s+loading=\{loading\}\s+onInsertStarter=\{insertStarterTemplate\}/, '<PseudocodeEditor\n              pseudocode={pseudocode}\n              onChange={(code) => setPseudocode(code)}\n              onSubmit={() => void onSubmit()}\n              loading={loading}\n              onInsertStarter={insertStarterTemplate}\n              onPushToGithub={handlePushToGithub}\n              githubLoading={githubLoading}');

  fs.writeFileSync('src/routes/problem.$slug.tsx', code);
  console.log("Patched problem.$slug.tsx");
}
