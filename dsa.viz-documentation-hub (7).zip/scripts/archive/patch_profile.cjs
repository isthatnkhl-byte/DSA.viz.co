const fs = require('fs');
let code = fs.readFileSync('src/routes/_authenticated/profile.tsx', 'utf8');

// 1. Add Github icon
code = code.replace(/import \{([\s\S]*?)Target,/, "import {$1Target, Github,");

// 2. Add message listener in ProfilePage for Github auth
const useEffectHook = `
  import { useEffect } from "react";
`;
if (!code.includes('import { useEffect } from "react"')) {
  // Try finding standard react import
  if (code.includes('import { useState, useMemo } from "react";')) {
    code = code.replace('import { useState, useMemo } from "react";', 'import { useState, useMemo, useEffect } from "react";');
  }
}

const githubEffect = `
  useEffect(() => {
    const handleMessage = (event) => {
      if (event.data?.type === 'GITHUB_AUTH_SUCCESS') {
        toast.success("GitHub connected successfully!");
        queryClient.invalidateQueries({ queryKey: ["profile-stats"] });
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [queryClient]);

  const handleConnectGithub = async () => {
    try {
      const auth = getAuth();
      const token = await auth.currentUser?.getIdToken();
      
      const res = await fetch("/api/github/url", {
        headers: { "Authorization": \`Bearer \${token}\` }
      });
      const { url } = await res.json();
      
      const authWindow = window.open(
        url,
        'oauth_popup',
        'width=600,height=700'
      );
      if (!authWindow) {
        toast.error('Please allow popups for this site to connect your GitHub account.');
      }
    } catch (e) {
      toast.error("Failed to initiate GitHub connect");
    }
  };
`;

code = code.replace(/(const \[editingLc, setEditingLc\] = useState\(false\);)/, "$1\n" + githubEffect);

// 3. Add getAuth import
if (!code.includes('getAuth')) {
  code = code.replace(/import \{ useAuth \} from "@\/hooks\/useAuth";/, 'import { useAuth } from "@/hooks/useAuth";\nimport { getAuth } from "firebase/auth";');
}

// 4. Add Github module UI
const githubModule = `
            {/* CONNECT WITH GITHUB MODULE */}
            <div className="flex flex-col gap-5 rounded-2xl border border-border/80 bg-card/75 p-6 shadow-sm backdrop-blur-sm mt-6">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="flex size-9 items-center justify-center rounded-xl bg-slate-500/15 border border-slate-500/30 text-slate-400">
                    <Github className="size-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground flex items-center gap-2">
                      <span>GitHub Integration</span>
                      {data?.profile?.githubToken && (
                        <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 font-mono text-[10px] font-bold text-emerald-400 border border-emerald-500/30">
                          CONNECTED
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      Connect your GitHub account to push your solutions directly to a repository.
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col gap-3">
                {data?.profile?.githubToken ? (
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-muted-foreground">
                      Your GitHub account is successfully connected.
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleConnectGithub}
                      className="h-8 text-xs font-mono"
                    >
                      Reconnect
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    <p className="text-sm font-medium text-muted-foreground">
                      Enable one-click code syncing to your personal GitHub repository.
                    </p>
                    <Button
                      onClick={handleConnectGithub}
                      className="h-10 px-5 font-bold font-mono text-xs gap-2 shrink-0 bg-[#24292e] hover:bg-[#24292e]/90 text-white w-fit"
                    >
                      <Github className="size-4" />
                      <span>Connect GitHub</span>
                    </Button>
                  </div>
                )}
              </div>
            </div>
`;

code = code.replace(/(<LeetCodeHeatmap\s*calendar=\{leetcodeStats\.submissionCalendar \?\? \{\}\}\s*activeDays=\{leetcodeStats\.totalActiveDays \?\? 0\}\s*streak=\{leetcodeStats\.streak \?\? 0\}\s*\/>\s*<\/div>\s*<\/div>\s*\)\s*\}\s*<\/div>\s*<\/div>)/, "$1\n" + githubModule);

fs.writeFileSync('src/routes/_authenticated/profile.tsx', code);
