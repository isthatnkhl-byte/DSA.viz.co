const fs = require('fs');

let server = fs.readFileSync('server.ts', 'utf8');

const routes = `
// --- DB API Routes ---
app.get("/api/profile", requireAuth, async (req, res) => {
  try {
    const user = await getOrCreateUser(req.user.uid, req.user.email || null);
    const profile = await getProfile(req.user.uid);
    res.json({ ...user, ...profile });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch profile" });
  }
});

app.post("/api/sync-leetcode", requireAuth, async (req, res) => {
  try {
    const { username, stats } = req.body;
    await updateProfile(req.user.uid, { leetcodeUsername: username, leetcodeStats: stats });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to sync" });
  }
});

app.get("/api/submissions", requireAuth, async (req, res) => {
  try {
    const subs = await getSubmissions(req.user.uid);
    res.json(subs);
  } catch (error) {
    res.status(500).json({ error: "Failed to get submissions" });
  }
});

app.post("/api/submissions", requireAuth, async (req, res) => {
  try {
    const sub = await addSubmission({ userId: req.user.uid, ...req.body });
    res.json(sub);
  } catch (error) {
    res.status(500).json({ error: "Failed to add submission" });
  }
});

app.delete("/api/submissions/:id", requireAuth, async (req, res) => {
  try {
    await deleteSubmission(Number(req.params.id), req.user.uid);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete submission" });
  }
});
// ---------------------
`;

server = server.replace('app.get("/api/files/tree"', routes + '\napp.get("/api/files/tree"');
fs.writeFileSync('server.ts', server);

