const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const startIdx = code.indexOf('app.post("/api/sync-leetcode",');
const endStr = 'app.get("/api/submissions",';
const endIdx = code.indexOf(endStr, startIdx);

if (startIdx !== -1 && endIdx !== -1) {
  code = code.substring(0, startIdx) + 
`app.post("/api/sync-leetcode", requireAuth, async (req, res) => {
  try {
    const { username } = req.body;
    const cleanUsername = username.trim();

    const [userRes, profileRes, calRes, subRes] = await Promise.all([
      fetch(\`https://alfa-leetcode-api.onrender.com/\${cleanUsername}\`),
      fetch(\`https://alfa-leetcode-api.onrender.com/\${cleanUsername}/profile\`),
      fetch(\`https://alfa-leetcode-api.onrender.com/\${cleanUsername}/calendar\`),
      fetch(\`https://alfa-leetcode-api.onrender.com/\${cleanUsername}/submission?limit=12\`),
    ]);

    const userJson = userRes.ok ? await userRes.json() : null;
    const profileJson = profileRes.ok ? await profileRes.json() : null;
    const calJson = calRes.ok ? await calRes.json() : null;
    const subJson = subRes.ok ? await subRes.json() : null;

    if (userJson?.errors || userJson?.error || userJson?.message === "user not found") {
      return res.status(404).json({ error: \`LeetCode account "\${cleanUsername}" not found.\` });
    }

    const rawCal = calJson?.submissionCalendar;
    const parsedCalendar = {};
    if (typeof rawCal === "string") {
      try { Object.assign(parsedCalendar, JSON.parse(rawCal)); } catch {}
    } else if (rawCal && typeof rawCal === "object") {
      Object.assign(parsedCalendar, rawCal);
    }
    
    // Sometimes calendar is directly returned inside profileJson
    if (Object.keys(parsedCalendar).length === 0 && profileJson?.submissionCalendar) {
      if (typeof profileJson.submissionCalendar === "string") {
        try { Object.assign(parsedCalendar, JSON.parse(profileJson.submissionCalendar)); } catch {}
      } else {
        Object.assign(parsedCalendar, profileJson.submissionCalendar);
      }
    }

    const stats = {
      username: cleanUsername,
      name: userJson?.name || cleanUsername,
      avatar: userJson?.avatar || "https://leetcode.com/static/images/LeetCode_logo.png",
      ranking: userJson?.ranking || profileJson?.ranking || 0,
      reputation: userJson?.reputation || profileJson?.reputation || 0,
      totalSolved: Number(profileJson?.totalSolved) || 0,
      totalQuestions: profileJson?.totalQuestions || 3300,
      easySolved: Number(profileJson?.easySolved) || 0,
      totalEasy: profileJson?.totalEasy || 850,
      mediumSolved: Number(profileJson?.mediumSolved) || 0,
      totalMedium: profileJson?.totalMedium || 1750,
      hardSolved: Number(profileJson?.hardSolved) || 0,
      totalHard: profileJson?.totalHard || 750,
      acceptanceRate: profileJson?.acceptanceRate || 0,
      submissionCalendar: Object.keys(parsedCalendar).length > 0 ? parsedCalendar : {},
      totalActiveDays: calJson?.totalActiveDays || Math.max(0, Object.keys(parsedCalendar).length),
      streak: calJson?.streak || 0,
      recentSubmissions: Array.isArray(subJson?.submission) && subJson.submission.length > 0
        ? subJson.submission.slice(0, 10).map((s) => ({
            title: s.title,
            titleSlug: s.titleSlug,
            statusDisplay: s.statusDisplay,
            lang: s.lang,
            timestamp: s.timestamp,
          }))
        : (profileJson?.recentSubmissions || []).slice(0, 10).map((s) => ({
             title: s.title,
             titleSlug: s.titleSlug,
             statusDisplay: s.statusDisplay,
             lang: s.lang,
             timestamp: s.timestamp,
          })),
      lastSyncedAt: new Date().toISOString(),
    };

    await updateProfile(req.user.uid, { leetcodeUsername: cleanUsername, leetcodeStats: stats });
    res.json({ success: true, stats });
  } catch (error) {
    console.error("Failed to sync LeetCode profile:", error);
    res.status(500).json({ error: "Failed to sync" });
  }
});

` + code.substring(endIdx);
  fs.writeFileSync('server.ts', code);
} else {
  console.log("NOT FOUND");
}
