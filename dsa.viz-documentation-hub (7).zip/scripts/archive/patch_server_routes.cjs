const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

// Find the start of the GitHub routes
const githubStartIdx = code.indexOf('  // GitHub OAuth');
// Find the end of the GitHub routes, which is right before app.listen(PORT, "0.0.0.0"
const appListenIdx = code.indexOf('app.listen(PORT, "0.0.0.0"');

if (githubStartIdx !== -1 && appListenIdx !== -1) {
  const githubRoutes = code.substring(githubStartIdx, appListenIdx);
  
  // Remove them from current position
  code = code.substring(0, githubStartIdx) + code.substring(appListenIdx);
  
  // Insert them right before "if (process.env.NODE_ENV !== "production") {"
  const insertIdx = code.indexOf('  if (process.env.NODE_ENV !== "production") {');
  if (insertIdx !== -1) {
    code = code.substring(0, insertIdx) + githubRoutes + '\n' + code.substring(insertIdx);
    fs.writeFileSync('server.ts', code);
    console.log("Successfully moved GitHub routes");
  } else {
    console.log("Could not find insert index");
  }
} else {
  console.log("Could not find GitHub routes");
}
