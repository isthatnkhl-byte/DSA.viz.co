const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const streakFunction = `
    function calculateCurrentStreak(calendar) {
      if (!calendar || Object.keys(calendar).length === 0) return 0;
      const ONE_DAY = 86400; // seconds
      const timestamps = Object.keys(calendar).map(Number).sort((a, b) => b - a);
      const nowTs = Math.floor(Date.now() / 1000);
      
      // We'll normalize 'today' based on the UTC day
      const todayStart = Math.floor(nowTs / ONE_DAY) * ONE_DAY;
      
      if (timestamps[0] < todayStart - ONE_DAY) {
        return 0;
      }
      
      let streak = 0;
      let currentExpected = timestamps[0]; 
      
      if (timestamps[0] === todayStart || timestamps[0] === todayStart - ONE_DAY) {
        for (const t of timestamps) {
          if (t === currentExpected) {
            streak++;
            currentExpected -= ONE_DAY;
          } else if (t < currentExpected) {
            break;
          }
        }
      }
      return streak;
    }
`;

code = code.replace(/const stats = \{/, streakFunction + '\n    const computedStreak = calculateCurrentStreak(parsedCalendar);\n\n    const stats = {');

code = code.replace(/streak: calJson\?\.streak \|\| 0,/, 'streak: computedStreak,');

fs.writeFileSync('server.ts', code);
