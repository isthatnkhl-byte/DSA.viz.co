const fs = require('fs');

let func = fs.readFileSync('src/lib/submissions.functions.ts', 'utf8');
func = `export interface Submission {
  id: number;
  userId: string;
  slug: string;
  code: string;
  lang: string;
  classification: string;
  difficulty: string;
  timeTakenMs: number | null;
  timeComplexity: string | null;
  spaceComplexity: string | null;
  createdAt: string;
}
` + func;
fs.writeFileSync('src/lib/submissions.functions.ts', func);

let authMw = fs.readFileSync('src/middleware/auth.ts', 'utf8');
authMw = authMw.replace(/if \(!token\) return res\.status\(401\)\.json\(\{ error: 'Unauthorized: Missing token' \}\);/g, 'if (!token) { return res.status(401).json({ error: \'Unauthorized: Missing token\' }); }');
fs.writeFileSync('src/middleware/auth.ts', authMw);
