const fs = require('fs');

let func = fs.readFileSync('src/lib/submissions.functions.ts', 'utf8');
func = func.replace(/export interface Submission \{[\s\S]*?\}\n/, `export interface Submission {
  id: string | number;
  userId?: string;
  slug: string;
  title?: string;
  code: string;
  pseudocode?: string | null;
  lang: string;
  classification: string;
  difficulty: string;
  timeTakenMs?: number | null;
  timeComplexity?: string | null;
  spaceComplexity?: string | null;
  time_complexity?: string | null;
  space_complexity?: string | null;
  created_at?: string;
  createdAt?: string;
  praise?: string | null;
  nudge?: string | null;
  review?: string | null;
  viz_steps?: any | null;
  test_case?: any | null;
  code_lines?: any | null;
}
`);
fs.writeFileSync('src/lib/submissions.functions.ts', func);
