const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// Replace the computedStreak part with calJson?.streak || 0
code = code.replace(/streak: computedStreak,/, 'streak: calJson?.streak || 0,');

fs.writeFileSync('server.ts', code);
