const express = require('express');
const app = express();
app.get('/test', (req, res) => {
  const proto = req.headers["x-forwarded-proto"] || "https";
  const host = req.headers["x-forwarded-host"] || req.headers.host;
  const origin = req.headers.origin || `${proto}://${host}`;
  res.json({ origin, proto, host, headers: req.headers });
});
app.listen(3001, () => console.log('started'));
