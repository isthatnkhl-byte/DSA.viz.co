async function test() {
  try {
    const res = await fetch("http://127.0.0.1:3000/api/github/url", {
      headers: { "Authorization": "Bearer TEST" }
    });
    console.log(res.status, await res.text());
  } catch (e) {
    console.error(e);
  }
}
test();
