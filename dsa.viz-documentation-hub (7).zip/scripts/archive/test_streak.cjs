const calendar = {"1781568000": 1, "1781654400": 8, "1781740800": 8, "1782172800": 10, "1783296000": 3, "1783728000": 8, "1784937600": 1, "1785024000": 5, "1785196800": 2};
const dates = Object.keys(calendar).map(Number).sort((a,b)=>a-b);
console.log(dates.map(t => new Date(t * 1000).toISOString()));
