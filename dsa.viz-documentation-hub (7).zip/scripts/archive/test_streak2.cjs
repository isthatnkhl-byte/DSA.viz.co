function calculateCurrentStreak(calendar) {
  if (!calendar || Object.keys(calendar).length === 0) return 0;
  const ONE_DAY = 86400; // seconds
  const timestamps = Object.keys(calendar).map(Number).sort((a,b)=>b-a);
  
  // LeetCode days usually reset at 00:00 UTC (or sometimes UTC-8).
  // Assuming timestamps in calendar are normalized to start of day.
  // E.g., 1785196800 is 2026-07-28T00:00:00.000Z
  const todayStart = Math.floor(Date.now() / 1000 / ONE_DAY) * ONE_DAY;
  
  // If the latest submission is older than yesterday, current streak is 0.
  if (timestamps[0] < todayStart - ONE_DAY) {
    return 0;
  }
  
  let streak = 0;
  let currentExpected = timestamps[0]; 
  
  // If the user hasn't submitted today, but submitted yesterday, the streak is still active.
  if (timestamps[0] === todayStart || timestamps[0] === todayStart - ONE_DAY) {
    for (const t of timestamps) {
      if (t === currentExpected) {
        streak++;
        currentExpected -= ONE_DAY;
      } else {
        break;
      }
    }
  }
  return streak;
}

const calendar = {"1781568000": 1, "1781654400": 8, "1781740800": 8, "1782172800": 10, "1783296000": 3, "1783728000": 8, "1784937600": 1, "1785024000": 5, "1785196800": 2};
console.log(calculateCurrentStreak(calendar));
