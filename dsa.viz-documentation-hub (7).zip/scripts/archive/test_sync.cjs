const { Pool } = require('pg');
require('dotenv').config();

async function run() {
  try {
    const cleanUsername = 'nikhil_it_is';
    const [userRes, profileRes, calRes, subRes] = await Promise.all([
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}`),
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}/profile`),
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}/calendar`),
      fetch(`https://alfa-leetcode-api.onrender.com/${cleanUsername}/submission?limit=12`),
    ]);
    
    console.log("User ok:", userRes.ok);
    console.log("Profile ok:", profileRes.ok);
    console.log("Cal ok:", calRes.ok);
    console.log("Sub ok:", subRes.ok);
    
    const userJson = userRes.ok ? await userRes.json() : null;
    const profileJson = profileRes.ok ? await profileRes.json() : null;
    const calJson = calRes.ok ? await calRes.json() : null;
    const subJson = subRes.ok ? await subRes.json() : null;

    console.log("userJson:", userJson?.message || "ok");
    console.log("profileJson.totalSolved:", profileJson?.totalSolved);
    console.log("profileJson error:", profileJson?.error);
    console.log("subJson length:", subJson?.submission?.length);
    
  } catch (e) {
    console.error(e);
  }
}
run();
