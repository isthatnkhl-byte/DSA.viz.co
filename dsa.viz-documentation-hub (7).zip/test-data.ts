import { sampleInputFor, sampleTreeFor, sampleMatrixFor } from "./src/lib/problems.ts";

console.log("Array:", sampleInputFor("two-sum"));
console.log("Tree:", sampleTreeFor("flip-binary-tree-to-match-preorder-traversal"));
console.log("Matrix:", sampleMatrixFor("number-of-islands"));
