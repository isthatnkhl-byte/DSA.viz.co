import { sampleInputFor, sampleTreeFor, sampleMatrixFor } from "./src/lib/problems.ts";

console.log("Random Array:", sampleInputFor("random-array-problem"));
console.log("Random Tree:", sampleTreeFor("random-tree-problem"));
console.log("Random Matrix:", sampleMatrixFor("random-matrix-problem"));
