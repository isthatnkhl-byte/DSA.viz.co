const titleSlug = "number-of-squareful-arrays";
fetch("https://leetcode.com/graphql", {
    method: "POST",
    headers: {
        "Content-Type": "application/json",
    },
    body: JSON.stringify({
        query: `query questionData($titleSlug: String!) {
            question(titleSlug: $titleSlug) {
                content
            }
        }`,
        variables: { titleSlug }
    })
}).then(res => res.json()).then(data => console.log(data)).catch(console.error);
