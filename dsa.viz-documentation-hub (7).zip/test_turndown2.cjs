const TurndownService = require("turndown");
const turndownService = new TurndownService({ codeBlockStyle: 'fenced' });
const html = `<p>An array is <strong>squareful</strong> if the sum of every pair of adjacent elements is a <strong>perfect square</strong>.</p>
<pre>
<strong>Input:</strong> nums = [1,17,8]
<strong>Output:</strong> 2
<strong>Explanation:</strong> [1,8,17] and [17,8,1] are the valid permutations.
</pre>`;
console.log(turndownService.turndown(html));
