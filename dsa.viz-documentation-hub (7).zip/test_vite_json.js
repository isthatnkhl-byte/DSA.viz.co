import { readFileSync } from 'fs';
const code = readFileSync('dist/server.cjs', 'utf8');
console.log(code.includes('statements_default = {') || code.includes('statements_default = '));
